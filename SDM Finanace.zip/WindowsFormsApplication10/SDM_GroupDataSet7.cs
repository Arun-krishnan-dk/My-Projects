﻿namespace WindowsFormsApplication10 {
    
    
    public partial class SDM_GroupDataSet7 {
        partial class Customer_PiggyDataTable
        {
        }
    
        partial class Customer_loanDataTable
        {
        }
    }
}

namespace WindowsFormsApplication10.SDM_GroupDataSet7TableAdapters {
    partial class Customer_PiggyTableAdapter
    {
    }
    
    
    public partial class Customer_loanTableAdapter {
    }
}
