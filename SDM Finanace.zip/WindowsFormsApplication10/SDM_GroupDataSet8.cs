﻿namespace WindowsFormsApplication10 {
    
    
    public partial class SDM_GroupDataSet8 {
    }
}

namespace WindowsFormsApplication10.SDM_GroupDataSet8TableAdapters {
    
    
    public partial class Customer_PiggyTableAdapter {
    }
}
