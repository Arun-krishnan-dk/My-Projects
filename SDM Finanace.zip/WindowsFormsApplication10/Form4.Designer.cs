﻿namespace WindowsFormsApplication10
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource3 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource4 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.RenewalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SDM_GroupDataSet7 = new WindowsFormsApplication10.SDM_GroupDataSet7();
            this.Customer_loanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DataSet3 = new WindowsFormsApplication10.DataSet3();
            this.Customer_PiggyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SDM_GroupDataSet8 = new WindowsFormsApplication10.SDM_GroupDataSet8();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DataSet2 = new WindowsFormsApplication10.DataSet2();
            this.RenewalTableAdapter = new WindowsFormsApplication10.SDM_GroupDataSet7TableAdapters.RenewalTableAdapter();
            this.reportViewer2 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer3 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.txt_Agent = new System.Windows.Forms.TextBox();
            this.Customer_PiggyTableAdapter = new WindowsFormsApplication10.SDM_GroupDataSet8TableAdapters.Customer_PiggyTableAdapter();
            this.DataSet1 = new WindowsFormsApplication10.DataSet1();
            this.Piggy_CustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Piggy_CustomerTableAdapter = new WindowsFormsApplication10.DataSet1TableAdapters.Piggy_CustomerTableAdapter();
            this.Customer_loanTableAdapter = new WindowsFormsApplication10.DataSet3TableAdapters.Customer_loanTableAdapter();
            this.reportViewer4 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.sDM_GroupDataSet10 = new WindowsFormsApplication10.SDM_GroupDataSet10();
            this.customerloanBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter2 = new WindowsFormsApplication10.SDM_GroupDataSet10TableAdapters.Customer_loanTableAdapter();
            this.sDM_GroupDataSet11 = new WindowsFormsApplication10.SDM_GroupDataSet11();
            this.customerloanBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter3 = new WindowsFormsApplication10.SDM_GroupDataSet11TableAdapters.Customer_loanTableAdapter();
            this.sDM_GroupDataSet12 = new WindowsFormsApplication10.SDM_GroupDataSet12();
            this.customerloanBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter4 = new WindowsFormsApplication10.SDM_GroupDataSet12TableAdapters.Customer_loanTableAdapter();
            this.sDM_GroupDataSet9 = new WindowsFormsApplication10.SDM_GroupDataSet9();
            this.customerloanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter1 = new WindowsFormsApplication10.SDM_GroupDataSet9TableAdapters.Customer_loanTableAdapter();
            this.sDM_GroupDataSet13 = new WindowsFormsApplication10.SDM_GroupDataSet13();
            this.customerloanBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter5 = new WindowsFormsApplication10.SDM_GroupDataSet13TableAdapters.Customer_loanTableAdapter();
            this.sDM_GroupDataSet14 = new WindowsFormsApplication10.SDM_GroupDataSet14();
            this.customerloanBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter6 = new WindowsFormsApplication10.SDM_GroupDataSet14TableAdapters.Customer_loanTableAdapter();
            this.sDM_GroupDataSet15 = new WindowsFormsApplication10.SDM_GroupDataSet15();
            this.customerloanBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter7 = new WindowsFormsApplication10.SDM_GroupDataSet15TableAdapters.Customer_loanTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.RenewalBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SDM_GroupDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_loanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_PiggyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SDM_GroupDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Piggy_CustomerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource6)).BeginInit();
            this.SuspendLayout();
            // 
            // RenewalBindingSource
            // 
            this.RenewalBindingSource.DataMember = "Renewal";
            this.RenewalBindingSource.DataSource = this.SDM_GroupDataSet7;
            // 
            // SDM_GroupDataSet7
            // 
            this.SDM_GroupDataSet7.DataSetName = "SDM_GroupDataSet7";
            this.SDM_GroupDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Customer_loanBindingSource
            // 
            this.Customer_loanBindingSource.DataMember = "Customer_loan";
            this.Customer_loanBindingSource.DataSource = this.DataSet3;
            // 
            // DataSet3
            // 
            this.DataSet3.DataSetName = "DataSet3";
            this.DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Customer_PiggyBindingSource
            // 
            this.Customer_PiggyBindingSource.DataMember = "Customer_Piggy";
            this.Customer_PiggyBindingSource.DataSource = this.SDM_GroupDataSet8;
            // 
            // SDM_GroupDataSet8
            // 
            this.SDM_GroupDataSet8.DataSetName = "SDM_GroupDataSet8";
            this.SDM_GroupDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.RenewalBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report7.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(954, 565);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // DataSet2
            // 
            this.DataSet2.DataSetName = "DataSet2";
            this.DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // RenewalTableAdapter
            // 
            this.RenewalTableAdapter.ClearBeforeFill = true;
            // 
            // reportViewer2
            // 
            this.reportViewer2.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource2.Name = "DataSet1";
            reportDataSource2.Value = this.Customer_loanBindingSource;
            this.reportViewer2.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer2.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report9.rdlc";
            this.reportViewer2.Location = new System.Drawing.Point(0, 0);
            this.reportViewer2.Name = "reportViewer2";
            this.reportViewer2.Size = new System.Drawing.Size(954, 565);
            this.reportViewer2.TabIndex = 1;
            // 
            // reportViewer3
            // 
            this.reportViewer3.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource3.Name = "DataSet1";
            reportDataSource3.Value = this.Customer_PiggyBindingSource;
            this.reportViewer3.LocalReport.DataSources.Add(reportDataSource3);
            this.reportViewer3.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report10.rdlc";
            this.reportViewer3.Location = new System.Drawing.Point(0, 0);
            this.reportViewer3.Name = "reportViewer3";
            this.reportViewer3.Size = new System.Drawing.Size(954, 565);
            this.reportViewer3.TabIndex = 2;
            // 
            // txt_Agent
            // 
            this.txt_Agent.Location = new System.Drawing.Point(682, 162);
            this.txt_Agent.Name = "txt_Agent";
            this.txt_Agent.Size = new System.Drawing.Size(105, 20);
            this.txt_Agent.TabIndex = 3;
            this.txt_Agent.Visible = false;
            // 
            // Customer_PiggyTableAdapter
            // 
            this.Customer_PiggyTableAdapter.ClearBeforeFill = true;
            // 
            // DataSet1
            // 
            this.DataSet1.DataSetName = "DataSet1";
            this.DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Piggy_CustomerBindingSource
            // 
            this.Piggy_CustomerBindingSource.DataMember = "Piggy_Customer";
            this.Piggy_CustomerBindingSource.DataSource = this.DataSet1;
            // 
            // Piggy_CustomerTableAdapter
            // 
            this.Piggy_CustomerTableAdapter.ClearBeforeFill = true;
            // 
            // Customer_loanTableAdapter
            // 
            this.Customer_loanTableAdapter.ClearBeforeFill = true;
            // 
            // reportViewer4
            // 
            this.reportViewer4.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource4.Name = "DataSet1";
            reportDataSource4.Value = this.Customer_loanBindingSource;
            this.reportViewer4.LocalReport.DataSources.Add(reportDataSource4);
            this.reportViewer4.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report11.rdlc";
            this.reportViewer4.Location = new System.Drawing.Point(0, 0);
            this.reportViewer4.Name = "reportViewer4";
            this.reportViewer4.Size = new System.Drawing.Size(954, 565);
            this.reportViewer4.TabIndex = 4;
            // 
            // sDM_GroupDataSet10
            // 
            this.sDM_GroupDataSet10.DataSetName = "SDM_GroupDataSet10";
            this.sDM_GroupDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerloanBindingSource1
            // 
            this.customerloanBindingSource1.DataMember = "Customer_loan";
            this.customerloanBindingSource1.DataSource = this.sDM_GroupDataSet10;
            // 
            // customer_loanTableAdapter2
            // 
            this.customer_loanTableAdapter2.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet11
            // 
            this.sDM_GroupDataSet11.DataSetName = "SDM_GroupDataSet11";
            this.sDM_GroupDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerloanBindingSource2
            // 
            this.customerloanBindingSource2.DataMember = "Customer_loan";
            this.customerloanBindingSource2.DataSource = this.sDM_GroupDataSet11;
            // 
            // customer_loanTableAdapter3
            // 
            this.customer_loanTableAdapter3.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet12
            // 
            this.sDM_GroupDataSet12.DataSetName = "SDM_GroupDataSet12";
            this.sDM_GroupDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerloanBindingSource3
            // 
            this.customerloanBindingSource3.DataMember = "Customer_loan";
            this.customerloanBindingSource3.DataSource = this.sDM_GroupDataSet12;
            // 
            // customer_loanTableAdapter4
            // 
            this.customer_loanTableAdapter4.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet9
            // 
            this.sDM_GroupDataSet9.DataSetName = "SDM_GroupDataSet9";
            this.sDM_GroupDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerloanBindingSource
            // 
            this.customerloanBindingSource.DataMember = "Customer_loan";
            this.customerloanBindingSource.DataSource = this.sDM_GroupDataSet9;
            // 
            // customer_loanTableAdapter1
            // 
            this.customer_loanTableAdapter1.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet13
            // 
            this.sDM_GroupDataSet13.DataSetName = "SDM_GroupDataSet13";
            this.sDM_GroupDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerloanBindingSource4
            // 
            this.customerloanBindingSource4.DataMember = "Customer_loan";
            this.customerloanBindingSource4.DataSource = this.sDM_GroupDataSet13;
            // 
            // customer_loanTableAdapter5
            // 
            this.customer_loanTableAdapter5.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet14
            // 
            this.sDM_GroupDataSet14.DataSetName = "SDM_GroupDataSet14";
            this.sDM_GroupDataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerloanBindingSource5
            // 
            this.customerloanBindingSource5.DataMember = "Customer_loan";
            this.customerloanBindingSource5.DataSource = this.sDM_GroupDataSet14;
            // 
            // customer_loanTableAdapter6
            // 
            this.customer_loanTableAdapter6.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet15
            // 
            this.sDM_GroupDataSet15.DataSetName = "SDM_GroupDataSet15";
            this.sDM_GroupDataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerloanBindingSource6
            // 
            this.customerloanBindingSource6.DataMember = "Customer_loan";
            this.customerloanBindingSource6.DataSource = this.sDM_GroupDataSet15;
            // 
            // customer_loanTableAdapter7
            // 
            this.customer_loanTableAdapter7.ClearBeforeFill = true;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 565);
            this.Controls.Add(this.txt_Agent);
            this.Controls.Add(this.reportViewer4);
            this.Controls.Add(this.reportViewer3);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.reportViewer2);
            this.Name = "Form4";
            this.Text = "Report";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.RenewalBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SDM_GroupDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_loanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_PiggyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SDM_GroupDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Piggy_CustomerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource RenewalBindingSource;
        private SDM_GroupDataSet7 SDM_GroupDataSet7;
        private SDM_GroupDataSet7TableAdapters.RenewalTableAdapter RenewalTableAdapter;
        private System.Windows.Forms.BindingSource Customer_PiggyBindingSource;
        private SDM_GroupDataSet8 SDM_GroupDataSet8;
        private SDM_GroupDataSet8TableAdapters.Customer_PiggyTableAdapter Customer_PiggyTableAdapter;
        private DataSet2 DataSet2;
        private System.Windows.Forms.BindingSource Customer_loanBindingSource;
        private DataSet3 DataSet3;
        private DataSet3TableAdapters.Customer_loanTableAdapter Customer_loanTableAdapter;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer3;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer2;
        public System.Windows.Forms.TextBox txt_Agent;
        private System.Windows.Forms.BindingSource Piggy_CustomerBindingSource;
        private DataSet1 DataSet1;
        private DataSet1TableAdapters.Piggy_CustomerTableAdapter Piggy_CustomerTableAdapter;
        private SDM_GroupDataSet9 sDM_GroupDataSet9;
        private System.Windows.Forms.BindingSource customerloanBindingSource;
        private SDM_GroupDataSet9TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter1;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer4;
        private SDM_GroupDataSet10 sDM_GroupDataSet10;
        private System.Windows.Forms.BindingSource customerloanBindingSource1;
        private SDM_GroupDataSet10TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter2;
        private SDM_GroupDataSet11 sDM_GroupDataSet11;
        private System.Windows.Forms.BindingSource customerloanBindingSource2;
        private SDM_GroupDataSet11TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter3;
        private SDM_GroupDataSet12 sDM_GroupDataSet12;
        private System.Windows.Forms.BindingSource customerloanBindingSource3;
        private SDM_GroupDataSet12TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter4;
        private SDM_GroupDataSet13 sDM_GroupDataSet13;
        private System.Windows.Forms.BindingSource customerloanBindingSource4;
        private SDM_GroupDataSet13TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter5;
        private SDM_GroupDataSet14 sDM_GroupDataSet14;
        private System.Windows.Forms.BindingSource customerloanBindingSource5;
        private SDM_GroupDataSet14TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter6;
        private SDM_GroupDataSet15 sDM_GroupDataSet15;
        private System.Windows.Forms.BindingSource customerloanBindingSource6;
        private SDM_GroupDataSet15TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter7;
    }
}