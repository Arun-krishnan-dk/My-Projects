﻿namespace WindowsFormsApplication10
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource4 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource5 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource6 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Loan_CustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DataSet1 = new WindowsFormsApplication10.DataSet1();
            this.Piggy_CustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Chit_CustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.reportViewer2 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer3 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.sDM_GroupDataSet = new WindowsFormsApplication10.SDM_GroupDataSet();
            this.sDMGroupDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txt_id = new System.Windows.Forms.TextBox();
            this.Loan_CustomerTableAdapter = new WindowsFormsApplication10.DataSet1TableAdapters.Loan_CustomerTableAdapter();
            this.Piggy_CustomerTableAdapter = new WindowsFormsApplication10.DataSet1TableAdapters.Piggy_CustomerTableAdapter();
            this.Chit_CustomerTableAdapter = new WindowsFormsApplication10.DataSet1TableAdapters.Chit_CustomerTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Loan_CustomerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Piggy_CustomerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chit_CustomerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDMGroupDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Loan_CustomerBindingSource
            // 
            this.Loan_CustomerBindingSource.DataMember = "Loan_Customer";
            this.Loan_CustomerBindingSource.DataSource = this.DataSet1;
            // 
            // DataSet1
            // 
            this.DataSet1.DataSetName = "DataSet1";
            this.DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Piggy_CustomerBindingSource
            // 
            this.Piggy_CustomerBindingSource.DataMember = "Piggy_Customer";
            this.Piggy_CustomerBindingSource.DataSource = this.DataSet1;
            // 
            // Chit_CustomerBindingSource
            // 
            this.Chit_CustomerBindingSource.DataMember = "Chit_Customer";
            this.Chit_CustomerBindingSource.DataSource = this.DataSet1;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource4.Name = "DataSet1";
            reportDataSource4.Value = this.Loan_CustomerBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource4);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report4.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(762, 523);
            this.reportViewer1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(698, 67);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(49, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(698, 102);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(49, 20);
            this.textBox2.TabIndex = 1;
            this.textBox2.Visible = false;
            // 
            // reportViewer2
            // 
            this.reportViewer2.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource5.Name = "DataSet1";
            reportDataSource5.Value = this.Piggy_CustomerBindingSource;
            this.reportViewer2.LocalReport.DataSources.Add(reportDataSource5);
            this.reportViewer2.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report2.rdlc";
            this.reportViewer2.Location = new System.Drawing.Point(0, 0);
            this.reportViewer2.Name = "reportViewer2";
            this.reportViewer2.Size = new System.Drawing.Size(762, 523);
            this.reportViewer2.TabIndex = 2;
            this.reportViewer2.Visible = false;
            // 
            // reportViewer3
            // 
            this.reportViewer3.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource6.Name = "DataSet1";
            reportDataSource6.Value = this.Chit_CustomerBindingSource;
            this.reportViewer3.LocalReport.DataSources.Add(reportDataSource6);
            this.reportViewer3.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report3.rdlc";
            this.reportViewer3.Location = new System.Drawing.Point(0, 0);
            this.reportViewer3.Name = "reportViewer3";
            this.reportViewer3.Size = new System.Drawing.Size(762, 523);
            this.reportViewer3.TabIndex = 3;
            // 
            // sDM_GroupDataSet
            // 
            this.sDM_GroupDataSet.DataSetName = "SDM_GroupDataSet";
            this.sDM_GroupDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sDMGroupDataSetBindingSource
            // 
            this.sDMGroupDataSetBindingSource.DataSource = this.sDM_GroupDataSet;
            this.sDMGroupDataSetBindingSource.Position = 0;
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(698, 142);
            this.txt_id.Name = "txt_id";
            this.txt_id.ReadOnly = true;
            this.txt_id.Size = new System.Drawing.Size(49, 20);
            this.txt_id.TabIndex = 4;
            this.txt_id.Visible = false;
            // 
            // Loan_CustomerTableAdapter
            // 
            this.Loan_CustomerTableAdapter.ClearBeforeFill = true;
            // 
            // Piggy_CustomerTableAdapter
            // 
            this.Piggy_CustomerTableAdapter.ClearBeforeFill = true;
            // 
            // Chit_CustomerTableAdapter
            // 
            this.Chit_CustomerTableAdapter.ClearBeforeFill = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(762, 523);
            this.Controls.Add(this.txt_id);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.reportViewer2);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.reportViewer3);
            this.Name = "Form2";
            this.Text = "Report";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Loan_CustomerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Piggy_CustomerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chit_CustomerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDMGroupDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource Loan_CustomerBindingSource;
        private DataSet1 DataSet1;
        private DataSet1TableAdapters.Loan_CustomerTableAdapter Loan_CustomerTableAdapter;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.BindingSource Piggy_CustomerBindingSource;
        private DataSet1TableAdapters.Piggy_CustomerTableAdapter Piggy_CustomerTableAdapter;
        private System.Windows.Forms.BindingSource Chit_CustomerBindingSource;
        private DataSet1TableAdapters.Chit_CustomerTableAdapter Chit_CustomerTableAdapter;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer2;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer3;
        private SDM_GroupDataSet sDM_GroupDataSet;
        private System.Windows.Forms.BindingSource sDMGroupDataSetBindingSource;
        public System.Windows.Forms.TextBox txt_id;
    }
}