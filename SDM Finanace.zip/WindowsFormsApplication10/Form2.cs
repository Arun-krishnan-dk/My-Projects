﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication10
{
    public partial class Form2 : Form
    {
        DateTime date1,date2;
        
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'DataSet1.Chit_Customer' table. You can move, or remove it, as needed.
             int num;
           // this.Chit_CustomerTableAdapter.Fill.(this.DataSet1.Chit_Customer,Convert.ToDateTime(textBox1.Text),Convert.ToDateTime(textBox2.Text));
            //mydataset
            // TODO: This line of code loads data into the 'DataSet1.Piggy_Customer' table. You can move, or remove it, as needed.
            if(txt_id.Text =="")
            {
            this.Piggy_CustomerTableAdapter.Fill(this.DataSet1.Piggy_Customer, Convert.ToDateTime(textBox1.Text), Convert.ToDateTime(textBox2.Text));
            this.Loan_CustomerTableAdapter.Fill(this.DataSet1.Loan_Customer, Convert.ToDateTime(textBox1.Text), Convert.ToDateTime(textBox2.Text));
            }
            else if (int.TryParse(txt_id.Text, out num) == true)
            {
                this.Piggy_CustomerTableAdapter.FillBy(this.DataSet1.Piggy_Customer, Convert.ToDateTime(textBox1.Text), Convert.ToDateTime(textBox2.Text), int.Parse(txt_id.Text));
                this.Loan_CustomerTableAdapter.FillBy(this.DataSet1.Loan_Customer, Convert.ToDateTime(textBox1.Text), Convert.ToDateTime(textBox2.Text), int.Parse(txt_id.Text));
            }
            else
            {
                this.Piggy_CustomerTableAdapter.FillBy1(this.DataSet1.Piggy_Customer, Convert.ToDateTime(textBox1.Text), Convert.ToDateTime(textBox2.Text), txt_id.Text);
                this.Loan_CustomerTableAdapter.FillBy1(this.DataSet1.Loan_Customer, Convert.ToDateTime(textBox1.Text), Convert.ToDateTime(textBox2.Text), txt_id.Text);
            }

            // TODO: This line of code loads data into the 'DataSet1.Loan_Customer' table. You can move, or remove it, as needed.
            Form1 arun = new Form1();
            //this.Loan_CustomerTableAdapter.Fill(this.DataSet1.Loan_Customer,Convert.ToDateTime(textBox1.Text) ,Convert.ToDateTime(textBox2.Text) );
            this.reportViewer1.RefreshReport();
            this.reportViewer2.RefreshReport();
            this.reportViewer3.RefreshReport();
        }
    }
}
