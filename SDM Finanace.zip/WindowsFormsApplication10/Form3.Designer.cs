﻿namespace WindowsFormsApplication10
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource3 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Customer_loanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SDM_GroupDataSet7 = new WindowsFormsApplication10.SDM_GroupDataSet7();
            this.Customer_PiggyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.txt_d1 = new System.Windows.Forms.TextBox();
            this.txt_d2 = new System.Windows.Forms.TextBox();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.Customer_loanTableAdapter = new WindowsFormsApplication10.SDM_GroupDataSet7TableAdapters.Customer_loanTableAdapter();
            this.Customer_PiggyTableAdapter = new WindowsFormsApplication10.SDM_GroupDataSet7TableAdapters.Customer_PiggyTableAdapter();
            this.SDM_GroupDataSet8 = new WindowsFormsApplication10.SDM_GroupDataSet8();
            this.DataSet3 = new WindowsFormsApplication10.DataSet3();
            this.reportViewer2 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DataSet2 = new WindowsFormsApplication10.DataSet2();
            this.reportViewer3 = new Microsoft.Reporting.WinForms.ReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_loanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SDM_GroupDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_PiggyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SDM_GroupDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // Customer_loanBindingSource
            // 
            this.Customer_loanBindingSource.DataMember = "Customer_loan";
            this.Customer_loanBindingSource.DataSource = this.SDM_GroupDataSet7;
            // 
            // SDM_GroupDataSet7
            // 
            this.SDM_GroupDataSet7.DataSetName = "SDM_GroupDataSet7";
            this.SDM_GroupDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Customer_PiggyBindingSource
            // 
            this.Customer_PiggyBindingSource.DataMember = "Customer_Piggy";
            this.Customer_PiggyBindingSource.DataSource = this.SDM_GroupDataSet7;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.Customer_loanBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report5.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(741, 488);
            this.reportViewer1.TabIndex = 0;
            // 
            // txt_d1
            // 
            this.txt_d1.Location = new System.Drawing.Point(560, 213);
            this.txt_d1.Name = "txt_d1";
            this.txt_d1.Size = new System.Drawing.Size(63, 20);
            this.txt_d1.TabIndex = 3;
            this.txt_d1.Visible = false;
            this.txt_d1.TextChanged += new System.EventHandler(this.txt_d1_TextChanged);
            // 
            // txt_d2
            // 
            this.txt_d2.Location = new System.Drawing.Point(560, 239);
            this.txt_d2.Name = "txt_d2";
            this.txt_d2.Size = new System.Drawing.Size(63, 20);
            this.txt_d2.TabIndex = 4;
            this.txt_d2.Visible = false;
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(560, 265);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(63, 20);
            this.txt_id.TabIndex = 5;
            this.txt_id.Visible = false;
            // 
            // Customer_loanTableAdapter
            // 
            this.Customer_loanTableAdapter.ClearBeforeFill = true;
            // 
            // Customer_PiggyTableAdapter
            // 
            this.Customer_PiggyTableAdapter.ClearBeforeFill = true;
            // 
            // SDM_GroupDataSet8
            // 
            this.SDM_GroupDataSet8.DataSetName = "SDM_GroupDataSet8";
            this.SDM_GroupDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // DataSet3
            // 
            this.DataSet3.DataSetName = "DataSet3";
            this.DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer2
            // 
            this.reportViewer2.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource2.Name = "DataSet1";
            reportDataSource2.Value = this.Customer_PiggyBindingSource;
            this.reportViewer2.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer2.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report6.rdlc";
            this.reportViewer2.Location = new System.Drawing.Point(0, 0);
            this.reportViewer2.Name = "reportViewer2";
            this.reportViewer2.Size = new System.Drawing.Size(741, 488);
            this.reportViewer2.TabIndex = 6;
            // 
            // DataSet2
            // 
            this.DataSet2.DataSetName = "DataSet2";
            this.DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer3
            // 
            this.reportViewer3.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource3.Name = "DataSet1";
            reportDataSource3.Value = this.Customer_loanBindingSource;
            this.reportViewer3.LocalReport.DataSources.Add(reportDataSource3);
            this.reportViewer3.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication10.Report13.rdlc";
            this.reportViewer3.Location = new System.Drawing.Point(0, 0);
            this.reportViewer3.Name = "reportViewer3";
            this.reportViewer3.Size = new System.Drawing.Size(741, 488);
            this.reportViewer3.TabIndex = 7;
            this.reportViewer3.Visible = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 488);
            this.Controls.Add(this.reportViewer3);
            this.Controls.Add(this.txt_id);
            this.Controls.Add(this.txt_d2);
            this.Controls.Add(this.txt_d1);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.reportViewer2);
            this.Name = "Form3";
            this.Text = "Report";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Customer_loanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SDM_GroupDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_PiggyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SDM_GroupDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource Customer_loanBindingSource;
        private SDM_GroupDataSet7 SDM_GroupDataSet7;
        private SDM_GroupDataSet7TableAdapters.Customer_loanTableAdapter Customer_loanTableAdapter;
        public System.Windows.Forms.TextBox txt_d1;
        public System.Windows.Forms.TextBox txt_d2;
        public System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.BindingSource Customer_PiggyBindingSource;
        private SDM_GroupDataSet7TableAdapters.Customer_PiggyTableAdapter Customer_PiggyTableAdapter;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private SDM_GroupDataSet8 SDM_GroupDataSet8;
        private DataSet3 DataSet3;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer2;
        private DataSet2 DataSet2;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer3;
    }
}