﻿namespace WindowsFormsApplication10 {
    
    
    public partial class DataSet3 {
    }
}

namespace WindowsFormsApplication10.DataSet3TableAdapters {
    
    
    public partial class Customer_loanTableAdapter {
    }
}
