﻿namespace WindowsFormsApplication10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

       #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label143 = new System.Windows.Forms.Label();
            this.txt_nominee_pig = new System.Windows.Forms.TextBox();
            this.label152 = new System.Windows.Forms.Label();
            this.txt_nominee_pig_Address = new System.Windows.Forms.TextBox();
            this.txt_Close = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.txt_app_no = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.txt_amount = new System.Windows.Forms.TextBox();
            this.cmb_agent_id = new System.Windows.Forms.ComboBox();
            this.label94 = new System.Windows.Forms.Label();
            this.Date_end_pig = new System.Windows.Forms.DateTimePicker();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cmb_area_pig = new System.Windows.Forms.ComboBox();
            this.label86 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.txt_id_pig = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.date_started_pig = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_phone_pig = new System.Windows.Forms.TextBox();
            this.txt_Name_pig = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_trade_pig = new System.Windows.Forms.TextBox();
            this.txt_Address_pig = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txt_cmb_trade_loan = new System.Windows.Forms.ComboBox();
            this.label97 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.cmb_id = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.cmb_name = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.date_due_loan = new System.Windows.Forms.DateTimePicker();
            this.date_paid_loan = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_amount_laon = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cmb_trade_Pig = new System.Windows.Forms.ComboBox();
            this.label96 = new System.Windows.Forms.Label();
            this.Cmb_id_pigme = new System.Windows.Forms.ComboBox();
            this.label71 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.cmb_name_pig = new System.Windows.Forms.ComboBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.date_pig = new System.Windows.Forms.DateTimePicker();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.Total_Paid = new System.Windows.Forms.TextBox();
            this.txt_amount_pig = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cmb_Chit = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.txt_id_chit = new System.Windows.Forms.TextBox();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txt_phone_chit = new System.Windows.Forms.TextBox();
            this.txt_Cust_chit = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txt_trade_chit = new System.Windows.Forms.TextBox();
            this.txt_address_chit = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.cmb_chit_name = new System.Windows.Forms.ComboBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.txt_total_amount = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.cmb_name_chit = new System.Windows.Forms.ComboBox();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.Paid_date_chit = new System.Windows.Forms.DateTimePicker();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.txt_amount_chit_paid = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_pass = new System.Windows.Forms.TextBox();
            this.txt_user = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.cmb_area_rpt = new System.Windows.Forms.ComboBox();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.cmb_trade_rpt = new System.Windows.Forms.ComboBox();
            this.cmb_id_rpt = new System.Windows.Forms.ComboBox();
            this.cmb_rpt_name = new System.Windows.Forms.ComboBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.button29 = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button30 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.chk_admin = new System.Windows.Forms.CheckBox();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.txt_password_c = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.txt_user_name = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.loanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentForCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updatreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.renewalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.piggyBankToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCusytomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.withdrawToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addChitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.addCustomerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.bidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.displayReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.totalCollectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.pigmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nearCompletionOfLoanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.profitLossAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripSeparator();
            this.loanReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addExpensesToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.profitLossAccountToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkPaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateCuisrtomerDetailsLoanPiggyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.totalCollectionPigmyLoanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sendMessageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reOpenClosePigmyAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripSeparator();
            this.enterAreaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.enterAgentIdToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contactInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label51 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button39 = new System.Windows.Forms.Button();
            this.date_bid = new System.Windows.Forms.DateTimePicker();
            this.txt_total_bid = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.cmb_chit_bid = new System.Windows.Forms.ComboBox();
            this.cmb_amount_bid = new System.Windows.Forms.ComboBox();
            this.bIDDER = new System.Windows.Forms.ComboBox();
            this.button34 = new System.Windows.Forms.Button();
            this.txt_balance = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txt_bid_amount = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button41 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.cmb_id_loan = new System.Windows.Forms.ComboBox();
            this.label89 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.Overdue = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.cmb_name_exc = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.due_after = new System.Windows.Forms.DateTimePicker();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.txt_due_after = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.End_date_chit = new System.Windows.Forms.DateTimePicker();
            this.label33 = new System.Windows.Forms.Label();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.label61 = new System.Windows.Forms.Label();
            this.txt_Amount_total = new System.Windows.Forms.TextBox();
            this.Start_date_chit = new System.Windows.Forms.DateTimePicker();
            this.label28 = new System.Windows.Forms.Label();
            this.txt_withdraw = new System.Windows.Forms.TextBox();
            this.txt_withdraw_amount = new System.Windows.Forms.TextBox();
            this.txt_total_taken = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.txt_profit = new System.Windows.Forms.TextBox();
            this.txt_total_balance_with = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.button40 = new System.Windows.Forms.Button();
            this.label76 = new System.Windows.Forms.Label();
            this.Cmb_name_wd = new System.Windows.Forms.ComboBox();
            this.label75 = new System.Windows.Forms.Label();
            this.Id = new System.Windows.Forms.ComboBox();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lbl_duration = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button68 = new System.Windows.Forms.Button();
            this.date_show = new System.Windows.Forms.DateTimePicker();
            this.button43 = new System.Windows.Forms.Button();
            this.txt_id_up = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.button42 = new System.Windows.Forms.Button();
            this.txt_name_update = new System.Windows.Forms.TextBox();
            this.button45 = new System.Windows.Forms.Button();
            this.date_pd_up = new System.Windows.Forms.DateTimePicker();
            this.label80 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.txt_amount_pd_up = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datePaidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nextdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.balanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loanCustomerBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.sDM_GroupDataSet3 = new WindowsFormsApplication10.SDM_GroupDataSet3();
            this.sDM_GroupDataSet1 = new WindowsFormsApplication10.SDM_GroupDataSet1();
            this.loanCustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.loan_CustomerTableAdapter = new WindowsFormsApplication10.SDM_GroupDataSet1TableAdapters.Loan_CustomerTableAdapter();
            this.sDM_GroupDataSet2 = new WindowsFormsApplication10.SDM_GroupDataSet2();
            this.loanCustomerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.loan_CustomerTableAdapter1 = new WindowsFormsApplication10.SDM_GroupDataSet2TableAdapters.Loan_CustomerTableAdapter();
            this.sDM_GroupDataSet4 = new WindowsFormsApplication10.SDM_GroupDataSet4();
            this.loanCustomerBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.loan_CustomerTableAdapter3 = new WindowsFormsApplication10.SDM_GroupDataSet4TableAdapters.Loan_CustomerTableAdapter();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button69 = new System.Windows.Forms.Button();
            this.date_now = new System.Windows.Forms.DateTimePicker();
            this.button44 = new System.Windows.Forms.Button();
            this.txt_id_up_pig = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.button46 = new System.Windows.Forms.Button();
            this.txt_name_pig_up = new System.Windows.Forms.TextBox();
            this.button47 = new System.Windows.Forms.Button();
            this.date_pd_pig = new System.Windows.Forms.DateTimePicker();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.txt_pig_amount_up = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountpaidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datepaidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.balanceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.withdrawalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.piggyCustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sDM_GroupDataSet5 = new WindowsFormsApplication10.SDM_GroupDataSet5();
            this.piggy_CustomerTableAdapter = new WindowsFormsApplication10.SDM_GroupDataSet5TableAdapters.Piggy_CustomerTableAdapter();
            this.sDM_GroupDataSet6 = new WindowsFormsApplication10.SDM_GroupDataSet6();
            this.piggyCustomerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.piggy_CustomerTableAdapter1 = new WindowsFormsApplication10.SDM_GroupDataSet6TableAdapters.Piggy_CustomerTableAdapter();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.txt_area = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.cmb_area_all = new System.Windows.Forms.ComboBox();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.cmb_trade_rep = new System.Windows.Forms.ComboBox();
            this.cmb_all_name = new System.Windows.Forms.ComboBox();
            this.cmb_id_all = new System.Windows.Forms.ComboBox();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.button50 = new System.Windows.Forms.Button();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.button51 = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txt_agenrt_name = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.txt_Agent = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_Nominee_aadress_Busioness = new System.Windows.Forms.TextBox();
            this.txt_Nominee_aadress = new System.Windows.Forms.TextBox();
            this.txt_Nominee_rel = new System.Windows.Forms.TextBox();
            this.txt_Nominee_Age = new System.Windows.Forms.TextBox();
            this.txt_Nominee = new System.Windows.Forms.TextBox();
            this.date_end = new System.Windows.Forms.DateTimePicker();
            this.label128 = new System.Windows.Forms.Label();
            this.Amt = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.txt_application_number = new System.Windows.Forms.TextBox();
            this.label108 = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.cmb_agend_id_loan = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.Area_Combox_Pig = new System.Windows.Forms.ComboBox();
            this.label85 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Date_Started = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.Customer = new System.Windows.Forms.Label();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.txt_Cutomer_name = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Interest = new System.Windows.Forms.TextBox();
            this.txt_Loan_Amt = new System.Windows.Forms.TextBox();
            this.txt_trade = new System.Windows.Forms.TextBox();
            this.txt_Address = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label103 = new System.Windows.Forms.Label();
            this.cmb_id_pay = new System.Windows.Forms.ComboBox();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.label102 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.cmb_trade_pay = new System.Windows.Forms.ComboBox();
            this.cmb_Name_pay = new System.Windows.Forms.ComboBox();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.button55 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.dateTimePicker8 = new System.Windows.Forms.DateTimePicker();
            this.button67 = new System.Windows.Forms.Button();
            this.cmb_agent_up = new System.Windows.Forms.ComboBox();
            this.cmb_area_up = new System.Windows.Forms.ComboBox();
            this.label113 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.txt_address_up = new System.Windows.Forms.TextBox();
            this.label112 = new System.Windows.Forms.Label();
            this.txt_app_up = new System.Windows.Forms.TextBox();
            this.label114 = new System.Windows.Forms.Label();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.button56 = new System.Windows.Forms.Button();
            this.txt_id_Main = new System.Windows.Forms.TextBox();
            this.label104 = new System.Windows.Forms.Label();
            this.button57 = new System.Windows.Forms.Button();
            this.txt_nam_main = new System.Windows.Forms.TextBox();
            this.button58 = new System.Windows.Forms.Button();
            this.label105 = new System.Windows.Forms.Label();
            this.txt_trade_main = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tradeNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.areaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerPiggyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sDM_GroupDataSet8 = new WindowsFormsApplication10.SDM_GroupDataSet8();
            this.txt_phone_up = new System.Windows.Forms.TextBox();
            this.customerloanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter = new WindowsFormsApplication10.SDM_GroupDataSet8TableAdapters.Customer_loanTableAdapter();
            this.customer_PiggyTableAdapter = new WindowsFormsApplication10.SDM_GroupDataSet8TableAdapters.Customer_PiggyTableAdapter();
            this.panel17 = new System.Windows.Forms.Panel();
            this.button60 = new System.Windows.Forms.Button();
            this.label115 = new System.Windows.Forms.Label();
            this.cmb_id_cl = new System.Windows.Forms.ComboBox();
            this.label116 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.cmb_trade_Cl = new System.Windows.Forms.ComboBox();
            this.Cmb_name_pig_cl = new System.Windows.Forms.ComboBox();
            this.button59 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label121 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.button63 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.label119 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.cmb_name_msg = new System.Windows.Forms.ComboBox();
            this.cmb_id_msg = new System.Windows.Forms.ComboBox();
            this.button70 = new System.Windows.Forms.Button();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.button66 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.sDMGroupDataSet8BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customerPiggyBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.customerloanBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sDM_GroupDataSet9 = new WindowsFormsApplication10.SDM_GroupDataSet9();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.sDMGroupDataSet9BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter1 = new WindowsFormsApplication10.SDM_GroupDataSet9TableAdapters.Customer_loanTableAdapter();
            this.customerloanBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.sDM_GroupDataSet16 = new WindowsFormsApplication10.SDM_GroupDataSet16();
            this.customerloanBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.customer_loanTableAdapter2 = new WindowsFormsApplication10.SDM_GroupDataSet16TableAdapters.Customer_loanTableAdapter();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.panel21 = new System.Windows.Forms.Panel();
            this.col_Day = new System.Windows.Forms.DateTimePicker();
            this.chk_all = new System.Windows.Forms.CheckBox();
            this.button75 = new System.Windows.Forms.Button();
            this.label125 = new System.Windows.Forms.Label();
            this.button72 = new System.Windows.Forms.Button();
            this.cmb_agent_name = new System.Windows.Forms.ComboBox();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.sDM_GroupDataSet17 = new WindowsFormsApplication10.SDM_GroupDataSet17();
            this.loanCustomerBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.loan_CustomerTableAdapter4 = new WindowsFormsApplication10.SDM_GroupDataSet17TableAdapters.Loan_CustomerTableAdapter();
            this.loan_CustomerTableAdapter2 = new WindowsFormsApplication10.SDM_GroupDataSet3TableAdapters.Loan_CustomerTableAdapter();
            this.sDM_GroupDataSet19 = new WindowsFormsApplication10.SDM_GroupDataSet19();
            this.loanCustomerBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.loan_CustomerTableAdapter5 = new WindowsFormsApplication10.SDM_GroupDataSet19TableAdapters.Loan_CustomerTableAdapter();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label122 = new System.Windows.Forms.Label();
            this.txt_exp = new System.Windows.Forms.TextBox();
            this.button73 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.panel20 = new System.Windows.Forms.Panel();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.button78 = new System.Windows.Forms.Button();
            this.label123 = new System.Windows.Forms.Label();
            this.dateTimePicker9 = new System.Windows.Forms.DateTimePicker();
            this.txt_exp_amt = new System.Windows.Forms.TextBox();
            this.cmb_exp = new System.Windows.Forms.ComboBox();
            this.button77 = new System.Windows.Forms.Button();
            this.lbl_loss = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.lbl_pig_int = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.lbl_intrest = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.button76 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.cmb_agent = new System.Windows.Forms.ComboBox();
            this.label117 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource3)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piggyCustomerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piggyCustomerBindingSource1)).BeginInit();
            this.panel13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPiggyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource)).BeginInit();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDMGroupDataSet8BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPiggyBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDMGroupDataSet9BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource3)).BeginInit();
            this.panel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource5)).BeginInit();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Location = new System.Drawing.Point(182, 166);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(251, 138);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Loan amount";
            this.groupBox2.Visible = false;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(27, 24);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(197, 32);
            this.button5.TabIndex = 9;
            this.button5.Text = "Add Customer";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(31, 79);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(193, 35);
            this.button6.TabIndex = 10;
            this.button6.Text = "Payment";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Controls.Add(this.button8);
            this.groupBox3.Location = new System.Drawing.Point(179, 379);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(251, 138);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Piggy bank";
            this.groupBox3.Visible = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(31, 79);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(193, 35);
            this.button7.TabIndex = 10;
            this.button7.Text = "Payment";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(27, 24);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(197, 32);
            this.button8.TabIndex = 9;
            this.button8.Text = "Add Customer";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label143);
            this.panel2.Controls.Add(this.txt_nominee_pig);
            this.panel2.Controls.Add(this.label152);
            this.panel2.Controls.Add(this.txt_nominee_pig_Address);
            this.panel2.Controls.Add(this.txt_Close);
            this.panel2.Controls.Add(this.label110);
            this.panel2.Controls.Add(this.txt_app_no);
            this.panel2.Controls.Add(this.label95);
            this.panel2.Controls.Add(this.txt_amount);
            this.panel2.Controls.Add(this.cmb_agent_id);
            this.panel2.Controls.Add(this.label94);
            this.panel2.Controls.Add(this.Date_end_pig);
            this.panel2.Controls.Add(this.label41);
            this.panel2.Controls.Add(this.label40);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.cmb_area_pig);
            this.panel2.Controls.Add(this.label86);
            this.panel2.Controls.Add(this.label43);
            this.panel2.Controls.Add(this.txt_id_pig);
            this.panel2.Controls.Add(this.label42);
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Controls.Add(this.button9);
            this.panel2.Controls.Add(this.button10);
            this.panel2.Controls.Add(this.date_started_pig);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.txt_phone_pig);
            this.panel2.Controls.Add(this.txt_Name_pig);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.txt_trade_pig);
            this.panel2.Controls.Add(this.txt_Address_pig);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Location = new System.Drawing.Point(394, 149);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(398, 652);
            this.panel2.TabIndex = 10;
            this.panel2.Visible = false;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label143.Location = new System.Drawing.Point(10, 433);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(69, 16);
            this.label143.TabIndex = 111;
            this.label143.Text = "Nominee :";
            // 
            // txt_nominee_pig
            // 
            this.txt_nominee_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nominee_pig.Location = new System.Drawing.Point(147, 431);
            this.txt_nominee_pig.Name = "txt_nominee_pig";
            this.txt_nominee_pig.Size = new System.Drawing.Size(206, 22);
            this.txt_nominee_pig.TabIndex = 110;
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label152.Location = new System.Drawing.Point(11, 469);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(120, 16);
            this.label152.TabIndex = 109;
            this.label152.Text = "Nominee Address:";
            // 
            // txt_nominee_pig_Address
            // 
            this.txt_nominee_pig_Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nominee_pig_Address.Location = new System.Drawing.Point(148, 466);
            this.txt_nominee_pig_Address.Name = "txt_nominee_pig_Address";
            this.txt_nominee_pig_Address.Size = new System.Drawing.Size(206, 22);
            this.txt_nominee_pig_Address.TabIndex = 108;
            // 
            // txt_Close
            // 
            this.txt_Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Close.Location = new System.Drawing.Point(364, 496);
            this.txt_Close.Name = "txt_Close";
            this.txt_Close.Size = new System.Drawing.Size(27, 22);
            this.txt_Close.TabIndex = 107;
            this.txt_Close.Text = "0";
            this.txt_Close.Visible = false;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(2, 49);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(132, 16);
            this.label110.TabIndex = 106;
            this.label110.Text = "Application Number :";
            // 
            // txt_app_no
            // 
            this.txt_app_no.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_app_no.Location = new System.Drawing.Point(147, 46);
            this.txt_app_no.Name = "txt_app_no";
            this.txt_app_no.Size = new System.Drawing.Size(206, 22);
            this.txt_app_no.TabIndex = 105;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(17, 498);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(59, 16);
            this.label95.TabIndex = 32;
            this.label95.Text = "Amount :";
            // 
            // txt_amount
            // 
            this.txt_amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_amount.Location = new System.Drawing.Point(149, 496);
            this.txt_amount.Name = "txt_amount";
            this.txt_amount.Size = new System.Drawing.Size(206, 22);
            this.txt_amount.TabIndex = 31;
            this.txt_amount.Text = "0";
            // 
            // cmb_agent_id
            // 
            this.cmb_agent_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_agent_id.FormattingEnabled = true;
            this.cmb_agent_id.Location = new System.Drawing.Point(149, 349);
            this.cmb_agent_id.Name = "cmb_agent_id";
            this.cmb_agent_id.Size = new System.Drawing.Size(205, 24);
            this.cmb_agent_id.TabIndex = 8;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(20, 350);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(49, 16);
            this.label94.TabIndex = 29;
            this.label94.Text = "Agent :";
            // 
            // Date_end_pig
            // 
            this.Date_end_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Date_end_pig.Location = new System.Drawing.Point(149, 566);
            this.Date_end_pig.Name = "Date_end_pig";
            this.Date_end_pig.Size = new System.Drawing.Size(204, 22);
            this.Date_end_pig.TabIndex = 28;
            this.Date_end_pig.Visible = false;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(13, 564);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(64, 16);
            this.label41.TabIndex = 27;
            this.label41.Text = "End Date";
            this.label41.Visible = false;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(15, 392);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(83, 16);
            this.label40.TabIndex = 26;
            this.label40.Text = "Interest Rate";
            this.label40.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(149, 389);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(152, 22);
            this.textBox1.TabIndex = 25;
            this.textBox1.Text = "50";
            this.textBox1.Visible = false;
            // 
            // cmb_area_pig
            // 
            this.cmb_area_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_area_pig.FormattingEnabled = true;
            this.cmb_area_pig.Location = new System.Drawing.Point(148, 310);
            this.cmb_area_pig.Name = "cmb_area_pig";
            this.cmb_area_pig.Size = new System.Drawing.Size(205, 24);
            this.cmb_area_pig.TabIndex = 7;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(22, 312);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(37, 16);
            this.label86.TabIndex = 21;
            this.label86.Text = "Area";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(12, 12);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(27, 16);
            this.label43.TabIndex = 18;
            this.label43.Text = "ID :";
            this.label43.Visible = false;
            // 
            // txt_id_pig
            // 
            this.txt_id_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_pig.Location = new System.Drawing.Point(148, 9);
            this.txt_id_pig.Name = "txt_id_pig";
            this.txt_id_pig.Size = new System.Drawing.Size(206, 22);
            this.txt_id_pig.TabIndex = 1;
            this.txt_id_pig.Visible = false;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label42.Location = new System.Drawing.Point(306, 392);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(54, 16);
            this.label42.TabIndex = 16;
            this.label42.Text = "Percent";
            this.label42.Visible = false;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(152, 533);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(79, 20);
            this.radioButton2.TabIndex = 13;
            this.radioButton2.Text = "Stagnant";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.Visible = false;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(247, 534);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(77, 20);
            this.radioButton1.TabIndex = 13;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Variable";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.Visible = false;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(230, 614);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(96, 29);
            this.button9.TabIndex = 9;
            this.button9.Text = "Cancel";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(43, 612);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(96, 29);
            this.button10.TabIndex = 9;
            this.button10.Text = "Save";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // date_started_pig
            // 
            this.date_started_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_started_pig.Location = new System.Drawing.Point(149, 272);
            this.date_started_pig.Name = "date_started_pig";
            this.date_started_pig.Size = new System.Drawing.Size(204, 22);
            this.date_started_pig.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(11, 202);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 16);
            this.label9.TabIndex = 6;
            this.label9.Text = "Phone :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(11, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 16);
            this.label10.TabIndex = 6;
            this.label10.Text = "Customer :";
            // 
            // txt_phone_pig
            // 
            this.txt_phone_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_phone_pig.Location = new System.Drawing.Point(148, 200);
            this.txt_phone_pig.Name = "txt_phone_pig";
            this.txt_phone_pig.Size = new System.Drawing.Size(206, 22);
            this.txt_phone_pig.TabIndex = 4;
            // 
            // txt_Name_pig
            // 
            this.txt_Name_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Name_pig.Location = new System.Drawing.Point(148, 82);
            this.txt_Name_pig.Name = "txt_Name_pig";
            this.txt_Name_pig.Size = new System.Drawing.Size(206, 22);
            this.txt_Name_pig.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(20, 535);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 16);
            this.label12.TabIndex = 7;
            this.label12.Text = "Type :";
            this.label12.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(13, 275);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 16);
            this.label11.TabIndex = 7;
            this.label11.Text = "Started On :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(11, 123);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 16);
            this.label15.TabIndex = 7;
            this.label15.Text = "Address :";
            // 
            // txt_trade_pig
            // 
            this.txt_trade_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_trade_pig.Location = new System.Drawing.Point(148, 235);
            this.txt_trade_pig.Name = "txt_trade_pig";
            this.txt_trade_pig.Size = new System.Drawing.Size(206, 22);
            this.txt_trade_pig.TabIndex = 5;
            // 
            // txt_Address_pig
            // 
            this.txt_Address_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Address_pig.Location = new System.Drawing.Point(147, 124);
            this.txt_Address_pig.Multiline = true;
            this.txt_Address_pig.Name = "txt_Address_pig";
            this.txt_Address_pig.Size = new System.Drawing.Size(206, 70);
            this.txt_Address_pig.TabIndex = 3;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(11, 238);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 16);
            this.label14.TabIndex = 7;
            this.label14.Text = "Trade Name :";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txt_cmb_trade_loan);
            this.panel3.Controls.Add(this.label97);
            this.panel3.Controls.Add(this.button26);
            this.panel3.Controls.Add(this.cmb_id);
            this.panel3.Controls.Add(this.label70);
            this.panel3.Controls.Add(this.cmb_name);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.groupBox7);
            this.panel3.Controls.Add(this.button12);
            this.panel3.Controls.Add(this.button11);
            this.panel3.Location = new System.Drawing.Point(269, 162);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(469, 342);
            this.panel3.TabIndex = 11;
            this.panel3.Visible = false;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // txt_cmb_trade_loan
            // 
            this.txt_cmb_trade_loan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cmb_trade_loan.FormattingEnabled = true;
            this.txt_cmb_trade_loan.Location = new System.Drawing.Point(149, 101);
            this.txt_cmb_trade_loan.Name = "txt_cmb_trade_loan";
            this.txt_cmb_trade_loan.Size = new System.Drawing.Size(280, 24);
            this.txt_cmb_trade_loan.TabIndex = 3;
            this.txt_cmb_trade_loan.SelectedIndexChanged += new System.EventHandler(this.txt_cmb_trade_loan_SelectedIndexChanged);
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(38, 104);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(88, 16);
            this.label97.TabIndex = 24;
            this.label97.Text = "Trade name :";
            // 
            // button26
            // 
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(38, 302);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(90, 24);
            this.button26.TabIndex = 7;
            this.button26.Text = "Refresh";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Visible = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // cmb_id
            // 
            this.cmb_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_id.FormattingEnabled = true;
            this.cmb_id.Location = new System.Drawing.Point(148, 28);
            this.cmb_id.Name = "cmb_id";
            this.cmb_id.Size = new System.Drawing.Size(280, 24);
            this.cmb_id.TabIndex = 1;
            this.cmb_id.SelectedIndexChanged += new System.EventHandler(this.cmb_id_SelectedIndexChanged);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(37, 31);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(25, 16);
            this.label70.TabIndex = 21;
            this.label70.Text = "Id :";
            // 
            // cmb_name
            // 
            this.cmb_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_name.FormattingEnabled = true;
            this.cmb_name.Location = new System.Drawing.Point(148, 59);
            this.cmb_name.Name = "cmb_name";
            this.cmb_name.Size = new System.Drawing.Size(280, 24);
            this.cmb_name.TabIndex = 2;
            this.cmb_name.SelectedIndexChanged += new System.EventHandler(this.cmb_name_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(37, 62);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 16);
            this.label17.TabIndex = 21;
            this.label17.Text = "Name :";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.date_due_loan);
            this.groupBox7.Controls.Add(this.date_paid_loan);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.txt_amount_laon);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(29, 146);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(428, 142);
            this.groupBox7.TabIndex = 13;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "enter";
            // 
            // date_due_loan
            // 
            this.date_due_loan.Enabled = false;
            this.date_due_loan.Location = new System.Drawing.Point(129, 102);
            this.date_due_loan.Name = "date_due_loan";
            this.date_due_loan.Size = new System.Drawing.Size(271, 22);
            this.date_due_loan.TabIndex = 6;
            this.date_due_loan.Visible = false;
            // 
            // date_paid_loan
            // 
            this.date_paid_loan.Location = new System.Drawing.Point(128, 61);
            this.date_paid_loan.Name = "date_paid_loan";
            this.date_paid_loan.Size = new System.Drawing.Size(272, 22);
            this.date_paid_loan.TabIndex = 5;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 107);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(93, 16);
            this.label18.TabIndex = 14;
            this.label18.Text = "Next Due date";
            this.label18.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 65);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 16);
            this.label16.TabIndex = 15;
            this.label16.Text = "Date paid";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 16);
            this.label13.TabIndex = 18;
            this.label13.Text = "Amount to be paid";
            // 
            // txt_amount_laon
            // 
            this.txt_amount_laon.Location = new System.Drawing.Point(128, 21);
            this.txt_amount_laon.Name = "txt_amount_laon";
            this.txt_amount_laon.Size = new System.Drawing.Size(272, 22);
            this.txt_amount_laon.TabIndex = 4;
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(247, 302);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(93, 25);
            this.button12.TabIndex = 9;
            this.button12.Text = "Cancel";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(141, 302);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(93, 25);
            this.button11.TabIndex = 8;
            this.button11.Text = "Save";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cmb_trade_Pig);
            this.panel4.Controls.Add(this.label96);
            this.panel4.Controls.Add(this.Cmb_id_pigme);
            this.panel4.Controls.Add(this.label71);
            this.panel4.Controls.Add(this.button27);
            this.panel4.Controls.Add(this.button21);
            this.panel4.Controls.Add(this.cmb_name_pig);
            this.panel4.Controls.Add(this.button13);
            this.panel4.Controls.Add(this.button14);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.groupBox8);
            this.panel4.Location = new System.Drawing.Point(296, 162);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(419, 362);
            this.panel4.TabIndex = 12;
            this.panel4.Visible = false;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // cmb_trade_Pig
            // 
            this.cmb_trade_Pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_trade_Pig.FormattingEnabled = true;
            this.cmb_trade_Pig.Location = new System.Drawing.Point(127, 91);
            this.cmb_trade_Pig.Name = "cmb_trade_Pig";
            this.cmb_trade_Pig.Size = new System.Drawing.Size(274, 24);
            this.cmb_trade_Pig.TabIndex = 3;
            this.cmb_trade_Pig.SelectedIndexChanged += new System.EventHandler(this.cmb_trade_Pig_SelectedIndexChanged);
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(28, 94);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(88, 16);
            this.label96.TabIndex = 16;
            this.label96.Text = "Trade name :";
            // 
            // Cmb_id_pigme
            // 
            this.Cmb_id_pigme.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cmb_id_pigme.FormattingEnabled = true;
            this.Cmb_id_pigme.Location = new System.Drawing.Point(122, 15);
            this.Cmb_id_pigme.Name = "Cmb_id_pigme";
            this.Cmb_id_pigme.Size = new System.Drawing.Size(274, 24);
            this.Cmb_id_pigme.TabIndex = 1;
            this.Cmb_id_pigme.SelectedIndexChanged += new System.EventHandler(this.Cmb_id_pigme_SelectedIndexChanged);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(30, 18);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(25, 16);
            this.label71.TabIndex = 14;
            this.label71.Text = "Id :";
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(111, 315);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(69, 25);
            this.button27.TabIndex = 8;
            this.button27.Text = "Refresh";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Visible = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(273, 315);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(73, 25);
            this.button21.TabIndex = 11;
            this.button21.Text = "Withdraw";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Visible = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // cmb_name_pig
            // 
            this.cmb_name_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_name_pig.FormattingEnabled = true;
            this.cmb_name_pig.Location = new System.Drawing.Point(125, 53);
            this.cmb_name_pig.Name = "cmb_name_pig";
            this.cmb_name_pig.Size = new System.Drawing.Size(274, 24);
            this.cmb_name_pig.TabIndex = 2;
            this.cmb_name_pig.SelectedIndexChanged += new System.EventHandler(this.cmb_name_pig_SelectedIndexChanged);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(190, 315);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(69, 25);
            this.button13.TabIndex = 9;
            this.button13.Text = "Cancel";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(28, 313);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(71, 25);
            this.button14.TabIndex = 7;
            this.button14.Text = "Save";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(26, 56);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 16);
            this.label22.TabIndex = 7;
            this.label22.Text = "Name :";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.date_pig);
            this.groupBox8.Controls.Add(this.label21);
            this.groupBox8.Controls.Add(this.label20);
            this.groupBox8.Controls.Add(this.label23);
            this.groupBox8.Controls.Add(this.Total_Paid);
            this.groupBox8.Controls.Add(this.txt_amount_pig);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(16, 135);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(393, 174);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Details";
            // 
            // date_pig
            // 
            this.date_pig.Location = new System.Drawing.Point(132, 78);
            this.date_pig.Name = "date_pig";
            this.date_pig.Size = new System.Drawing.Size(242, 22);
            this.date_pig.TabIndex = 5;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(5, 82);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(73, 16);
            this.label21.TabIndex = 11;
            this.label21.Text = "Date paid :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 127);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 16);
            this.label20.TabIndex = 12;
            this.label20.Text = "Total :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 40);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(122, 16);
            this.label23.TabIndex = 13;
            this.label23.Text = "Amount to be paid :";
            // 
            // Total_Paid
            // 
            this.Total_Paid.Enabled = false;
            this.Total_Paid.Location = new System.Drawing.Point(129, 121);
            this.Total_Paid.Name = "Total_Paid";
            this.Total_Paid.Size = new System.Drawing.Size(242, 22);
            this.Total_Paid.TabIndex = 6;
            this.Total_Paid.Text = "0";
            // 
            // txt_amount_pig
            // 
            this.txt_amount_pig.Location = new System.Drawing.Point(132, 38);
            this.txt_amount_pig.Name = "txt_amount_pig";
            this.txt_amount_pig.Size = new System.Drawing.Size(242, 22);
            this.txt_amount_pig.TabIndex = 4;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button16);
            this.groupBox4.Controls.Add(this.button15);
            this.groupBox4.Location = new System.Drawing.Point(574, 377);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(251, 138);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Chit";
            this.groupBox4.Visible = false;
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(28, 87);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(193, 35);
            this.button16.TabIndex = 10;
            this.button16.Text = "Create User";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Visible = false;
            this.button16.Click += new System.EventHandler(this.button6_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(28, 32);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(192, 37);
            this.button15.TabIndex = 11;
            this.button15.Text = "Reports";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button17);
            this.groupBox5.Controls.Add(this.button18);
            this.groupBox5.Location = new System.Drawing.Point(573, 176);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(251, 138);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Chits";
            this.groupBox5.Visible = false;
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(27, 75);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(193, 35);
            this.button17.TabIndex = 10;
            this.button17.Text = "Payment";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(27, 24);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(197, 32);
            this.button18.TabIndex = 9;
            this.button18.Text = "Add Customer";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.cmb_Chit);
            this.panel5.Controls.Add(this.label30);
            this.panel5.Controls.Add(this.button33);
            this.panel5.Controls.Add(this.txt_id_chit);
            this.panel5.Controls.Add(this.button19);
            this.panel5.Controls.Add(this.button20);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Controls.Add(this.label44);
            this.panel5.Controls.Add(this.label27);
            this.panel5.Controls.Add(this.txt_phone_chit);
            this.panel5.Controls.Add(this.txt_Cust_chit);
            this.panel5.Controls.Add(this.label31);
            this.panel5.Controls.Add(this.label32);
            this.panel5.Controls.Add(this.txt_trade_chit);
            this.panel5.Controls.Add(this.txt_address_chit);
            this.panel5.Location = new System.Drawing.Point(259, 207);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(367, 301);
            this.panel5.TabIndex = 14;
            this.panel5.Visible = false;
            // 
            // cmb_Chit
            // 
            this.cmb_Chit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Chit.FormattingEnabled = true;
            this.cmb_Chit.Location = new System.Drawing.Point(125, 192);
            this.cmb_Chit.Name = "cmb_Chit";
            this.cmb_Chit.Size = new System.Drawing.Size(203, 24);
            this.cmb_Chit.TabIndex = 16;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(22, 193);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(77, 16);
            this.label30.TabIndex = 15;
            this.label30.Text = "Select Chit :";
            // 
            // button33
            // 
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.Location = new System.Drawing.Point(257, 248);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(96, 29);
            this.button33.TabIndex = 11;
            this.button33.Text = "Bid";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // txt_id_chit
            // 
            this.txt_id_chit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_chit.Location = new System.Drawing.Point(123, 25);
            this.txt_id_chit.Name = "txt_id_chit";
            this.txt_id_chit.Size = new System.Drawing.Size(206, 22);
            this.txt_id_chit.TabIndex = 10;
            this.txt_id_chit.TextChanged += new System.EventHandler(this.txt_id_chit_TextChanged);
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(137, 248);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(96, 29);
            this.button19.TabIndex = 9;
            this.button19.Text = "Cancel";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(15, 248);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(96, 29);
            this.button20.TabIndex = 9;
            this.button20.Text = "Save";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(18, 123);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 16);
            this.label26.TabIndex = 6;
            this.label26.Text = "Phone :";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(19, 27);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(22, 16);
            this.label44.TabIndex = 6;
            this.label44.Text = "Id:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(19, 54);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(71, 16);
            this.label27.TabIndex = 6;
            this.label27.Text = "Customer :";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // txt_phone_chit
            // 
            this.txt_phone_chit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_phone_chit.Location = new System.Drawing.Point(123, 120);
            this.txt_phone_chit.Name = "txt_phone_chit";
            this.txt_phone_chit.Size = new System.Drawing.Size(206, 22);
            this.txt_phone_chit.TabIndex = 4;
            this.txt_phone_chit.TextChanged += new System.EventHandler(this.txt_phone_chit_TextChanged);
            // 
            // txt_Cust_chit
            // 
            this.txt_Cust_chit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cust_chit.Location = new System.Drawing.Point(123, 51);
            this.txt_Cust_chit.Name = "txt_Cust_chit";
            this.txt_Cust_chit.Size = new System.Drawing.Size(206, 22);
            this.txt_Cust_chit.TabIndex = 4;
            this.txt_Cust_chit.TextChanged += new System.EventHandler(this.txt_Cust_chit_TextChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(19, 158);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(91, 16);
            this.label31.TabIndex = 7;
            this.label31.Text = "Trade Name :";
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(19, 84);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 16);
            this.label32.TabIndex = 7;
            this.label32.Text = "Address :";
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // txt_trade_chit
            // 
            this.txt_trade_chit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_trade_chit.Location = new System.Drawing.Point(123, 155);
            this.txt_trade_chit.Name = "txt_trade_chit";
            this.txt_trade_chit.Size = new System.Drawing.Size(206, 22);
            this.txt_trade_chit.TabIndex = 5;
            this.txt_trade_chit.TextChanged += new System.EventHandler(this.txt_trade_chit_TextChanged);
            // 
            // txt_address_chit
            // 
            this.txt_address_chit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_address_chit.Location = new System.Drawing.Point(123, 81);
            this.txt_address_chit.Name = "txt_address_chit";
            this.txt_address_chit.Size = new System.Drawing.Size(206, 22);
            this.txt_address_chit.TabIndex = 5;
            this.txt_address_chit.TextChanged += new System.EventHandler(this.txt_address_chit_TextChanged);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.cmb_chit_name);
            this.panel7.Controls.Add(this.label62);
            this.panel7.Controls.Add(this.label45);
            this.panel7.Controls.Add(this.txt_total_amount);
            this.panel7.Controls.Add(this.button28);
            this.panel7.Controls.Add(this.cmb_name_chit);
            this.panel7.Controls.Add(this.button24);
            this.panel7.Controls.Add(this.button25);
            this.panel7.Controls.Add(this.Paid_date_chit);
            this.panel7.Controls.Add(this.label35);
            this.panel7.Controls.Add(this.label36);
            this.panel7.Controls.Add(this.label39);
            this.panel7.Controls.Add(this.txt_amount_chit_paid);
            this.panel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel7.Location = new System.Drawing.Point(384, 180);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(385, 271);
            this.panel7.TabIndex = 16;
            this.panel7.Visible = false;
            // 
            // cmb_chit_name
            // 
            this.cmb_chit_name.FormattingEnabled = true;
            this.cmb_chit_name.Location = new System.Drawing.Point(157, 16);
            this.cmb_chit_name.Name = "cmb_chit_name";
            this.cmb_chit_name.Size = new System.Drawing.Size(183, 24);
            this.cmb_chit_name.TabIndex = 1;
            this.cmb_chit_name.SelectedIndexChanged += new System.EventHandler(this.cmb_chit_name_SelectedIndexChanged);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(26, 19);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(36, 16);
            this.label62.TabIndex = 14;
            this.label62.Text = "Chit :";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(25, 173);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(118, 16);
            this.label45.TabIndex = 13;
            this.label45.Text = "Total Amount Paid";
            // 
            // txt_total_amount
            // 
            this.txt_total_amount.Enabled = false;
            this.txt_total_amount.Location = new System.Drawing.Point(162, 171);
            this.txt_total_amount.Name = "txt_total_amount";
            this.txt_total_amount.Size = new System.Drawing.Size(175, 22);
            this.txt_total_amount.TabIndex = 5;
            this.txt_total_amount.Text = "0";
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(49, 219);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(83, 25);
            this.button28.TabIndex = 6;
            this.button28.Text = "Refresh";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // cmb_name_chit
            // 
            this.cmb_name_chit.FormattingEnabled = true;
            this.cmb_name_chit.Location = new System.Drawing.Point(157, 50);
            this.cmb_name_chit.Name = "cmb_name_chit";
            this.cmb_name_chit.Size = new System.Drawing.Size(183, 24);
            this.cmb_name_chit.TabIndex = 2;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(245, 217);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(83, 25);
            this.button24.TabIndex = 8;
            this.button24.Text = "Cancel";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.Enabled = false;
            this.button25.Location = new System.Drawing.Point(149, 219);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(83, 25);
            this.button25.TabIndex = 7;
            this.button25.Text = "Save";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // Paid_date_chit
            // 
            this.Paid_date_chit.Location = new System.Drawing.Point(157, 136);
            this.Paid_date_chit.Name = "Paid_date_chit";
            this.Paid_date_chit.Size = new System.Drawing.Size(183, 22);
            this.Paid_date_chit.TabIndex = 4;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(22, 140);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(67, 16);
            this.label35.TabIndex = 7;
            this.label35.Text = "Date paid";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(26, 53);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(51, 16);
            this.label36.TabIndex = 7;
            this.label36.Text = "Name :";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(20, 98);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(116, 16);
            this.label39.TabIndex = 7;
            this.label39.Text = "Amount to be paid";
            // 
            // txt_amount_chit_paid
            // 
            this.txt_amount_chit_paid.Location = new System.Drawing.Point(157, 96);
            this.txt_amount_chit_paid.Name = "txt_amount_chit_paid";
            this.txt_amount_chit_paid.Size = new System.Drawing.Size(183, 22);
            this.txt_amount_chit_paid.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txt_pass);
            this.groupBox1.Controls.Add(this.txt_user);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(352, 316);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(356, 187);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Login";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(215, 135);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 32);
            this.button2.TabIndex = 8;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(57, 135);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 32);
            this.button1.TabIndex = 8;
            this.button1.Text = "&Ok";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Password :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "User Name :";
            // 
            // txt_pass
            // 
            this.txt_pass.Location = new System.Drawing.Point(117, 89);
            this.txt_pass.Name = "txt_pass";
            this.txt_pass.PasswordChar = '*';
            this.txt_pass.Size = new System.Drawing.Size(206, 22);
            this.txt_pass.TabIndex = 2;
            // 
            // txt_user
            // 
            this.txt_user.Location = new System.Drawing.Point(117, 30);
            this.txt_user.Name = "txt_user";
            this.txt_user.Size = new System.Drawing.Size(206, 22);
            this.txt_user.TabIndex = 1;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.groupBox13);
            this.groupBox9.Controls.Add(this.groupBox12);
            this.groupBox9.Controls.Add(this.radioButton8);
            this.groupBox9.Controls.Add(this.groupBox11);
            this.groupBox9.Controls.Add(this.radioButton7);
            this.groupBox9.Controls.Add(this.radioButton6);
            this.groupBox9.Controls.Add(this.button29);
            this.groupBox9.Controls.Add(this.label47);
            this.groupBox9.Controls.Add(this.label46);
            this.groupBox9.Controls.Add(this.dateTimePicker2);
            this.groupBox9.Controls.Add(this.dateTimePicker1);
            this.groupBox9.Controls.Add(this.button30);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(331, 191);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(493, 406);
            this.groupBox9.TabIndex = 18;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "                                             ";
            this.groupBox9.Visible = false;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.radioButton5);
            this.groupBox13.Controls.Add(this.radioButton4);
            this.groupBox13.Controls.Add(this.radioButton3);
            this.groupBox13.Location = new System.Drawing.Point(22, 121);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(457, 63);
            this.groupBox13.TabIndex = 22;
            this.groupBox13.TabStop = false;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(322, 23);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(109, 20);
            this.radioButton5.TabIndex = 16;
            this.radioButton5.Text = "Piggy_Report";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(178, 23);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(92, 20);
            this.radioButton4.TabIndex = 17;
            this.radioButton4.Text = "Chit Report";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.Visible = false;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Checked = true;
            this.radioButton3.Location = new System.Drawing.Point(24, 24);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(100, 20);
            this.radioButton3.TabIndex = 18;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Loan Report";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.cmb_area_rpt);
            this.groupBox12.Location = new System.Drawing.Point(29, 280);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(444, 55);
            this.groupBox12.TabIndex = 21;
            this.groupBox12.TabStop = false;
            this.groupBox12.Visible = false;
            // 
            // cmb_area_rpt
            // 
            this.cmb_area_rpt.FormattingEnabled = true;
            this.cmb_area_rpt.Location = new System.Drawing.Point(9, 19);
            this.cmb_area_rpt.Name = "cmb_area_rpt";
            this.cmb_area_rpt.Size = new System.Drawing.Size(429, 24);
            this.cmb_area_rpt.TabIndex = 29;
            this.cmb_area_rpt.SelectedIndexChanged += new System.EventHandler(this.cmb_area_rpt_SelectedIndexChanged);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(359, 199);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(55, 20);
            this.radioButton8.TabIndex = 20;
            this.radioButton8.Text = "Area";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.cmb_trade_rpt);
            this.groupBox11.Controls.Add(this.cmb_id_rpt);
            this.groupBox11.Controls.Add(this.cmb_rpt_name);
            this.groupBox11.Location = new System.Drawing.Point(29, 224);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(444, 50);
            this.groupBox11.TabIndex = 18;
            this.groupBox11.TabStop = false;
            this.groupBox11.Visible = false;
            this.groupBox11.Enter += new System.EventHandler(this.groupBox11_Enter);
            // 
            // cmb_trade_rpt
            // 
            this.cmb_trade_rpt.FormattingEnabled = true;
            this.cmb_trade_rpt.Location = new System.Drawing.Point(195, 18);
            this.cmb_trade_rpt.Name = "cmb_trade_rpt";
            this.cmb_trade_rpt.Size = new System.Drawing.Size(149, 24);
            this.cmb_trade_rpt.TabIndex = 22;
            this.cmb_trade_rpt.SelectedIndexChanged += new System.EventHandler(this.cmb_trade_rpt_SelectedIndexChanged);
            // 
            // cmb_id_rpt
            // 
            this.cmb_id_rpt.FormattingEnabled = true;
            this.cmb_id_rpt.Location = new System.Drawing.Point(353, 17);
            this.cmb_id_rpt.Name = "cmb_id_rpt";
            this.cmb_id_rpt.Size = new System.Drawing.Size(85, 24);
            this.cmb_id_rpt.TabIndex = 21;
            this.cmb_id_rpt.SelectedIndexChanged += new System.EventHandler(this.cmb_id_rpt_SelectedIndexChanged);
            // 
            // cmb_rpt_name
            // 
            this.cmb_rpt_name.FormattingEnabled = true;
            this.cmb_rpt_name.Location = new System.Drawing.Point(8, 18);
            this.cmb_rpt_name.Name = "cmb_rpt_name";
            this.cmb_rpt_name.Size = new System.Drawing.Size(181, 24);
            this.cmb_rpt_name.TabIndex = 20;
            this.cmb_rpt_name.SelectedIndexChanged += new System.EventHandler(this.cmb_rpt_name_SelectedIndexChanged);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Checked = true;
            this.radioButton7.Location = new System.Drawing.Point(42, 199);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(63, 20);
            this.radioButton7.TabIndex = 17;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Group";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(199, 199);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(80, 20);
            this.radioButton6.TabIndex = 16;
            this.radioButton6.Text = "Personal";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(286, 354);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(135, 35);
            this.button29.TabIndex = 14;
            this.button29.Text = "Exit";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click_1);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(90, 31);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(39, 16);
            this.label47.TabIndex = 13;
            this.label47.Text = "From";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(95, 80);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(25, 16);
            this.label46.TabIndex = 12;
            this.label46.Text = "To";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(189, 82);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(224, 22);
            this.dateTimePicker2.TabIndex = 11;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(188, 31);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(224, 22);
            this.dateTimePicker1.TabIndex = 11;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(84, 352);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(135, 35);
            this.button30.TabIndex = 10;
            this.button30.Text = "Generate Report";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button29_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.chk_admin);
            this.groupBox10.Controls.Add(this.button31);
            this.groupBox10.Controls.Add(this.button32);
            this.groupBox10.Controls.Add(this.label50);
            this.groupBox10.Controls.Add(this.label48);
            this.groupBox10.Controls.Add(this.label49);
            this.groupBox10.Controls.Add(this.txt_password_c);
            this.groupBox10.Controls.Add(this.txt_password);
            this.groupBox10.Controls.Add(this.txt_user_name);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(272, 231);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(372, 253);
            this.groupBox10.TabIndex = 19;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Login";
            this.groupBox10.Visible = false;
            this.groupBox10.Enter += new System.EventHandler(this.groupBox10_Enter);
            // 
            // chk_admin
            // 
            this.chk_admin.AutoSize = true;
            this.chk_admin.Location = new System.Drawing.Point(138, 147);
            this.chk_admin.Name = "chk_admin";
            this.chk_admin.Size = new System.Drawing.Size(65, 20);
            this.chk_admin.TabIndex = 4;
            this.chk_admin.Text = "Admin";
            this.chk_admin.UseVisualStyleBackColor = true;
            this.chk_admin.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged_1);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(207, 193);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(94, 32);
            this.button31.TabIndex = 6;
            this.button31.Text = "&Cancel";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(49, 193);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(88, 32);
            this.button32.TabIndex = 5;
            this.button32.Text = "&Ok";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(18, 111);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(119, 16);
            this.label50.TabIndex = 7;
            this.label50.Text = "Confirm Password:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(22, 71);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(74, 16);
            this.label48.TabIndex = 7;
            this.label48.Text = "Password :";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(22, 35);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(83, 16);
            this.label49.TabIndex = 6;
            this.label49.Text = "User Name :";
            // 
            // txt_password_c
            // 
            this.txt_password_c.Location = new System.Drawing.Point(139, 111);
            this.txt_password_c.Name = "txt_password_c";
            this.txt_password_c.PasswordChar = '*';
            this.txt_password_c.Size = new System.Drawing.Size(206, 22);
            this.txt_password_c.TabIndex = 3;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(139, 70);
            this.txt_password.Name = "txt_password";
            this.txt_password.PasswordChar = '*';
            this.txt_password.Size = new System.Drawing.Size(206, 22);
            this.txt_password.TabIndex = 2;
            // 
            // txt_user_name
            // 
            this.txt_user_name.Location = new System.Drawing.Point(139, 34);
            this.txt_user_name.Name = "txt_user_name";
            this.txt_user_name.Size = new System.Drawing.Size(206, 22);
            this.txt_user_name.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loanToolStripMenuItem,
            this.piggyBankToolStripMenuItem,
            this.chitToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.accountToolStripMenuItem,
            this.optionsToolStripMenuItem,
            this.masterToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1054, 29);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // loanToolStripMenuItem
            // 
            this.loanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCustomerToolStripMenuItem,
            this.paymentForCustomerToolStripMenuItem,
            this.updatreToolStripMenuItem,
            this.toolStripMenuItem1,
            this.renewalToolStripMenuItem});
            this.loanToolStripMenuItem.Name = "loanToolStripMenuItem";
            this.loanToolStripMenuItem.Size = new System.Drawing.Size(56, 25);
            this.loanToolStripMenuItem.Text = "Loan";
            this.loanToolStripMenuItem.Click += new System.EventHandler(this.loanToolStripMenuItem_Click);
            // 
            // addCustomerToolStripMenuItem
            // 
            this.addCustomerToolStripMenuItem.Name = "addCustomerToolStripMenuItem";
            this.addCustomerToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.addCustomerToolStripMenuItem.Text = "Add Customer";
            this.addCustomerToolStripMenuItem.Click += new System.EventHandler(this.addCustomerToolStripMenuItem_Click);
            // 
            // paymentForCustomerToolStripMenuItem
            // 
            this.paymentForCustomerToolStripMenuItem.Name = "paymentForCustomerToolStripMenuItem";
            this.paymentForCustomerToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.paymentForCustomerToolStripMenuItem.Text = "Payment";
            this.paymentForCustomerToolStripMenuItem.Click += new System.EventHandler(this.paymentForCustomerToolStripMenuItem_Click);
            // 
            // updatreToolStripMenuItem
            // 
            this.updatreToolStripMenuItem.Name = "updatreToolStripMenuItem";
            this.updatreToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.updatreToolStripMenuItem.Text = "Update Payment";
            this.updatreToolStripMenuItem.Click += new System.EventHandler(this.updatreToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(192, 6);
            // 
            // renewalToolStripMenuItem
            // 
            this.renewalToolStripMenuItem.Enabled = false;
            this.renewalToolStripMenuItem.Name = "renewalToolStripMenuItem";
            this.renewalToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.renewalToolStripMenuItem.Text = "Renewal";
            this.renewalToolStripMenuItem.Click += new System.EventHandler(this.renewalToolStripMenuItem_Click);
            // 
            // piggyBankToolStripMenuItem
            // 
            this.piggyBankToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCusytomerToolStripMenuItem,
            this.paymentToolStripMenuItem,
            this.toolStripMenuItem5,
            this.toolStripMenuItem4,
            this.withdrawToolStripMenuItem});
            this.piggyBankToolStripMenuItem.Name = "piggyBankToolStripMenuItem";
            this.piggyBankToolStripMenuItem.Size = new System.Drawing.Size(104, 25);
            this.piggyBankToolStripMenuItem.Text = "Pigmy Bank";
            this.piggyBankToolStripMenuItem.Click += new System.EventHandler(this.piggyBankToolStripMenuItem_Click);
            // 
            // addCusytomerToolStripMenuItem
            // 
            this.addCusytomerToolStripMenuItem.Name = "addCusytomerToolStripMenuItem";
            this.addCusytomerToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.addCusytomerToolStripMenuItem.Text = "Add Customer";
            this.addCusytomerToolStripMenuItem.Click += new System.EventHandler(this.addCusytomerToolStripMenuItem_Click);
            // 
            // paymentToolStripMenuItem
            // 
            this.paymentToolStripMenuItem.Name = "paymentToolStripMenuItem";
            this.paymentToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.paymentToolStripMenuItem.Text = "Payment";
            this.paymentToolStripMenuItem.Click += new System.EventHandler(this.paymentToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(195, 26);
            this.toolStripMenuItem5.Text = "Update Payment";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(192, 6);
            // 
            // withdrawToolStripMenuItem
            // 
            this.withdrawToolStripMenuItem.Name = "withdrawToolStripMenuItem";
            this.withdrawToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.withdrawToolStripMenuItem.Text = "Withdraw";
            this.withdrawToolStripMenuItem.Click += new System.EventHandler(this.withdrawToolStripMenuItem_Click);
            // 
            // chitToolStripMenuItem
            // 
            this.chitToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addChitToolStripMenuItem,
            this.toolStripMenuItem2,
            this.addCustomerToolStripMenuItem1,
            this.paymentToolStripMenuItem1,
            this.toolStripMenuItem3,
            this.bidToolStripMenuItem});
            this.chitToolStripMenuItem.Name = "chitToolStripMenuItem";
            this.chitToolStripMenuItem.Size = new System.Drawing.Size(50, 25);
            this.chitToolStripMenuItem.Text = "Chit";
            this.chitToolStripMenuItem.Visible = false;
            // 
            // addChitToolStripMenuItem
            // 
            this.addChitToolStripMenuItem.Name = "addChitToolStripMenuItem";
            this.addChitToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.addChitToolStripMenuItem.Text = "Add Chit";
            this.addChitToolStripMenuItem.Click += new System.EventHandler(this.addChitToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(177, 6);
            // 
            // addCustomerToolStripMenuItem1
            // 
            this.addCustomerToolStripMenuItem1.Name = "addCustomerToolStripMenuItem1";
            this.addCustomerToolStripMenuItem1.Size = new System.Drawing.Size(180, 26);
            this.addCustomerToolStripMenuItem1.Text = "Add Customer";
            this.addCustomerToolStripMenuItem1.Click += new System.EventHandler(this.addCustomerToolStripMenuItem1_Click);
            // 
            // paymentToolStripMenuItem1
            // 
            this.paymentToolStripMenuItem1.Name = "paymentToolStripMenuItem1";
            this.paymentToolStripMenuItem1.Size = new System.Drawing.Size(180, 26);
            this.paymentToolStripMenuItem1.Text = "Payment";
            this.paymentToolStripMenuItem1.Click += new System.EventHandler(this.paymentToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(177, 6);
            // 
            // bidToolStripMenuItem
            // 
            this.bidToolStripMenuItem.Name = "bidToolStripMenuItem";
            this.bidToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.bidToolStripMenuItem.Text = "Bid";
            this.bidToolStripMenuItem.Click += new System.EventHandler(this.bidToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.displayReportToolStripMenuItem,
            this.totalCollectionToolStripMenuItem,
            this.toolStripMenuItem6,
            this.pigmeToolStripMenuItem,
            this.nearCompletionOfLoanToolStripMenuItem,
            this.toolStripMenuItem9,
            this.profitLossAccountToolStripMenuItem,
            this.toolStripMenuItem12,
            this.loanReportToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(76, 25);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // displayReportToolStripMenuItem
            // 
            this.displayReportToolStripMenuItem.Name = "displayReportToolStripMenuItem";
            this.displayReportToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.displayReportToolStripMenuItem.Text = "Customer Loan/Pigmy";
            this.displayReportToolStripMenuItem.Click += new System.EventHandler(this.displayReportToolStripMenuItem_Click);
            // 
            // totalCollectionToolStripMenuItem
            // 
            this.totalCollectionToolStripMenuItem.Name = "totalCollectionToolStripMenuItem";
            this.totalCollectionToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.totalCollectionToolStripMenuItem.Text = "Total Customer Loan/Pigmy";
            this.totalCollectionToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.totalCollectionToolStripMenuItem.ToolTipText = "Hello";
            this.totalCollectionToolStripMenuItem.Click += new System.EventHandler(this.totalCollectionToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(271, 6);
            // 
            // pigmeToolStripMenuItem
            // 
            this.pigmeToolStripMenuItem.Name = "pigmeToolStripMenuItem";
            this.pigmeToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.pigmeToolStripMenuItem.Text = "Renewal";
            this.pigmeToolStripMenuItem.Click += new System.EventHandler(this.pigmeToolStripMenuItem_Click);
            // 
            // nearCompletionOfLoanToolStripMenuItem
            // 
            this.nearCompletionOfLoanToolStripMenuItem.Name = "nearCompletionOfLoanToolStripMenuItem";
            this.nearCompletionOfLoanToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.nearCompletionOfLoanToolStripMenuItem.Text = "Near Completion of Loan";
            this.nearCompletionOfLoanToolStripMenuItem.Click += new System.EventHandler(this.nearCompletionOfLoanToolStripMenuItem_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(271, 6);
            // 
            // profitLossAccountToolStripMenuItem
            // 
            this.profitLossAccountToolStripMenuItem.Name = "profitLossAccountToolStripMenuItem";
            this.profitLossAccountToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.profitLossAccountToolStripMenuItem.Text = "Profit/Loss Account Report";
            this.profitLossAccountToolStripMenuItem.Click += new System.EventHandler(this.profitLossAccountToolStripMenuItem_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(271, 6);
            // 
            // loanReportToolStripMenuItem
            // 
            this.loanReportToolStripMenuItem.Name = "loanReportToolStripMenuItem";
            this.loanReportToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.loanReportToolStripMenuItem.Text = "Print Collection Sheet";
            this.loanReportToolStripMenuItem.Click += new System.EventHandler(this.loanReportToolStripMenuItem_Click_1);
            // 
            // accountToolStripMenuItem
            // 
            this.accountToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addExpensesToolStripMenuItem2,
            this.profitLossAccountToolStripMenuItem1});
            this.accountToolStripMenuItem.Name = "accountToolStripMenuItem";
            this.accountToolStripMenuItem.Size = new System.Drawing.Size(78, 25);
            this.accountToolStripMenuItem.Text = "Account";
            // 
            // addExpensesToolStripMenuItem2
            // 
            this.addExpensesToolStripMenuItem2.Name = "addExpensesToolStripMenuItem2";
            this.addExpensesToolStripMenuItem2.Size = new System.Drawing.Size(215, 26);
            this.addExpensesToolStripMenuItem2.Text = "Add Expenses";
            this.addExpensesToolStripMenuItem2.Click += new System.EventHandler(this.addExpensesToolStripMenuItem2_Click);
            // 
            // profitLossAccountToolStripMenuItem1
            // 
            this.profitLossAccountToolStripMenuItem1.Name = "profitLossAccountToolStripMenuItem1";
            this.profitLossAccountToolStripMenuItem1.Size = new System.Drawing.Size(215, 26);
            this.profitLossAccountToolStripMenuItem1.Text = "Profit/Loss Account";
            this.profitLossAccountToolStripMenuItem1.Click += new System.EventHandler(this.profitLossAccountToolStripMenuItem1_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.checkPaymentToolStripMenuItem,
            this.updateCuisrtomerDetailsLoanPiggyToolStripMenuItem,
            this.toolStripMenuItem8,
            this.totalCollectionPigmyLoanToolStripMenuItem,
            this.sendMessageToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(77, 25);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // checkPaymentToolStripMenuItem
            // 
            this.checkPaymentToolStripMenuItem.Name = "checkPaymentToolStripMenuItem";
            this.checkPaymentToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.checkPaymentToolStripMenuItem.Text = "Check Payment";
            this.checkPaymentToolStripMenuItem.Click += new System.EventHandler(this.checkPaymentToolStripMenuItem_Click);
            // 
            // updateCuisrtomerDetailsLoanPiggyToolStripMenuItem
            // 
            this.updateCuisrtomerDetailsLoanPiggyToolStripMenuItem.Name = "updateCuisrtomerDetailsLoanPiggyToolStripMenuItem";
            this.updateCuisrtomerDetailsLoanPiggyToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.updateCuisrtomerDetailsLoanPiggyToolStripMenuItem.Text = "Update Customer Details Loan/Pigmy";
            this.updateCuisrtomerDetailsLoanPiggyToolStripMenuItem.Click += new System.EventHandler(this.updateCuisrtomerDetailsLoanPiggyToolStripMenuItem_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(338, 6);
            // 
            // totalCollectionPigmyLoanToolStripMenuItem
            // 
            this.totalCollectionPigmyLoanToolStripMenuItem.Name = "totalCollectionPigmyLoanToolStripMenuItem";
            this.totalCollectionPigmyLoanToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.totalCollectionPigmyLoanToolStripMenuItem.Text = "Total Collection Pigmy/ Loan";
            this.totalCollectionPigmyLoanToolStripMenuItem.Click += new System.EventHandler(this.totalCollectionPigmyLoanToolStripMenuItem_Click);
            // 
            // sendMessageToolStripMenuItem
            // 
            this.sendMessageToolStripMenuItem.Name = "sendMessageToolStripMenuItem";
            this.sendMessageToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.sendMessageToolStripMenuItem.Text = "Send Message";
            this.sendMessageToolStripMenuItem.Click += new System.EventHandler(this.sendMessageToolStripMenuItem_Click);
            // 
            // masterToolStripMenuItem
            // 
            this.masterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reOpenClosePigmyAccountToolStripMenuItem,
            this.toolStripMenuItem13,
            this.enterAreaToolStripMenuItem1,
            this.enterAgentIdToolStripMenuItem1});
            this.masterToolStripMenuItem.Name = "masterToolStripMenuItem";
            this.masterToolStripMenuItem.Size = new System.Drawing.Size(70, 25);
            this.masterToolStripMenuItem.Text = "Master";
            // 
            // reOpenClosePigmyAccountToolStripMenuItem
            // 
            this.reOpenClosePigmyAccountToolStripMenuItem.Name = "reOpenClosePigmyAccountToolStripMenuItem";
            this.reOpenClosePigmyAccountToolStripMenuItem.Size = new System.Drawing.Size(298, 26);
            this.reOpenClosePigmyAccountToolStripMenuItem.Text = "Re-Open/Close Pigmy Account ";
            this.reOpenClosePigmyAccountToolStripMenuItem.Click += new System.EventHandler(this.reOpenClosePigmyAccountToolStripMenuItem_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(295, 6);
            // 
            // enterAreaToolStripMenuItem1
            // 
            this.enterAreaToolStripMenuItem1.Name = "enterAreaToolStripMenuItem1";
            this.enterAreaToolStripMenuItem1.Size = new System.Drawing.Size(298, 26);
            this.enterAreaToolStripMenuItem1.Text = "Enter Area";
            this.enterAreaToolStripMenuItem1.Click += new System.EventHandler(this.enterAreaToolStripMenuItem1_Click);
            // 
            // enterAgentIdToolStripMenuItem1
            // 
            this.enterAgentIdToolStripMenuItem1.Name = "enterAgentIdToolStripMenuItem1";
            this.enterAgentIdToolStripMenuItem1.Size = new System.Drawing.Size(298, 26);
            this.enterAgentIdToolStripMenuItem1.Text = "Enter Agent Id";
            this.enterAgentIdToolStripMenuItem1.Click += new System.EventHandler(this.enterAgentIdToolStripMenuItem1_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addUserToolStripMenuItem});
            this.helpToolStripMenuItem.Enabled = false;
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(68, 25);
            this.helpToolStripMenuItem.Text = "Admin";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // addUserToolStripMenuItem
            // 
            this.addUserToolStripMenuItem.Name = "addUserToolStripMenuItem";
            this.addUserToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.addUserToolStripMenuItem.Text = "Add User";
            this.addUserToolStripMenuItem.Click += new System.EventHandler(this.addUserToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contactInformationToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(64, 25);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // contactInformationToolStripMenuItem
            // 
            this.contactInformationToolStripMenuItem.Name = "contactInformationToolStripMenuItem";
            this.contactInformationToolStripMenuItem.Size = new System.Drawing.Size(219, 26);
            this.contactInformationToolStripMenuItem.Text = "Contact Information";
            this.contactInformationToolStripMenuItem.Click += new System.EventHandler(this.contactInformationToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(71, 25);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Copperplate Gothic Light", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label51.Location = new System.Drawing.Point(182, 90);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(692, 52);
            this.label51.TabIndex = 24;
            this.label51.Text = "Welcome to SDM Finance";
            this.label51.Click += new System.EventHandler(this.label51_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.button39);
            this.panel8.Controls.Add(this.date_bid);
            this.panel8.Controls.Add(this.txt_total_bid);
            this.panel8.Controls.Add(this.label56);
            this.panel8.Controls.Add(this.cmb_chit_bid);
            this.panel8.Controls.Add(this.cmb_amount_bid);
            this.panel8.Controls.Add(this.bIDDER);
            this.panel8.Controls.Add(this.button34);
            this.panel8.Controls.Add(this.txt_balance);
            this.panel8.Controls.Add(this.label54);
            this.panel8.Controls.Add(this.txt_bid_amount);
            this.panel8.Controls.Add(this.label64);
            this.panel8.Controls.Add(this.label63);
            this.panel8.Controls.Add(this.label53);
            this.panel8.Controls.Add(this.label55);
            this.panel8.Controls.Add(this.label52);
            this.panel8.Location = new System.Drawing.Point(326, 248);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(466, 313);
            this.panel8.TabIndex = 25;
            this.panel8.Visible = false;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // button39
            // 
            this.button39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.Location = new System.Drawing.Point(257, 270);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(104, 29);
            this.button39.TabIndex = 7;
            this.button39.Text = "Cancel";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // date_bid
            // 
            this.date_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_bid.Location = new System.Drawing.Point(192, 123);
            this.date_bid.Name = "date_bid";
            this.date_bid.Size = new System.Drawing.Size(236, 22);
            this.date_bid.TabIndex = 6;
            // 
            // txt_total_bid
            // 
            this.txt_total_bid.Enabled = false;
            this.txt_total_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total_bid.Location = new System.Drawing.Point(188, 226);
            this.txt_total_bid.Name = "txt_total_bid";
            this.txt_total_bid.Size = new System.Drawing.Size(241, 22);
            this.txt_total_bid.TabIndex = 5;
            this.txt_total_bid.Text = "0";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(23, 231);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(116, 16);
            this.label56.TabIndex = 4;
            this.label56.Text = "Bid Amount  Total:";
            // 
            // cmb_chit_bid
            // 
            this.cmb_chit_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_chit_bid.FormattingEnabled = true;
            this.cmb_chit_bid.Location = new System.Drawing.Point(189, 17);
            this.cmb_chit_bid.Name = "cmb_chit_bid";
            this.cmb_chit_bid.Size = new System.Drawing.Size(237, 24);
            this.cmb_chit_bid.TabIndex = 3;
            this.cmb_chit_bid.SelectedIndexChanged += new System.EventHandler(this.cmb_chit_bid_SelectedIndexChanged);
            // 
            // cmb_amount_bid
            // 
            this.cmb_amount_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_amount_bid.FormattingEnabled = true;
            this.cmb_amount_bid.Location = new System.Drawing.Point(191, 88);
            this.cmb_amount_bid.Name = "cmb_amount_bid";
            this.cmb_amount_bid.Size = new System.Drawing.Size(237, 24);
            this.cmb_amount_bid.TabIndex = 3;
            // 
            // bIDDER
            // 
            this.bIDDER.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bIDDER.FormattingEnabled = true;
            this.bIDDER.Location = new System.Drawing.Point(191, 51);
            this.bIDDER.Name = "bIDDER";
            this.bIDDER.Size = new System.Drawing.Size(237, 24);
            this.bIDDER.TabIndex = 3;
            this.bIDDER.SelectedIndexChanged += new System.EventHandler(this.bIDDER_SelectedIndexChanged);
            // 
            // button34
            // 
            this.button34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.Location = new System.Drawing.Point(80, 270);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(104, 29);
            this.button34.TabIndex = 2;
            this.button34.Text = "Bid";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // txt_balance
            // 
            this.txt_balance.Enabled = false;
            this.txt_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_balance.Location = new System.Drawing.Point(188, 194);
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.Size = new System.Drawing.Size(241, 22);
            this.txt_balance.TabIndex = 1;
            this.txt_balance.Text = "0";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(69, 197);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(58, 16);
            this.label54.TabIndex = 0;
            this.label54.Text = "Balance";
            // 
            // txt_bid_amount
            // 
            this.txt_bid_amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_bid_amount.Location = new System.Drawing.Point(189, 156);
            this.txt_bid_amount.Name = "txt_bid_amount";
            this.txt_bid_amount.Size = new System.Drawing.Size(241, 22);
            this.txt_bid_amount.TabIndex = 1;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(38, 127);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(108, 16);
            this.label64.TabIndex = 0;
            this.label64.Text = "Date Of Bidding :";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(4, 91);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(148, 16);
            this.label63.TabIndex = 0;
            this.label63.Text = "Chit Amount for Biddng :";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(85, 20);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(36, 16);
            this.label53.TabIndex = 0;
            this.label53.Text = "Chit :";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(32, 54);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(110, 16);
            this.label55.TabIndex = 0;
            this.label55.Text = "Name  Of Bidder:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(51, 161);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(82, 16);
            this.label52.TabIndex = 0;
            this.label52.Text = "Bid Amount :";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.button41);
            this.panel9.Controls.Add(this.button36);
            this.panel9.Controls.Add(this.button35);
            this.panel9.Controls.Add(this.groupBox6);
            this.panel9.Location = new System.Drawing.Point(219, 151);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(391, 486);
            this.panel9.TabIndex = 26;
            this.panel9.Visible = false;
            this.panel9.Paint += new System.Windows.Forms.PaintEventHandler(this.panel9_Paint);
            // 
            // button41
            // 
            this.button41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button41.Location = new System.Drawing.Point(39, 444);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(85, 26);
            this.button41.TabIndex = 10;
            this.button41.Text = "Refresh";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button36
            // 
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.Location = new System.Drawing.Point(248, 443);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(85, 26);
            this.button36.TabIndex = 16;
            this.button36.Text = "Exit";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button35
            // 
            this.button35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.Location = new System.Drawing.Point(146, 442);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(85, 26);
            this.button35.TabIndex = 11;
            this.button35.Text = "Save";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.cmb_id_loan);
            this.groupBox6.Controls.Add(this.label89);
            this.groupBox6.Controls.Add(this.label74);
            this.groupBox6.Controls.Add(this.label73);
            this.groupBox6.Controls.Add(this.Overdue);
            this.groupBox6.Controls.Add(this.label72);
            this.groupBox6.Controls.Add(this.textBox5);
            this.groupBox6.Controls.Add(this.label68);
            this.groupBox6.Controls.Add(this.label67);
            this.groupBox6.Controls.Add(this.textBox3);
            this.groupBox6.Controls.Add(this.cmb_name_exc);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.textBox2);
            this.groupBox6.Controls.Add(this.due_after);
            this.groupBox6.Controls.Add(this.label38);
            this.groupBox6.Controls.Add(this.label37);
            this.groupBox6.Controls.Add(this.txt_total);
            this.groupBox6.Controls.Add(this.txt_due_after);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label59);
            this.groupBox6.Controls.Add(this.label60);
            this.groupBox6.Controls.Add(this.textBox15);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(21, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(340, 413);
            this.groupBox6.TabIndex = 15;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Alert";
            // 
            // cmb_id_loan
            // 
            this.cmb_id_loan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_id_loan.FormattingEnabled = true;
            this.cmb_id_loan.Location = new System.Drawing.Point(55, 20);
            this.cmb_id_loan.Name = "cmb_id_loan";
            this.cmb_id_loan.Size = new System.Drawing.Size(253, 24);
            this.cmb_id_loan.TabIndex = 1;
            this.cmb_id_loan.SelectedIndexChanged += new System.EventHandler(this.cmb_id_loan_SelectedIndexChanged);
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(20, 20);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(22, 16);
            this.label89.TabIndex = 33;
            this.label89.Text = "Id:";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(264, 376);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(54, 16);
            this.label74.TabIndex = 32;
            this.label74.Text = "Percent";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(38, 137);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(65, 16);
            this.label73.TabIndex = 31;
            this.label73.Text = "Over Due";
            // 
            // Overdue
            // 
            this.Overdue.Enabled = false;
            this.Overdue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Overdue.Location = new System.Drawing.Point(146, 134);
            this.Overdue.Name = "Overdue";
            this.Overdue.Size = new System.Drawing.Size(103, 22);
            this.Overdue.TabIndex = 30;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(44, 376);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(107, 16);
            this.label72.TabIndex = 29;
            this.label72.Text = "Interest For Loan";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(171, 372);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(84, 22);
            this.textBox5.TabIndex = 9;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(260, 173);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(54, 16);
            this.label68.TabIndex = 27;
            this.label68.Text = "Percent";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label67.Location = new System.Drawing.Point(7, 338);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(165, 16);
            this.label67.TabIndex = 26;
            this.label67.Text = "Amount Given to Customer";
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(169, 335);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(139, 22);
            this.textBox3.TabIndex = 8;
            // 
            // cmb_name_exc
            // 
            this.cmb_name_exc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_name_exc.FormattingEnabled = true;
            this.cmb_name_exc.Location = new System.Drawing.Point(57, 51);
            this.cmb_name_exc.Name = "cmb_name_exc";
            this.cmb_name_exc.Size = new System.Drawing.Size(253, 24);
            this.cmb_name_exc.TabIndex = 2;
            this.cmb_name_exc.SelectedIndexChanged += new System.EventHandler(this.cmb_name_exc_SelectedIndexChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(40, 174);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(93, 16);
            this.label24.TabIndex = 23;
            this.label24.Text = "Interest Taken";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(148, 171);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(103, 22);
            this.textBox2.TabIndex = 3;
            // 
            // due_after
            // 
            this.due_after.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.due_after.Location = new System.Drawing.Point(105, 255);
            this.due_after.Name = "due_after";
            this.due_after.Size = new System.Drawing.Size(205, 22);
            this.due_after.TabIndex = 5;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(5, 214);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(85, 16);
            this.label38.TabIndex = 11;
            this.label38.Text = "Loan amount";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(68, 300);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(69, 16);
            this.label37.TabIndex = 11;
            this.label37.Text = "Total paid";
            this.label37.Visible = false;
            // 
            // txt_total
            // 
            this.txt_total.Enabled = false;
            this.txt_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total.Location = new System.Drawing.Point(174, 295);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(136, 22);
            this.txt_total.TabIndex = 7;
            this.txt_total.Text = "0";
            this.txt_total.Visible = false;
            // 
            // txt_due_after
            // 
            this.txt_due_after.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_due_after.Location = new System.Drawing.Point(103, 212);
            this.txt_due_after.Name = "txt_due_after";
            this.txt_due_after.Size = new System.Drawing.Size(207, 22);
            this.txt_due_after.TabIndex = 4;
            this.txt_due_after.TextChanged += new System.EventHandler(this.txt_due_after_TextChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(7, 54);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(48, 16);
            this.label25.TabIndex = 14;
            this.label25.Text = "Name:";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(23, 257);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(66, 16);
            this.label59.TabIndex = 14;
            this.label59.Text = "Paid date";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Red;
            this.label60.Location = new System.Drawing.Point(28, 82);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(264, 16);
            this.label60.TabIndex = 9;
            this.label60.Text = "Amount Exceded after loan amount finsihed";
            // 
            // textBox15
            // 
            this.textBox15.Enabled = false;
            this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.ForeColor = System.Drawing.Color.Red;
            this.textBox15.Location = new System.Drawing.Point(32, 107);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(278, 22);
            this.textBox15.TabIndex = 8;
            this.textBox15.Visible = false;
            this.textBox15.TextChanged += new System.EventHandler(this.textBox15_TextChanged);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.End_date_chit);
            this.panel10.Controls.Add(this.label33);
            this.panel10.Controls.Add(this.button37);
            this.panel10.Controls.Add(this.button38);
            this.panel10.Controls.Add(this.label61);
            this.panel10.Controls.Add(this.txt_Amount_total);
            this.panel10.Controls.Add(this.Start_date_chit);
            this.panel10.Controls.Add(this.label28);
            this.panel10.Location = new System.Drawing.Point(347, 177);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(379, 200);
            this.panel10.TabIndex = 27;
            this.panel10.Visible = false;
            // 
            // End_date_chit
            // 
            this.End_date_chit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.End_date_chit.Location = new System.Drawing.Point(155, 103);
            this.End_date_chit.Name = "End_date_chit";
            this.End_date_chit.Size = new System.Drawing.Size(204, 22);
            this.End_date_chit.TabIndex = 20;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(29, 106);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(58, 16);
            this.label33.TabIndex = 19;
            this.label33.Text = "End On :";
            // 
            // button37
            // 
            this.button37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button37.Location = new System.Drawing.Point(198, 147);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(96, 29);
            this.button37.TabIndex = 17;
            this.button37.Text = "Cancel";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button38.Location = new System.Drawing.Point(89, 148);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(96, 29);
            this.button38.TabIndex = 18;
            this.button38.Text = "Save";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(27, 21);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(118, 16);
            this.label61.TabIndex = 16;
            this.label61.Text = "Chit Total Amount :";
            // 
            // txt_Amount_total
            // 
            this.txt_Amount_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Amount_total.Location = new System.Drawing.Point(154, 17);
            this.txt_Amount_total.Name = "txt_Amount_total";
            this.txt_Amount_total.Size = new System.Drawing.Size(205, 22);
            this.txt_Amount_total.TabIndex = 15;
            // 
            // Start_date_chit
            // 
            this.Start_date_chit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Start_date_chit.Location = new System.Drawing.Point(155, 62);
            this.Start_date_chit.Name = "Start_date_chit";
            this.Start_date_chit.Size = new System.Drawing.Size(204, 22);
            this.Start_date_chit.TabIndex = 14;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(29, 65);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(77, 16);
            this.label28.TabIndex = 11;
            this.label28.Text = "Started On :";
            // 
            // txt_withdraw
            // 
            this.txt_withdraw.Location = new System.Drawing.Point(191, 93);
            this.txt_withdraw.Name = "txt_withdraw";
            this.txt_withdraw.Size = new System.Drawing.Size(223, 22);
            this.txt_withdraw.TabIndex = 3;
            // 
            // txt_withdraw_amount
            // 
            this.txt_withdraw_amount.Location = new System.Drawing.Point(193, 131);
            this.txt_withdraw_amount.Name = "txt_withdraw_amount";
            this.txt_withdraw_amount.Size = new System.Drawing.Size(223, 22);
            this.txt_withdraw_amount.TabIndex = 4;
            this.txt_withdraw_amount.Text = "0";
            // 
            // txt_total_taken
            // 
            this.txt_total_taken.Location = new System.Drawing.Point(196, 171);
            this.txt_total_taken.Name = "txt_total_taken";
            this.txt_total_taken.Size = new System.Drawing.Size(223, 22);
            this.txt_total_taken.TabIndex = 5;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(25, 95);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(156, 16);
            this.label29.TabIndex = 9;
            this.label29.Text = "Withdaw Amount Percent";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(28, 134);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(111, 16);
            this.label57.TabIndex = 9;
            this.label57.Text = "Withdraw Amount";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(31, 174);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(134, 16);
            this.label58.TabIndex = 9;
            this.label58.Text = "Amount Taken/Given";
            // 
            // button23
            // 
            this.button23.Enabled = false;
            this.button23.Location = new System.Drawing.Point(143, 386);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 23);
            this.button23.TabIndex = 10;
            this.button23.Text = "Withdraw";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button22_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(236, 387);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(83, 22);
            this.button22.TabIndex = 11;
            this.button22.Text = "Cancel";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click_1);
            // 
            // txt_profit
            // 
            this.txt_profit.Location = new System.Drawing.Point(196, 215);
            this.txt_profit.Name = "txt_profit";
            this.txt_profit.Size = new System.Drawing.Size(223, 22);
            this.txt_profit.TabIndex = 6;
            // 
            // txt_total_balance_with
            // 
            this.txt_total_balance_with.Enabled = false;
            this.txt_total_balance_with.Location = new System.Drawing.Point(196, 255);
            this.txt_total_balance_with.Name = "txt_total_balance_with";
            this.txt_total_balance_with.Size = new System.Drawing.Size(223, 22);
            this.txt_total_balance_with.TabIndex = 7;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(30, 219);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(129, 16);
            this.label66.TabIndex = 15;
            this.label66.Text = "Withdraw Profit/Loss";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label65.Location = new System.Drawing.Point(31, 258);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(98, 16);
            this.label65.TabIndex = 14;
            this.label65.Text = "Total Balance :";
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(51, 386);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(75, 23);
            this.button40.TabIndex = 9;
            this.button40.Text = "Refresh";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(30, 55);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(51, 16);
            this.label76.TabIndex = 17;
            this.label76.Text = "Name :";
            // 
            // Cmb_name_wd
            // 
            this.Cmb_name_wd.FormattingEnabled = true;
            this.Cmb_name_wd.Location = new System.Drawing.Point(193, 54);
            this.Cmb_name_wd.Name = "Cmb_name_wd";
            this.Cmb_name_wd.Size = new System.Drawing.Size(222, 24);
            this.Cmb_name_wd.TabIndex = 2;
            this.Cmb_name_wd.SelectedIndexChanged += new System.EventHandler(this.Cmb_name_wd_SelectedIndexChanged);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(30, 20);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(25, 16);
            this.label75.TabIndex = 19;
            this.label75.Text = "Id :";
            // 
            // Id
            // 
            this.Id.FormattingEnabled = true;
            this.Id.Location = new System.Drawing.Point(191, 16);
            this.Id.Name = "Id";
            this.Id.Size = new System.Drawing.Size(222, 24);
            this.Id.TabIndex = 1;
            this.Id.SelectedIndexChanged += new System.EventHandler(this.Id_SelectedIndexChanged);
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(196, 291);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(221, 22);
            this.dateTimePicker3.TabIndex = 8;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.lbl_duration);
            this.panel6.Controls.Add(this.label69);
            this.panel6.Controls.Add(this.dateTimePicker3);
            this.panel6.Controls.Add(this.Id);
            this.panel6.Controls.Add(this.label75);
            this.panel6.Controls.Add(this.Cmb_name_wd);
            this.panel6.Controls.Add(this.label76);
            this.panel6.Controls.Add(this.button40);
            this.panel6.Controls.Add(this.label65);
            this.panel6.Controls.Add(this.label66);
            this.panel6.Controls.Add(this.txt_total_balance_with);
            this.panel6.Controls.Add(this.txt_profit);
            this.panel6.Controls.Add(this.button22);
            this.panel6.Controls.Add(this.button23);
            this.panel6.Controls.Add(this.label58);
            this.panel6.Controls.Add(this.label57);
            this.panel6.Controls.Add(this.label29);
            this.panel6.Controls.Add(this.txt_total_taken);
            this.panel6.Controls.Add(this.txt_withdraw_amount);
            this.panel6.Controls.Add(this.txt_withdraw);
            this.panel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(293, 164);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(441, 439);
            this.panel6.TabIndex = 15;
            this.panel6.Visible = false;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // lbl_duration
            // 
            this.lbl_duration.AutoSize = true;
            this.lbl_duration.Location = new System.Drawing.Point(33, 329);
            this.lbl_duration.Name = "lbl_duration";
            this.lbl_duration.Size = new System.Drawing.Size(73, 16);
            this.lbl_duration.TabIndex = 28;
            this.lbl_duration.Text = "Date paid :";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(29, 291);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(73, 16);
            this.label69.TabIndex = 28;
            this.label69.Text = "Date paid :";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.button68);
            this.panel11.Controls.Add(this.date_show);
            this.panel11.Controls.Add(this.button43);
            this.panel11.Controls.Add(this.txt_id_up);
            this.panel11.Controls.Add(this.label79);
            this.panel11.Controls.Add(this.button42);
            this.panel11.Controls.Add(this.txt_name_update);
            this.panel11.Controls.Add(this.button45);
            this.panel11.Controls.Add(this.date_pd_up);
            this.panel11.Controls.Add(this.label80);
            this.panel11.Controls.Add(this.label77);
            this.panel11.Controls.Add(this.txt_amount_pd_up);
            this.panel11.Controls.Add(this.label78);
            this.panel11.Controls.Add(this.dataGridView1);
            this.panel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel11.Location = new System.Drawing.Point(49, 149);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(938, 491);
            this.panel11.TabIndex = 28;
            this.panel11.Visible = false;
            // 
            // button68
            // 
            this.button68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button68.Location = new System.Drawing.Point(475, 170);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(75, 23);
            this.button68.TabIndex = 57;
            this.button68.Text = "Delete";
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // date_show
            // 
            this.date_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_show.Location = new System.Drawing.Point(234, 429);
            this.date_show.Name = "date_show";
            this.date_show.Size = new System.Drawing.Size(190, 22);
            this.date_show.TabIndex = 56;
            // 
            // button43
            // 
            this.button43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button43.Location = new System.Drawing.Point(453, 428);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(75, 23);
            this.button43.TabIndex = 55;
            this.button43.Text = "Refresh";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // txt_id_up
            // 
            this.txt_id_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_up.Location = new System.Drawing.Point(373, 9);
            this.txt_id_up.Name = "txt_id_up";
            this.txt_id_up.Size = new System.Drawing.Size(183, 22);
            this.txt_id_up.TabIndex = 54;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(241, 10);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(25, 16);
            this.label79.TabIndex = 53;
            this.label79.Text = "Id :";
            // 
            // button42
            // 
            this.button42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button42.Location = new System.Drawing.Point(544, 428);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(75, 23);
            this.button42.TabIndex = 52;
            this.button42.Text = "Cancel";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click_1);
            // 
            // txt_name_update
            // 
            this.txt_name_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name_update.Location = new System.Drawing.Point(372, 48);
            this.txt_name_update.Name = "txt_name_update";
            this.txt_name_update.Size = new System.Drawing.Size(183, 22);
            this.txt_name_update.TabIndex = 51;
            // 
            // button45
            // 
            this.button45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button45.Location = new System.Drawing.Point(310, 170);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(75, 23);
            this.button45.TabIndex = 49;
            this.button45.Text = "Update";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // date_pd_up
            // 
            this.date_pd_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_pd_up.Location = new System.Drawing.Point(373, 90);
            this.date_pd_up.Name = "date_pd_up";
            this.date_pd_up.Size = new System.Drawing.Size(183, 22);
            this.date_pd_up.TabIndex = 47;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(239, 52);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(51, 16);
            this.label80.TabIndex = 45;
            this.label80.Text = "Name :";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(236, 92);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(67, 16);
            this.label77.TabIndex = 37;
            this.label77.Text = "Date paid";
            // 
            // txt_amount_pd_up
            // 
            this.txt_amount_pd_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_amount_pd_up.Location = new System.Drawing.Point(372, 133);
            this.txt_amount_pd_up.Name = "txt_amount_pd_up";
            this.txt_amount_pd_up.Size = new System.Drawing.Size(183, 22);
            this.txt_amount_pd_up.TabIndex = 36;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(234, 135);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(116, 16);
            this.label78.TabIndex = 38;
            this.label78.Text = "Amount to be paid";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn,
            this.datePaidDataGridViewTextBoxColumn,
            this.nextdateDataGridViewTextBoxColumn,
            this.totalDataGridViewTextBoxColumn,
            this.balanceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.loanCustomerBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(21, 204);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(879, 209);
            this.dataGridView1.TabIndex = 33;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseDoubleClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "Amount";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            this.amountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // datePaidDataGridViewTextBoxColumn
            // 
            this.datePaidDataGridViewTextBoxColumn.DataPropertyName = "Date_Paid";
            this.datePaidDataGridViewTextBoxColumn.HeaderText = "Date_Paid";
            this.datePaidDataGridViewTextBoxColumn.Name = "datePaidDataGridViewTextBoxColumn";
            this.datePaidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nextdateDataGridViewTextBoxColumn
            // 
            this.nextdateDataGridViewTextBoxColumn.DataPropertyName = "Next_date";
            this.nextdateDataGridViewTextBoxColumn.HeaderText = "Next_date";
            this.nextdateDataGridViewTextBoxColumn.Name = "nextdateDataGridViewTextBoxColumn";
            this.nextdateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // totalDataGridViewTextBoxColumn
            // 
            this.totalDataGridViewTextBoxColumn.DataPropertyName = "Total";
            this.totalDataGridViewTextBoxColumn.HeaderText = "Total";
            this.totalDataGridViewTextBoxColumn.Name = "totalDataGridViewTextBoxColumn";
            this.totalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // balanceDataGridViewTextBoxColumn
            // 
            this.balanceDataGridViewTextBoxColumn.DataPropertyName = "Balance";
            this.balanceDataGridViewTextBoxColumn.HeaderText = "Balance";
            this.balanceDataGridViewTextBoxColumn.Name = "balanceDataGridViewTextBoxColumn";
            this.balanceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // loanCustomerBindingSource2
            // 
            this.loanCustomerBindingSource2.DataMember = "Loan_Customer";
            this.loanCustomerBindingSource2.DataSource = this.sDM_GroupDataSet3;
            // 
            // sDM_GroupDataSet3
            // 
            this.sDM_GroupDataSet3.DataSetName = "SDM_GroupDataSet3";
            this.sDM_GroupDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sDM_GroupDataSet1
            // 
            this.sDM_GroupDataSet1.DataSetName = "SDM_GroupDataSet1";
            this.sDM_GroupDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loanCustomerBindingSource
            // 
            this.loanCustomerBindingSource.DataMember = "Loan_Customer";
            this.loanCustomerBindingSource.DataSource = this.sDM_GroupDataSet1;
            // 
            // loan_CustomerTableAdapter
            // 
            this.loan_CustomerTableAdapter.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet2
            // 
            this.sDM_GroupDataSet2.DataSetName = "SDM_GroupDataSet2";
            this.sDM_GroupDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loanCustomerBindingSource1
            // 
            this.loanCustomerBindingSource1.DataMember = "Loan_Customer";
            this.loanCustomerBindingSource1.DataSource = this.sDM_GroupDataSet2;
            // 
            // loan_CustomerTableAdapter1
            // 
            this.loan_CustomerTableAdapter1.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet4
            // 
            this.sDM_GroupDataSet4.DataSetName = "SDM_GroupDataSet4";
            this.sDM_GroupDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loanCustomerBindingSource3
            // 
            this.loanCustomerBindingSource3.DataMember = "Loan_Customer";
            this.loanCustomerBindingSource3.DataSource = this.sDM_GroupDataSet4;
            // 
            // loan_CustomerTableAdapter3
            // 
            this.loan_CustomerTableAdapter3.ClearBeforeFill = true;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.button69);
            this.panel12.Controls.Add(this.date_now);
            this.panel12.Controls.Add(this.button44);
            this.panel12.Controls.Add(this.txt_id_up_pig);
            this.panel12.Controls.Add(this.label81);
            this.panel12.Controls.Add(this.button46);
            this.panel12.Controls.Add(this.txt_name_pig_up);
            this.panel12.Controls.Add(this.button47);
            this.panel12.Controls.Add(this.date_pd_pig);
            this.panel12.Controls.Add(this.label82);
            this.panel12.Controls.Add(this.label83);
            this.panel12.Controls.Add(this.txt_pig_amount_up);
            this.panel12.Controls.Add(this.label84);
            this.panel12.Controls.Add(this.dataGridView2);
            this.panel12.Location = new System.Drawing.Point(49, 154);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(938, 491);
            this.panel12.TabIndex = 29;
            this.panel12.Visible = false;
            // 
            // button69
            // 
            this.button69.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button69.Location = new System.Drawing.Point(566, 175);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(75, 23);
            this.button69.TabIndex = 58;
            this.button69.Text = "Delete";
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // date_now
            // 
            this.date_now.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_now.Location = new System.Drawing.Point(298, 445);
            this.date_now.Name = "date_now";
            this.date_now.Size = new System.Drawing.Size(190, 22);
            this.date_now.TabIndex = 57;
            this.date_now.ValueChanged += new System.EventHandler(this.date_now_ValueChanged);
            // 
            // button44
            // 
            this.button44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button44.Location = new System.Drawing.Point(503, 443);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(84, 28);
            this.button44.TabIndex = 55;
            this.button44.Text = "Refresh";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click_1);
            // 
            // txt_id_up_pig
            // 
            this.txt_id_up_pig.Enabled = false;
            this.txt_id_up_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_up_pig.Location = new System.Drawing.Point(439, 15);
            this.txt_id_up_pig.Name = "txt_id_up_pig";
            this.txt_id_up_pig.Size = new System.Drawing.Size(183, 22);
            this.txt_id_up_pig.TabIndex = 54;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(302, 16);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(25, 16);
            this.label81.TabIndex = 53;
            this.label81.Text = "Id :";
            // 
            // button46
            // 
            this.button46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button46.Location = new System.Drawing.Point(594, 443);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(84, 28);
            this.button46.TabIndex = 52;
            this.button46.Text = "Cancel";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // txt_name_pig_up
            // 
            this.txt_name_pig_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name_pig_up.Location = new System.Drawing.Point(438, 54);
            this.txt_name_pig_up.Name = "txt_name_pig_up";
            this.txt_name_pig_up.Size = new System.Drawing.Size(183, 22);
            this.txt_name_pig_up.TabIndex = 51;
            // 
            // button47
            // 
            this.button47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button47.Location = new System.Drawing.Point(395, 176);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(75, 23);
            this.button47.TabIndex = 49;
            this.button47.Text = "Update";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // date_pd_pig
            // 
            this.date_pd_pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_pd_pig.Location = new System.Drawing.Point(439, 96);
            this.date_pd_pig.Name = "date_pd_pig";
            this.date_pd_pig.Size = new System.Drawing.Size(183, 22);
            this.date_pd_pig.TabIndex = 47;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(300, 58);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(51, 16);
            this.label82.TabIndex = 45;
            this.label82.Text = "Name :";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(297, 98);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(67, 16);
            this.label83.TabIndex = 37;
            this.label83.Text = "Date paid";
            // 
            // txt_pig_amount_up
            // 
            this.txt_pig_amount_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pig_amount_up.Location = new System.Drawing.Point(438, 139);
            this.txt_pig_amount_up.Name = "txt_pig_amount_up";
            this.txt_pig_amount_up.Size = new System.Drawing.Size(183, 22);
            this.txt_pig_amount_up.TabIndex = 36;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(295, 141);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(116, 16);
            this.label84.TabIndex = 38;
            this.label84.Text = "Amount to be paid";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.nameDataGridViewTextBoxColumn1,
            this.amountpaidDataGridViewTextBoxColumn,
            this.datepaidDataGridViewTextBoxColumn1,
            this.totalDataGridViewTextBoxColumn1,
            this.balanceDataGridViewTextBoxColumn1,
            this.withdrawalDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.piggyCustomerBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(30, 204);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(870, 209);
            this.dataGridView2.TabIndex = 33;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.dataGridView2.DoubleClick += new System.EventHandler(this.dataGridView2_DoubleClick);
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            this.nameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // amountpaidDataGridViewTextBoxColumn
            // 
            this.amountpaidDataGridViewTextBoxColumn.DataPropertyName = "Amount_paid";
            this.amountpaidDataGridViewTextBoxColumn.HeaderText = "Amount_paid";
            this.amountpaidDataGridViewTextBoxColumn.Name = "amountpaidDataGridViewTextBoxColumn";
            this.amountpaidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // datepaidDataGridViewTextBoxColumn1
            // 
            this.datepaidDataGridViewTextBoxColumn1.DataPropertyName = "Date_paid";
            this.datepaidDataGridViewTextBoxColumn1.HeaderText = "Date_paid";
            this.datepaidDataGridViewTextBoxColumn1.Name = "datepaidDataGridViewTextBoxColumn1";
            this.datepaidDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // totalDataGridViewTextBoxColumn1
            // 
            this.totalDataGridViewTextBoxColumn1.DataPropertyName = "Total";
            this.totalDataGridViewTextBoxColumn1.HeaderText = "Total";
            this.totalDataGridViewTextBoxColumn1.Name = "totalDataGridViewTextBoxColumn1";
            this.totalDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // balanceDataGridViewTextBoxColumn1
            // 
            this.balanceDataGridViewTextBoxColumn1.DataPropertyName = "Balance";
            this.balanceDataGridViewTextBoxColumn1.HeaderText = "Balance";
            this.balanceDataGridViewTextBoxColumn1.Name = "balanceDataGridViewTextBoxColumn1";
            this.balanceDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // withdrawalDataGridViewTextBoxColumn
            // 
            this.withdrawalDataGridViewTextBoxColumn.DataPropertyName = "Withdrawal";
            this.withdrawalDataGridViewTextBoxColumn.HeaderText = "Withdrawal";
            this.withdrawalDataGridViewTextBoxColumn.Name = "withdrawalDataGridViewTextBoxColumn";
            this.withdrawalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // piggyCustomerBindingSource
            // 
            this.piggyCustomerBindingSource.DataMember = "Piggy_Customer";
            this.piggyCustomerBindingSource.DataSource = this.sDM_GroupDataSet5;
            // 
            // sDM_GroupDataSet5
            // 
            this.sDM_GroupDataSet5.DataSetName = "SDM_GroupDataSet5";
            this.sDM_GroupDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // piggy_CustomerTableAdapter
            // 
            this.piggy_CustomerTableAdapter.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet6
            // 
            this.sDM_GroupDataSet6.DataSetName = "SDM_GroupDataSet6";
            this.sDM_GroupDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // piggyCustomerBindingSource1
            // 
            this.piggyCustomerBindingSource1.DataMember = "Piggy_Customer";
            this.piggyCustomerBindingSource1.DataSource = this.sDM_GroupDataSet6;
            // 
            // piggy_CustomerTableAdapter1
            // 
            this.piggy_CustomerTableAdapter1.ClearBeforeFill = true;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.button48);
            this.panel13.Controls.Add(this.button49);
            this.panel13.Controls.Add(this.label88);
            this.panel13.Controls.Add(this.label87);
            this.panel13.Controls.Add(this.txt_area);
            this.panel13.Location = new System.Drawing.Point(338, 291);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(371, 138);
            this.panel13.TabIndex = 30;
            this.panel13.Visible = false;
            this.panel13.Paint += new System.Windows.Forms.PaintEventHandler(this.panel13_Paint);
            // 
            // button48
            // 
            this.button48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button48.Location = new System.Drawing.Point(252, 97);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(69, 26);
            this.button48.TabIndex = 11;
            this.button48.Text = "Cancel";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button49
            // 
            this.button49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button49.Location = new System.Drawing.Point(96, 94);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(69, 26);
            this.button49.TabIndex = 12;
            this.button49.Text = "Save";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(148, 24);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(98, 16);
            this.label88.TabIndex = 10;
            this.label88.Text = "Enter The Area";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(39, 55);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(37, 16);
            this.label87.TabIndex = 9;
            this.label87.Text = "Area";
            // 
            // txt_area
            // 
            this.txt_area.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_area.Location = new System.Drawing.Point(83, 52);
            this.txt_area.Name = "txt_area";
            this.txt_area.Size = new System.Drawing.Size(266, 22);
            this.txt_area.TabIndex = 8;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.groupBox15);
            this.groupBox14.Controls.Add(this.groupBox16);
            this.groupBox14.Controls.Add(this.radioButton12);
            this.groupBox14.Controls.Add(this.groupBox17);
            this.groupBox14.Controls.Add(this.radioButton13);
            this.groupBox14.Controls.Add(this.radioButton14);
            this.groupBox14.Controls.Add(this.button50);
            this.groupBox14.Controls.Add(this.label90);
            this.groupBox14.Controls.Add(this.label91);
            this.groupBox14.Controls.Add(this.dateTimePicker4);
            this.groupBox14.Controls.Add(this.dateTimePicker5);
            this.groupBox14.Controls.Add(this.button51);
            this.groupBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.Location = new System.Drawing.Point(253, 191);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(488, 406);
            this.groupBox14.TabIndex = 33;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "                                             ";
            this.groupBox14.Visible = false;
            this.groupBox14.Enter += new System.EventHandler(this.groupBox14_Enter);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.radioButton9);
            this.groupBox15.Controls.Add(this.radioButton10);
            this.groupBox15.Controls.Add(this.radioButton11);
            this.groupBox15.Location = new System.Drawing.Point(22, 121);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(436, 63);
            this.groupBox15.TabIndex = 22;
            this.groupBox15.TabStop = false;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(306, 23);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(109, 20);
            this.radioButton9.TabIndex = 16;
            this.radioButton9.Text = "Piggy_Report";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(165, 22);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(92, 20);
            this.radioButton10.TabIndex = 17;
            this.radioButton10.Text = "Chit Report";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.Visible = false;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Checked = true;
            this.radioButton11.Location = new System.Drawing.Point(24, 24);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(100, 20);
            this.radioButton11.TabIndex = 18;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "Loan Report";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.cmb_area_all);
            this.groupBox16.Location = new System.Drawing.Point(29, 280);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(428, 55);
            this.groupBox16.TabIndex = 21;
            this.groupBox16.TabStop = false;
            this.groupBox16.Visible = false;
            // 
            // cmb_area_all
            // 
            this.cmb_area_all.FormattingEnabled = true;
            this.cmb_area_all.Location = new System.Drawing.Point(9, 19);
            this.cmb_area_all.Name = "cmb_area_all";
            this.cmb_area_all.Size = new System.Drawing.Size(410, 24);
            this.cmb_area_all.TabIndex = 29;
            this.cmb_area_all.SelectedIndexChanged += new System.EventHandler(this.cmb_area_all_SelectedIndexChanged);
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(348, 199);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(55, 20);
            this.radioButton12.TabIndex = 20;
            this.radioButton12.Text = "Area";
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton12_CheckedChanged);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.cmb_trade_rep);
            this.groupBox17.Controls.Add(this.cmb_all_name);
            this.groupBox17.Controls.Add(this.cmb_id_all);
            this.groupBox17.Location = new System.Drawing.Point(29, 224);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(429, 50);
            this.groupBox17.TabIndex = 18;
            this.groupBox17.TabStop = false;
            this.groupBox17.Visible = false;
            // 
            // cmb_trade_rep
            // 
            this.cmb_trade_rep.FormattingEnabled = true;
            this.cmb_trade_rep.Location = new System.Drawing.Point(173, 18);
            this.cmb_trade_rep.Name = "cmb_trade_rep";
            this.cmb_trade_rep.Size = new System.Drawing.Size(127, 24);
            this.cmb_trade_rep.TabIndex = 23;
            // 
            // cmb_all_name
            // 
            this.cmb_all_name.FormattingEnabled = true;
            this.cmb_all_name.Location = new System.Drawing.Point(12, 19);
            this.cmb_all_name.Name = "cmb_all_name";
            this.cmb_all_name.Size = new System.Drawing.Size(148, 24);
            this.cmb_all_name.TabIndex = 22;
            this.cmb_all_name.SelectedIndexChanged += new System.EventHandler(this.cmb_all_name_SelectedIndexChanged);
            // 
            // cmb_id_all
            // 
            this.cmb_id_all.FormattingEnabled = true;
            this.cmb_id_all.Location = new System.Drawing.Point(316, 17);
            this.cmb_id_all.Name = "cmb_id_all";
            this.cmb_id_all.Size = new System.Drawing.Size(107, 24);
            this.cmb_id_all.TabIndex = 21;
            this.cmb_id_all.SelectedIndexChanged += new System.EventHandler(this.cmb_id_all_SelectedIndexChanged);
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Checked = true;
            this.radioButton13.Location = new System.Drawing.Point(42, 199);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(63, 20);
            this.radioButton13.TabIndex = 17;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "Group";
            this.radioButton13.UseVisualStyleBackColor = true;
            this.radioButton13.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged);
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(188, 199);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(80, 20);
            this.radioButton14.TabIndex = 16;
            this.radioButton14.Text = "Personal";
            this.radioButton14.UseVisualStyleBackColor = true;
            this.radioButton14.CheckedChanged += new System.EventHandler(this.radioButton14_CheckedChanged);
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(284, 354);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(135, 35);
            this.button50.TabIndex = 14;
            this.button50.Text = "Exit";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(46, 31);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(39, 16);
            this.label90.TabIndex = 13;
            this.label90.Text = "From";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(51, 80);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(25, 16);
            this.label91.TabIndex = 12;
            this.label91.Text = "To";
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(145, 82);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(224, 22);
            this.dateTimePicker4.TabIndex = 11;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Location = new System.Drawing.Point(144, 31);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(224, 22);
            this.dateTimePicker5.TabIndex = 11;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(82, 352);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(135, 35);
            this.button51.TabIndex = 10;
            this.button51.Text = "Generate Report";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.txt_agenrt_name);
            this.panel14.Controls.Add(this.label98);
            this.panel14.Controls.Add(this.button52);
            this.panel14.Controls.Add(this.button53);
            this.panel14.Controls.Add(this.label92);
            this.panel14.Controls.Add(this.label93);
            this.panel14.Controls.Add(this.txt_Agent);
            this.panel14.Location = new System.Drawing.Point(335, 226);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(450, 186);
            this.panel14.TabIndex = 34;
            this.panel14.Visible = false;
            this.panel14.Paint += new System.Windows.Forms.PaintEventHandler(this.panel14_Paint);
            // 
            // txt_agenrt_name
            // 
            this.txt_agenrt_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_agenrt_name.Location = new System.Drawing.Point(127, 55);
            this.txt_agenrt_name.Name = "txt_agenrt_name";
            this.txt_agenrt_name.Size = new System.Drawing.Size(266, 22);
            this.txt_agenrt_name.TabIndex = 15;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(10, 61);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(89, 16);
            this.label98.TabIndex = 14;
            this.label98.Text = "Agent Name :";
            // 
            // button52
            // 
            this.button52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button52.Location = new System.Drawing.Point(295, 143);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(69, 26);
            this.button52.TabIndex = 11;
            this.button52.Text = "Cancel";
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // button53
            // 
            this.button53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button53.Location = new System.Drawing.Point(139, 140);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(69, 26);
            this.button53.TabIndex = 12;
            this.button53.Text = "Save";
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(148, 24);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(118, 16);
            this.label92.TabIndex = 10;
            this.label92.Text = "Enter The Agent Id";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(30, 95);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(60, 16);
            this.label93.TabIndex = 9;
            this.label93.Text = "Agent Id:";
            // 
            // txt_Agent
            // 
            this.txt_Agent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Agent.Location = new System.Drawing.Point(126, 92);
            this.txt_Agent.MaxLength = 3;
            this.txt_Agent.Name = "txt_Agent";
            this.txt_Agent.Size = new System.Drawing.Size(266, 22);
            this.txt_Agent.TabIndex = 8;
            this.txt_Agent.TextChanged += new System.EventHandler(this.txt_Agent_TextChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txt_Nominee_aadress_Busioness);
            this.panel1.Controls.Add(this.txt_Nominee_aadress);
            this.panel1.Controls.Add(this.txt_Nominee_rel);
            this.panel1.Controls.Add(this.txt_Nominee_Age);
            this.panel1.Controls.Add(this.txt_Nominee);
            this.panel1.Controls.Add(this.date_end);
            this.panel1.Controls.Add(this.label128);
            this.panel1.Controls.Add(this.Amt);
            this.panel1.Controls.Add(this.label109);
            this.panel1.Controls.Add(this.txt_application_number);
            this.panel1.Controls.Add(this.label108);
            this.panel1.Controls.Add(this.txt_id);
            this.panel1.Controls.Add(this.cmb_agend_id_loan);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.Area_Combox_Pig);
            this.panel1.Controls.Add(this.label85);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.Date_Started);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label132);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.label131);
            this.panel1.Controls.Add(this.label130);
            this.panel1.Controls.Add(this.Customer);
            this.panel1.Controls.Add(this.txt_phone);
            this.panel1.Controls.Add(this.txt_Cutomer_name);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label151);
            this.panel1.Controls.Add(this.label129);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txt_Interest);
            this.panel1.Controls.Add(this.txt_Loan_Amt);
            this.panel1.Controls.Add(this.txt_trade);
            this.panel1.Controls.Add(this.txt_Address);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(142, 148);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(781, 625);
            this.panel1.TabIndex = 37;
            this.panel1.Visible = false;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // txt_Nominee_aadress_Busioness
            // 
            this.txt_Nominee_aadress_Busioness.Location = new System.Drawing.Point(558, 222);
            this.txt_Nominee_aadress_Busioness.Multiline = true;
            this.txt_Nominee_aadress_Busioness.Name = "txt_Nominee_aadress_Busioness";
            this.txt_Nominee_aadress_Busioness.Size = new System.Drawing.Size(206, 96);
            this.txt_Nominee_aadress_Busioness.TabIndex = 108;
            // 
            // txt_Nominee_aadress
            // 
            this.txt_Nominee_aadress.Location = new System.Drawing.Point(558, 115);
            this.txt_Nominee_aadress.Multiline = true;
            this.txt_Nominee_aadress.Name = "txt_Nominee_aadress";
            this.txt_Nominee_aadress.Size = new System.Drawing.Size(206, 96);
            this.txt_Nominee_aadress.TabIndex = 108;
            // 
            // txt_Nominee_rel
            // 
            this.txt_Nominee_rel.Location = new System.Drawing.Point(558, 333);
            this.txt_Nominee_rel.Name = "txt_Nominee_rel";
            this.txt_Nominee_rel.Size = new System.Drawing.Size(206, 22);
            this.txt_Nominee_rel.TabIndex = 108;
            // 
            // txt_Nominee_Age
            // 
            this.txt_Nominee_Age.AcceptsReturn = true;
            this.txt_Nominee_Age.Location = new System.Drawing.Point(558, 65);
            this.txt_Nominee_Age.Name = "txt_Nominee_Age";
            this.txt_Nominee_Age.Size = new System.Drawing.Size(206, 22);
            this.txt_Nominee_Age.TabIndex = 108;
            // 
            // txt_Nominee
            // 
            this.txt_Nominee.Location = new System.Drawing.Point(558, 35);
            this.txt_Nominee.Name = "txt_Nominee";
            this.txt_Nominee.Size = new System.Drawing.Size(206, 22);
            this.txt_Nominee.TabIndex = 108;
            // 
            // date_end
            // 
            this.date_end.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_end.Location = new System.Drawing.Point(165, 489);
            this.date_end.Name = "date_end";
            this.date_end.Size = new System.Drawing.Size(204, 22);
            this.date_end.TabIndex = 107;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.Location = new System.Drawing.Point(12, 492);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(70, 16);
            this.label128.TabIndex = 106;
            this.label128.Text = "End Date :";
            // 
            // Amt
            // 
            this.Amt.AutoSize = true;
            this.Amt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Amt.ForeColor = System.Drawing.Color.Blue;
            this.Amt.Location = new System.Drawing.Point(347, 530);
            this.Amt.Name = "Amt";
            this.Amt.Size = new System.Drawing.Size(201, 16);
            this.Amt.TabIndex = 105;
            this.Amt.Text = "Amount to be Givent to Customer";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(8, 43);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(132, 16);
            this.label109.TabIndex = 104;
            this.label109.Text = "Application Number :";
            // 
            // txt_application_number
            // 
            this.txt_application_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_application_number.Location = new System.Drawing.Point(160, 40);
            this.txt_application_number.Name = "txt_application_number";
            this.txt_application_number.Size = new System.Drawing.Size(206, 22);
            this.txt_application_number.TabIndex = 103;
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(319, 455);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(54, 16);
            this.label108.TabIndex = 102;
            this.label108.Text = "Percent";
            // 
            // txt_id
            // 
            this.txt_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id.Location = new System.Drawing.Point(161, 7);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(206, 22);
            this.txt_id.TabIndex = 101;
            this.txt_id.Visible = false;
            // 
            // cmb_agend_id_loan
            // 
            this.cmb_agend_id_loan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_agend_id_loan.FormattingEnabled = true;
            this.cmb_agend_id_loan.Location = new System.Drawing.Point(162, 341);
            this.cmb_agend_id_loan.Name = "cmb_agend_id_loan";
            this.cmb_agend_id_loan.Size = new System.Drawing.Size(205, 24);
            this.cmb_agend_id_loan.TabIndex = 93;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(13, 346);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 16);
            this.label19.TabIndex = 100;
            this.label19.Text = "Agent :";
            // 
            // Area_Combox_Pig
            // 
            this.Area_Combox_Pig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Area_Combox_Pig.FormattingEnabled = true;
            this.Area_Combox_Pig.Location = new System.Drawing.Point(161, 300);
            this.Area_Combox_Pig.Name = "Area_Combox_Pig";
            this.Area_Combox_Pig.Size = new System.Drawing.Size(205, 24);
            this.Area_Combox_Pig.TabIndex = 87;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(18, 303);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(37, 16);
            this.label85.TabIndex = 99;
            this.label85.Text = "Area";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(500, 576);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(96, 29);
            this.button4.TabIndex = 98;
            this.button4.Text = "Cancel";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(235, 575);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(96, 29);
            this.button3.TabIndex = 97;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Date_Started
            // 
            this.Date_Started.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Date_Started.Location = new System.Drawing.Point(162, 414);
            this.Date_Started.Name = "Date_Started";
            this.Date_Started.Size = new System.Drawing.Size(204, 22);
            this.Date_Started.TabIndex = 95;
            this.Date_Started.ValueChanged += new System.EventHandler(this.Date_Started_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(11, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 16);
            this.label6.TabIndex = 83;
            this.label6.Text = "Phone :";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.Location = new System.Drawing.Point(393, 72);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(97, 16);
            this.label132.TabIndex = 85;
            this.label132.Text = "Nominee Age :";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(21, 13);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(25, 16);
            this.label34.TabIndex = 84;
            this.label34.Text = "Id :";
            this.label34.Visible = false;
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label131.Location = new System.Drawing.Point(396, 36);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(69, 16);
            this.label131.TabIndex = 85;
            this.label131.Text = "Nominee :";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label130.Location = new System.Drawing.Point(393, 334);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(119, 16);
            this.label130.TabIndex = 85;
            this.label130.Text = "Nominee Relation:";
            // 
            // Customer
            // 
            this.Customer.AutoSize = true;
            this.Customer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customer.Location = new System.Drawing.Point(12, 80);
            this.Customer.Name = "Customer";
            this.Customer.Size = new System.Drawing.Size(71, 16);
            this.Customer.TabIndex = 85;
            this.Customer.Text = "Customer :";
            // 
            // txt_phone
            // 
            this.txt_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_phone.Location = new System.Drawing.Point(161, 226);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(206, 22);
            this.txt_phone.TabIndex = 82;
            // 
            // txt_Cutomer_name
            // 
            this.txt_Cutomer_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cutomer_name.Location = new System.Drawing.Point(161, 75);
            this.txt_Cutomer_name.Name = "txt_Cutomer_name";
            this.txt_Cutomer_name.Size = new System.Drawing.Size(206, 22);
            this.txt_Cutomer_name.TabIndex = 80;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 417);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 16);
            this.label3.TabIndex = 88;
            this.label3.Text = "Started On :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(9, 455);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 16);
            this.label7.TabIndex = 89;
            this.label7.Text = "Interest Taken";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 383);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 16);
            this.label8.TabIndex = 90;
            this.label8.Text = "Loan Amount given:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 16);
            this.label5.TabIndex = 91;
            this.label5.Text = "Trade Name :";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label151.Location = new System.Drawing.Point(391, 119);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(163, 16);
            this.label151.TabIndex = 92;
            this.label151.Text = "Nominee Home Address :";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label129.Location = new System.Drawing.Point(380, 225);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(181, 16);
            this.label129.TabIndex = 92;
            this.label129.Text = "Nominee Business Address :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 16);
            this.label4.TabIndex = 92;
            this.label4.Text = "Address :";
            // 
            // txt_Interest
            // 
            this.txt_Interest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Interest.Location = new System.Drawing.Point(163, 452);
            this.txt_Interest.Name = "txt_Interest";
            this.txt_Interest.Size = new System.Drawing.Size(155, 22);
            this.txt_Interest.TabIndex = 96;
            // 
            // txt_Loan_Amt
            // 
            this.txt_Loan_Amt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Loan_Amt.Location = new System.Drawing.Point(161, 379);
            this.txt_Loan_Amt.Name = "txt_Loan_Amt";
            this.txt_Loan_Amt.Size = new System.Drawing.Size(205, 22);
            this.txt_Loan_Amt.TabIndex = 94;
            // 
            // txt_trade
            // 
            this.txt_trade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_trade.Location = new System.Drawing.Point(161, 262);
            this.txt_trade.Name = "txt_trade";
            this.txt_trade.Size = new System.Drawing.Size(206, 22);
            this.txt_trade.TabIndex = 86;
            // 
            // txt_Address
            // 
            this.txt_Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Address.Location = new System.Drawing.Point(161, 118);
            this.txt_Address.Multiline = true;
            this.txt_Address.Name = "txt_Address";
            this.txt_Address.Size = new System.Drawing.Size(206, 96);
            this.txt_Address.TabIndex = 81;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label103);
            this.panel15.Controls.Add(this.cmb_id_pay);
            this.panel15.Controls.Add(this.radioButton17);
            this.panel15.Controls.Add(this.radioButton16);
            this.panel15.Controls.Add(this.label102);
            this.panel15.Controls.Add(this.label101);
            this.panel15.Controls.Add(this.label100);
            this.panel15.Controls.Add(this.label99);
            this.panel15.Controls.Add(this.cmb_trade_pay);
            this.panel15.Controls.Add(this.cmb_Name_pay);
            this.panel15.Controls.Add(this.dateTimePicker6);
            this.panel15.Controls.Add(this.button55);
            this.panel15.Controls.Add(this.button54);
            this.panel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel15.Location = new System.Drawing.Point(231, 224);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(530, 267);
            this.panel15.TabIndex = 38;
            this.panel15.Visible = false;
            this.panel15.Paint += new System.Windows.Forms.PaintEventHandler(this.panel15_Paint_1);
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(44, 160);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(25, 16);
            this.label103.TabIndex = 17;
            this.label103.Text = "Id :";
            // 
            // cmb_id_pay
            // 
            this.cmb_id_pay.FormattingEnabled = true;
            this.cmb_id_pay.Location = new System.Drawing.Point(147, 157);
            this.cmb_id_pay.Name = "cmb_id_pay";
            this.cmb_id_pay.Size = new System.Drawing.Size(286, 24);
            this.cmb_id_pay.TabIndex = 16;
            this.cmb_id_pay.SelectedIndexChanged += new System.EventHandler(this.cmb_id_pay_SelectedIndexChanged);
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Checked = true;
            this.radioButton17.Location = new System.Drawing.Point(148, 192);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(56, 20);
            this.radioButton17.TabIndex = 15;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "Loan";
            this.radioButton17.UseVisualStyleBackColor = true;
            this.radioButton17.CheckedChanged += new System.EventHandler(this.radioButton17_CheckedChanged);
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(347, 195);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(98, 20);
            this.radioButton16.TabIndex = 14;
            this.radioButton16.Text = "Pigmy Bank";
            this.radioButton16.UseVisualStyleBackColor = true;
            this.radioButton16.CheckedChanged += new System.EventHandler(this.radioButton16_CheckedChanged);
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(229, 14);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(115, 16);
            this.label102.TabIndex = 12;
            this.label102.Text = "Check Payment";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(44, 88);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(51, 16);
            this.label101.TabIndex = 11;
            this.label101.Text = "Name :";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(44, 123);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(91, 16);
            this.label100.TabIndex = 11;
            this.label100.Text = "Trade Name :";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(43, 57);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(43, 16);
            this.label99.TabIndex = 10;
            this.label99.Text = "Date :";
            // 
            // cmb_trade_pay
            // 
            this.cmb_trade_pay.FormattingEnabled = true;
            this.cmb_trade_pay.Location = new System.Drawing.Point(147, 120);
            this.cmb_trade_pay.Name = "cmb_trade_pay";
            this.cmb_trade_pay.Size = new System.Drawing.Size(286, 24);
            this.cmb_trade_pay.TabIndex = 9;
            this.cmb_trade_pay.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // cmb_Name_pay
            // 
            this.cmb_Name_pay.FormattingEnabled = true;
            this.cmb_Name_pay.Location = new System.Drawing.Point(148, 86);
            this.cmb_Name_pay.Name = "cmb_Name_pay";
            this.cmb_Name_pay.Size = new System.Drawing.Size(286, 24);
            this.cmb_Name_pay.TabIndex = 8;
            this.cmb_Name_pay.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.Location = new System.Drawing.Point(150, 50);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(286, 22);
            this.dateTimePicker6.TabIndex = 7;
            this.dateTimePicker6.ValueChanged += new System.EventHandler(this.dateTimePicker6_ValueChanged);
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(327, 225);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(90, 30);
            this.button55.TabIndex = 1;
            this.button55.Text = "Exit";
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(146, 224);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(92, 31);
            this.button54.TabIndex = 1;
            this.button54.Text = "Search";
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.dateTimePicker8);
            this.panel16.Controls.Add(this.button67);
            this.panel16.Controls.Add(this.cmb_agent_up);
            this.panel16.Controls.Add(this.cmb_area_up);
            this.panel16.Controls.Add(this.label113);
            this.panel16.Controls.Add(this.label106);
            this.panel16.Controls.Add(this.label111);
            this.panel16.Controls.Add(this.txt_address_up);
            this.panel16.Controls.Add(this.label112);
            this.panel16.Controls.Add(this.txt_app_up);
            this.panel16.Controls.Add(this.label114);
            this.panel16.Controls.Add(this.radioButton18);
            this.panel16.Controls.Add(this.radioButton15);
            this.panel16.Controls.Add(this.dateTimePicker7);
            this.panel16.Controls.Add(this.button56);
            this.panel16.Controls.Add(this.txt_id_Main);
            this.panel16.Controls.Add(this.label104);
            this.panel16.Controls.Add(this.button57);
            this.panel16.Controls.Add(this.txt_nam_main);
            this.panel16.Controls.Add(this.button58);
            this.panel16.Controls.Add(this.label105);
            this.panel16.Controls.Add(this.txt_trade_main);
            this.panel16.Controls.Add(this.label107);
            this.panel16.Controls.Add(this.dataGridView3);
            this.panel16.Controls.Add(this.txt_phone_up);
            this.panel16.Location = new System.Drawing.Point(52, 159);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(932, 513);
            this.panel16.TabIndex = 39;
            this.panel16.Visible = false;
            this.panel16.Paint += new System.Windows.Forms.PaintEventHandler(this.panel16_Paint);
            // 
            // dateTimePicker8
            // 
            this.dateTimePicker8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker8.Location = new System.Drawing.Point(241, 470);
            this.dateTimePicker8.Name = "dateTimePicker8";
            this.dateTimePicker8.Size = new System.Drawing.Size(149, 22);
            this.dateTimePicker8.TabIndex = 74;
            // 
            // button67
            // 
            this.button67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button67.Location = new System.Drawing.Point(484, 175);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(75, 23);
            this.button67.TabIndex = 73;
            this.button67.Text = "Delete";
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // cmb_agent_up
            // 
            this.cmb_agent_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_agent_up.FormattingEnabled = true;
            this.cmb_agent_up.Location = new System.Drawing.Point(241, 132);
            this.cmb_agent_up.Name = "cmb_agent_up";
            this.cmb_agent_up.Size = new System.Drawing.Size(181, 24);
            this.cmb_agent_up.TabIndex = 72;
            // 
            // cmb_area_up
            // 
            this.cmb_area_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_area_up.FormattingEnabled = true;
            this.cmb_area_up.Location = new System.Drawing.Point(572, 132);
            this.cmb_area_up.Name = "cmb_area_up";
            this.cmb_area_up.Size = new System.Drawing.Size(181, 24);
            this.cmb_area_up.TabIndex = 71;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.Location = new System.Drawing.Point(446, 135);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(37, 16);
            this.label113.TabIndex = 70;
            this.label113.Text = "Area";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(140, 133);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(43, 16);
            this.label106.TabIndex = 68;
            this.label106.Text = "Agent";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.Location = new System.Drawing.Point(450, 16);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(101, 16);
            this.label111.TabIndex = 65;
            this.label111.Text = "Phone Number:";
            // 
            // txt_address_up
            // 
            this.txt_address_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_address_up.Location = new System.Drawing.Point(572, 54);
            this.txt_address_up.Name = "txt_address_up";
            this.txt_address_up.Size = new System.Drawing.Size(183, 22);
            this.txt_address_up.TabIndex = 64;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.Location = new System.Drawing.Point(448, 58);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(65, 16);
            this.label112.TabIndex = 62;
            this.label112.Text = "Address :";
            // 
            // txt_app_up
            // 
            this.txt_app_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_app_up.Location = new System.Drawing.Point(572, 92);
            this.txt_app_up.Name = "txt_app_up";
            this.txt_app_up.Size = new System.Drawing.Size(183, 22);
            this.txt_app_up.TabIndex = 59;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.Location = new System.Drawing.Point(443, 95);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(123, 16);
            this.label114.TabIndex = 61;
            this.label114.Text = "Application number";
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton18.Location = new System.Drawing.Point(579, 215);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(64, 20);
            this.radioButton18.TabIndex = 58;
            this.radioButton18.Text = "Pigmy";
            this.radioButton18.UseVisualStyleBackColor = true;
            this.radioButton18.CheckedChanged += new System.EventHandler(this.radioButton18_CheckedChanged);
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Checked = true;
            this.radioButton15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton15.Location = new System.Drawing.Point(337, 215);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(56, 20);
            this.radioButton15.TabIndex = 57;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "Loan";
            this.radioButton15.UseVisualStyleBackColor = true;
            this.radioButton15.CheckedChanged += new System.EventHandler(this.radioButton15_CheckedChanged);
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker7.Location = new System.Drawing.Point(409, 470);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(140, 22);
            this.dateTimePicker7.TabIndex = 56;
            // 
            // button56
            // 
            this.button56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button56.Location = new System.Drawing.Point(557, 469);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(75, 23);
            this.button56.TabIndex = 55;
            this.button56.Text = "Refresh";
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // txt_id_Main
            // 
            this.txt_id_Main.Enabled = false;
            this.txt_id_Main.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_Main.Location = new System.Drawing.Point(241, 10);
            this.txt_id_Main.Name = "txt_id_Main";
            this.txt_id_Main.Size = new System.Drawing.Size(183, 22);
            this.txt_id_Main.TabIndex = 54;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(142, 11);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(25, 16);
            this.label104.TabIndex = 53;
            this.label104.Text = "Id :";
            // 
            // button57
            // 
            this.button57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button57.Location = new System.Drawing.Point(648, 469);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(75, 23);
            this.button57.TabIndex = 52;
            this.button57.Text = "Cancel";
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // txt_nam_main
            // 
            this.txt_nam_main.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nam_main.Location = new System.Drawing.Point(240, 49);
            this.txt_nam_main.Name = "txt_nam_main";
            this.txt_nam_main.Size = new System.Drawing.Size(183, 22);
            this.txt_nam_main.TabIndex = 51;
            // 
            // button58
            // 
            this.button58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button58.Location = new System.Drawing.Point(346, 173);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(75, 23);
            this.button58.TabIndex = 49;
            this.button58.Text = "Update";
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(140, 53);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(51, 16);
            this.label105.TabIndex = 45;
            this.label105.Text = "Name :";
            // 
            // txt_trade_main
            // 
            this.txt_trade_main.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_trade_main.Location = new System.Drawing.Point(240, 94);
            this.txt_trade_main.Name = "txt_trade_main";
            this.txt_trade_main.Size = new System.Drawing.Size(183, 22);
            this.txt_trade_main.TabIndex = 36;
            this.txt_trade_main.TextChanged += new System.EventHandler(this.txt_trade_main_TextChanged);
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(135, 97);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(88, 16);
            this.label107.TabIndex = 38;
            this.label107.Text = "Trade Name:";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToResizeRows = false;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.customerDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn,
            this.tradeNameDataGridViewTextBoxColumn,
            this.interestDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn1,
            this.areaDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.customerPiggyBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(18, 252);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3.Size = new System.Drawing.Size(879, 209);
            this.dataGridView3.TabIndex = 33;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            this.dataGridView3.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            this.idDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // customerDataGridViewTextBoxColumn
            // 
            this.customerDataGridViewTextBoxColumn.DataPropertyName = "Customer";
            this.customerDataGridViewTextBoxColumn.HeaderText = "Customer";
            this.customerDataGridViewTextBoxColumn.Name = "customerDataGridViewTextBoxColumn";
            this.customerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            this.phoneDataGridViewTextBoxColumn.DataPropertyName = "Phone";
            this.phoneDataGridViewTextBoxColumn.HeaderText = "Phone";
            this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            this.phoneDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tradeNameDataGridViewTextBoxColumn
            // 
            this.tradeNameDataGridViewTextBoxColumn.DataPropertyName = "Trade_Name";
            this.tradeNameDataGridViewTextBoxColumn.HeaderText = "Trade_Name";
            this.tradeNameDataGridViewTextBoxColumn.Name = "tradeNameDataGridViewTextBoxColumn";
            this.tradeNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // interestDataGridViewTextBoxColumn
            // 
            this.interestDataGridViewTextBoxColumn.DataPropertyName = "Interest";
            this.interestDataGridViewTextBoxColumn.HeaderText = "Interest";
            this.interestDataGridViewTextBoxColumn.Name = "interestDataGridViewTextBoxColumn";
            this.interestDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // amountDataGridViewTextBoxColumn1
            // 
            this.amountDataGridViewTextBoxColumn1.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn1.HeaderText = "Amount";
            this.amountDataGridViewTextBoxColumn1.Name = "amountDataGridViewTextBoxColumn1";
            this.amountDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // areaDataGridViewTextBoxColumn
            // 
            this.areaDataGridViewTextBoxColumn.DataPropertyName = "Area";
            this.areaDataGridViewTextBoxColumn.HeaderText = "Area";
            this.areaDataGridViewTextBoxColumn.Name = "areaDataGridViewTextBoxColumn";
            this.areaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // customerPiggyBindingSource
            // 
            this.customerPiggyBindingSource.DataMember = "Customer_Piggy";
            this.customerPiggyBindingSource.DataSource = this.sDM_GroupDataSet8;
            // 
            // sDM_GroupDataSet8
            // 
            this.sDM_GroupDataSet8.DataSetName = "SDM_GroupDataSet8";
            this.sDM_GroupDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txt_phone_up
            // 
            this.txt_phone_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_phone_up.Location = new System.Drawing.Point(573, 15);
            this.txt_phone_up.Name = "txt_phone_up";
            this.txt_phone_up.Size = new System.Drawing.Size(183, 22);
            this.txt_phone_up.TabIndex = 66;
            this.txt_phone_up.TextChanged += new System.EventHandler(this.txt_phone_up_TextChanged);
            // 
            // customerloanBindingSource
            // 
            this.customerloanBindingSource.DataMember = "Customer_loan";
            this.customerloanBindingSource.DataSource = this.sDM_GroupDataSet8;
            // 
            // customer_loanTableAdapter
            // 
            this.customer_loanTableAdapter.ClearBeforeFill = true;
            // 
            // customer_PiggyTableAdapter
            // 
            this.customer_PiggyTableAdapter.ClearBeforeFill = true;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.button60);
            this.panel17.Controls.Add(this.label115);
            this.panel17.Controls.Add(this.cmb_id_cl);
            this.panel17.Controls.Add(this.label116);
            this.panel17.Controls.Add(this.label117);
            this.panel17.Controls.Add(this.label118);
            this.panel17.Controls.Add(this.cmb_trade_Cl);
            this.panel17.Controls.Add(this.Cmb_name_pig_cl);
            this.panel17.Controls.Add(this.button59);
            this.panel17.Controls.Add(this.button61);
            this.panel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel17.Location = new System.Drawing.Point(172, 224);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(530, 235);
            this.panel17.TabIndex = 40;
            this.panel17.Visible = false;
            this.panel17.Paint += new System.Windows.Forms.PaintEventHandler(this.panel17_Paint);
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(53, 181);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(92, 31);
            this.button60.TabIndex = 18;
            this.button60.Text = "Re-Open";
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button60_Click_1);
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(44, 136);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(25, 16);
            this.label115.TabIndex = 17;
            this.label115.Text = "Id :";
            // 
            // cmb_id_cl
            // 
            this.cmb_id_cl.FormattingEnabled = true;
            this.cmb_id_cl.Location = new System.Drawing.Point(147, 133);
            this.cmb_id_cl.Name = "cmb_id_cl";
            this.cmb_id_cl.Size = new System.Drawing.Size(286, 24);
            this.cmb_id_cl.TabIndex = 16;
            this.cmb_id_cl.SelectedIndexChanged += new System.EventHandler(this.cmb_id_cl_SelectedIndexChanged);
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.Location = new System.Drawing.Point(151, 14);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(225, 16);
            this.label116.TabIndex = 12;
            this.label116.Text = "Re-Open/Close Pigmy Account ";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(44, 99);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(91, 16);
            this.label118.TabIndex = 11;
            this.label118.Text = "Trade Name :";
            // 
            // cmb_trade_Cl
            // 
            this.cmb_trade_Cl.FormattingEnabled = true;
            this.cmb_trade_Cl.Location = new System.Drawing.Point(148, 100);
            this.cmb_trade_Cl.Name = "cmb_trade_Cl";
            this.cmb_trade_Cl.Size = new System.Drawing.Size(286, 24);
            this.cmb_trade_Cl.TabIndex = 9;
            this.cmb_trade_Cl.SelectedIndexChanged += new System.EventHandler(this.cmb_trade_Cl_SelectedIndexChanged);
            // 
            // Cmb_name_pig_cl
            // 
            this.Cmb_name_pig_cl.FormattingEnabled = true;
            this.Cmb_name_pig_cl.Location = new System.Drawing.Point(148, 62);
            this.Cmb_name_pig_cl.Name = "Cmb_name_pig_cl";
            this.Cmb_name_pig_cl.Size = new System.Drawing.Size(286, 24);
            this.Cmb_name_pig_cl.TabIndex = 8;
            this.Cmb_name_pig_cl.SelectedIndexChanged += new System.EventHandler(this.Cmb_name_pig_cl_SelectedIndexChanged);
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(326, 184);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(90, 30);
            this.button59.TabIndex = 1;
            this.button59.Text = "Exit";
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(189, 184);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(92, 31);
            this.button61.TabIndex = 1;
            this.button61.Text = "Close";
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.button60_Click);
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label121);
            this.panel18.Controls.Add(this.label120);
            this.panel18.Controls.Add(this.button63);
            this.panel18.Controls.Add(this.button62);
            this.panel18.Controls.Add(this.radioButton19);
            this.panel18.Controls.Add(this.radioButton20);
            this.panel18.Controls.Add(this.label119);
            this.panel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel18.Location = new System.Drawing.Point(312, 258);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(367, 207);
            this.panel18.TabIndex = 41;
            this.panel18.Visible = false;
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.ForeColor = System.Drawing.Color.Blue;
            this.label121.Location = new System.Drawing.Point(49, 125);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(128, 16);
            this.label121.TabIndex = 21;
            this.label121.Text = "The Total Collection";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.ForeColor = System.Drawing.Color.Green;
            this.label120.Location = new System.Drawing.Point(46, 91);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(176, 16);
            this.label120.TabIndex = 20;
            this.label120.Text = "The Total Amount Balance : ";
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(213, 160);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(90, 30);
            this.button63.TabIndex = 19;
            this.button63.Text = "Exit";
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(28, 159);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(134, 31);
            this.button62.TabIndex = 18;
            this.button62.Text = "Total Payment";
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Checked = true;
            this.radioButton19.Location = new System.Drawing.Point(26, 49);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(56, 20);
            this.radioButton19.TabIndex = 17;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "Loan";
            this.radioButton19.UseVisualStyleBackColor = true;
            this.radioButton19.CheckedChanged += new System.EventHandler(this.radioButton19_CheckedChanged);
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(225, 52);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(115, 20);
            this.radioButton20.TabIndex = 16;
            this.radioButton20.Text = "Pigmy Account";
            this.radioButton20.UseVisualStyleBackColor = true;
            this.radioButton20.CheckedChanged += new System.EventHandler(this.radioButton20_CheckedChanged);
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label119.Location = new System.Drawing.Point(65, 15);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(194, 16);
            this.label119.TabIndex = 13;
            this.label119.Text = "Total Payment Loan/Pigmy";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(63, 32);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(269, 22);
            this.textBox4.TabIndex = 1;
            this.textBox4.Visible = false;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label133);
            this.groupBox18.Controls.Add(this.cmb_agent);
            this.groupBox18.Controls.Add(this.groupBox19);
            this.groupBox18.Controls.Add(this.button70);
            this.groupBox18.Controls.Add(this.radioButton22);
            this.groupBox18.Controls.Add(this.radioButton21);
            this.groupBox18.Controls.Add(this.button66);
            this.groupBox18.Controls.Add(this.button65);
            this.groupBox18.Controls.Add(this.textBox4);
            this.groupBox18.Controls.Add(this.button64);
            this.groupBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox18.Location = new System.Drawing.Point(302, 165);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(407, 291);
            this.groupBox18.TabIndex = 42;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Message Send";
            this.groupBox18.Visible = false;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.cmb_name_msg);
            this.groupBox19.Controls.Add(this.cmb_id_msg);
            this.groupBox19.Location = new System.Drawing.Point(14, 169);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(373, 45);
            this.groupBox19.TabIndex = 8;
            this.groupBox19.TabStop = false;
            this.groupBox19.Visible = false;
            // 
            // cmb_name_msg
            // 
            this.cmb_name_msg.FormattingEnabled = true;
            this.cmb_name_msg.Location = new System.Drawing.Point(194, 13);
            this.cmb_name_msg.Name = "cmb_name_msg";
            this.cmb_name_msg.Size = new System.Drawing.Size(158, 24);
            this.cmb_name_msg.TabIndex = 10;
            this.cmb_name_msg.SelectedIndexChanged += new System.EventHandler(this.cmb_name_msg_SelectedIndexChanged);
            // 
            // cmb_id_msg
            // 
            this.cmb_id_msg.FormattingEnabled = true;
            this.cmb_id_msg.Location = new System.Drawing.Point(19, 13);
            this.cmb_id_msg.Name = "cmb_id_msg";
            this.cmb_id_msg.Size = new System.Drawing.Size(169, 24);
            this.cmb_id_msg.TabIndex = 9;
            this.cmb_id_msg.SelectedIndexChanged += new System.EventHandler(this.cmb_id_msg_SelectedIndexChanged);
            // 
            // button70
            // 
            this.button70.Enabled = false;
            this.button70.Location = new System.Drawing.Point(149, 243);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(98, 28);
            this.button70.TabIndex = 7;
            this.button70.Text = "Send";
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Click += new System.EventHandler(this.button70_Click_1);
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(229, 217);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(83, 20);
            this.radioButton22.TabIndex = 5;
            this.radioButton22.Text = "Individual";
            this.radioButton22.UseVisualStyleBackColor = true;
            this.radioButton22.CheckedChanged += new System.EventHandler(this.radioButton22_CheckedChanged_1);
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Checked = true;
            this.radioButton21.Location = new System.Drawing.Point(89, 217);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(63, 20);
            this.radioButton21.TabIndex = 4;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "Group";
            this.radioButton21.UseVisualStyleBackColor = true;
            this.radioButton21.CheckedChanged += new System.EventHandler(this.radioButton21_CheckedChanged_1);
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(174, 71);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(96, 28);
            this.button66.TabIndex = 3;
            this.button66.Text = "Send Pigmy";
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(309, 72);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(72, 28);
            this.button65.TabIndex = 2;
            this.button65.Text = "Exit";
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(44, 71);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(98, 28);
            this.button64.TabIndex = 0;
            this.button64.Text = "Send Loan";
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(380, 149);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(299, 163);
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // sDMGroupDataSet8BindingSource
            // 
            this.sDMGroupDataSet8BindingSource.DataSource = this.sDM_GroupDataSet8;
            this.sDMGroupDataSet8BindingSource.Position = 0;
            // 
            // customerPiggyBindingSource1
            // 
            this.customerPiggyBindingSource1.DataMember = "Customer_Piggy";
            this.customerPiggyBindingSource1.DataSource = this.sDMGroupDataSet8BindingSource;
            // 
            // customerloanBindingSource1
            // 
            this.customerloanBindingSource1.DataMember = "Customer_loan";
            this.customerloanBindingSource1.DataSource = this.sDM_GroupDataSet9;
            // 
            // sDM_GroupDataSet9
            // 
            this.sDM_GroupDataSet9.DataSetName = "SDM_GroupDataSet9";
            this.sDM_GroupDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // sDMGroupDataSet9BindingSource
            // 
            this.sDMGroupDataSet9BindingSource.DataSource = this.sDM_GroupDataSet9;
            this.sDMGroupDataSet9BindingSource.Position = 0;
            // 
            // customer_loanTableAdapter1
            // 
            this.customer_loanTableAdapter1.ClearBeforeFill = true;
            // 
            // customerloanBindingSource2
            // 
            this.customerloanBindingSource2.DataMember = "Customer_loan";
            this.customerloanBindingSource2.DataSource = this.sDMGroupDataSet9BindingSource;
            // 
            // sDM_GroupDataSet16
            // 
            this.sDM_GroupDataSet16.DataSetName = "SDM_GroupDataSet16";
            this.sDM_GroupDataSet16.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerloanBindingSource3
            // 
            this.customerloanBindingSource3.DataMember = "Customer_loan";
            this.customerloanBindingSource3.DataSource = this.sDM_GroupDataSet16;
            // 
            // customer_loanTableAdapter2
            // 
            this.customer_loanTableAdapter2.ClearBeforeFill = true;
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.col_Day);
            this.panel21.Controls.Add(this.chk_all);
            this.panel21.Controls.Add(this.button75);
            this.panel21.Controls.Add(this.label125);
            this.panel21.Controls.Add(this.button72);
            this.panel21.Controls.Add(this.cmb_agent_name);
            this.panel21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel21.Location = new System.Drawing.Point(354, 170);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(370, 138);
            this.panel21.TabIndex = 45;
            this.panel21.Visible = false;
            this.panel21.Paint += new System.Windows.Forms.PaintEventHandler(this.panel21_Paint);
            // 
            // col_Day
            // 
            this.col_Day.Location = new System.Drawing.Point(149, 57);
            this.col_Day.Name = "col_Day";
            this.col_Day.Size = new System.Drawing.Size(168, 22);
            this.col_Day.TabIndex = 5;
            // 
            // chk_all
            // 
            this.chk_all.AutoSize = true;
            this.chk_all.Location = new System.Drawing.Point(34, 59);
            this.chk_all.Name = "chk_all";
            this.chk_all.Size = new System.Drawing.Size(109, 20);
            this.chk_all.TabIndex = 4;
            this.chk_all.Text = "All Customers";
            this.chk_all.UseVisualStyleBackColor = true;
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(225, 89);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(91, 29);
            this.button75.TabIndex = 3;
            this.button75.Text = "Exit";
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Click += new System.EventHandler(this.button75_Click);
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.Location = new System.Drawing.Point(35, 26);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(49, 16);
            this.label125.TabIndex = 2;
            this.label125.Text = "Agent :";
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(66, 88);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(97, 30);
            this.button72.TabIndex = 1;
            this.button72.Text = "Print";
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // cmb_agent_name
            // 
            this.cmb_agent_name.FormattingEnabled = true;
            this.cmb_agent_name.Location = new System.Drawing.Point(97, 24);
            this.cmb_agent_name.Name = "cmb_agent_name";
            this.cmb_agent_name.Size = new System.Drawing.Size(222, 24);
            this.cmb_agent_name.TabIndex = 0;
            // 
            // sDM_GroupDataSet17
            // 
            this.sDM_GroupDataSet17.DataSetName = "SDM_GroupDataSet17";
            this.sDM_GroupDataSet17.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loanCustomerBindingSource4
            // 
            this.loanCustomerBindingSource4.DataMember = "Loan_Customer";
            this.loanCustomerBindingSource4.DataSource = this.sDM_GroupDataSet17;
            // 
            // loan_CustomerTableAdapter4
            // 
            this.loan_CustomerTableAdapter4.ClearBeforeFill = true;
            // 
            // loan_CustomerTableAdapter2
            // 
            this.loan_CustomerTableAdapter2.ClearBeforeFill = true;
            // 
            // sDM_GroupDataSet19
            // 
            this.sDM_GroupDataSet19.DataSetName = "SDM_GroupDataSet19";
            this.sDM_GroupDataSet19.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loanCustomerBindingSource5
            // 
            this.loanCustomerBindingSource5.DataMember = "Loan_Customer";
            this.loanCustomerBindingSource5.DataSource = this.sDM_GroupDataSet19;
            // 
            // loan_CustomerTableAdapter5
            // 
            this.loan_CustomerTableAdapter5.ClearBeforeFill = true;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label122);
            this.panel19.Controls.Add(this.txt_exp);
            this.panel19.Controls.Add(this.button73);
            this.panel19.Controls.Add(this.button71);
            this.panel19.Location = new System.Drawing.Point(359, 225);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(379, 141);
            this.panel19.TabIndex = 47;
            this.panel19.Visible = false;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label122.Location = new System.Drawing.Point(145, 16);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(87, 20);
            this.label122.TabIndex = 3;
            this.label122.Text = "Expenses";
            // 
            // txt_exp
            // 
            this.txt_exp.Location = new System.Drawing.Point(52, 52);
            this.txt_exp.Name = "txt_exp";
            this.txt_exp.Size = new System.Drawing.Size(285, 20);
            this.txt_exp.TabIndex = 2;
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(198, 97);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(75, 27);
            this.button73.TabIndex = 1;
            this.button73.Text = "Exit";
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.button73_Click_1);
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(99, 97);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(69, 25);
            this.button71.TabIndex = 0;
            this.button71.Text = "Add";
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.button71_Click_2);
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.groupBox20);
            this.panel20.Controls.Add(this.button77);
            this.panel20.Controls.Add(this.lbl_loss);
            this.panel20.Controls.Add(this.label127);
            this.panel20.Controls.Add(this.lbl_pig_int);
            this.panel20.Controls.Add(this.label126);
            this.panel20.Controls.Add(this.lbl_intrest);
            this.panel20.Controls.Add(this.label124);
            this.panel20.Controls.Add(this.button76);
            this.panel20.Controls.Add(this.button74);
            this.panel20.Location = new System.Drawing.Point(186, 147);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(639, 523);
            this.panel20.TabIndex = 48;
            this.panel20.Visible = false;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.button78);
            this.groupBox20.Controls.Add(this.label123);
            this.groupBox20.Controls.Add(this.dateTimePicker9);
            this.groupBox20.Controls.Add(this.txt_exp_amt);
            this.groupBox20.Controls.Add(this.cmb_exp);
            this.groupBox20.Location = new System.Drawing.Point(23, 23);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(582, 269);
            this.groupBox20.TabIndex = 10;
            this.groupBox20.TabStop = false;
            this.groupBox20.Enter += new System.EventHandler(this.groupBox20_Enter);
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(263, 230);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(60, 20);
            this.button78.TabIndex = 8;
            this.button78.Text = "Save";
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Click += new System.EventHandler(this.button78_Click);
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(181, 12);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(230, 16);
            this.label123.TabIndex = 7;
            this.label123.Text = "Profit/Loss For Month of January";
            // 
            // dateTimePicker9
            // 
            this.dateTimePicker9.Location = new System.Drawing.Point(170, 78);
            this.dateTimePicker9.Name = "dateTimePicker9";
            this.dateTimePicker9.Size = new System.Drawing.Size(242, 20);
            this.dateTimePicker9.TabIndex = 6;
            this.dateTimePicker9.ValueChanged += new System.EventHandler(this.dateTimePicker9_ValueChanged);
            // 
            // txt_exp_amt
            // 
            this.txt_exp_amt.Location = new System.Drawing.Point(170, 182);
            this.txt_exp_amt.Name = "txt_exp_amt";
            this.txt_exp_amt.Size = new System.Drawing.Size(242, 20);
            this.txt_exp_amt.TabIndex = 5;
            // 
            // cmb_exp
            // 
            this.cmb_exp.FormattingEnabled = true;
            this.cmb_exp.Location = new System.Drawing.Point(170, 126);
            this.cmb_exp.Name = "cmb_exp";
            this.cmb_exp.Size = new System.Drawing.Size(242, 21);
            this.cmb_exp.TabIndex = 4;
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(258, 478);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(93, 24);
            this.button77.TabIndex = 9;
            this.button77.Text = "Refresh";
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.button77_Click);
            // 
            // lbl_loss
            // 
            this.lbl_loss.AutoSize = true;
            this.lbl_loss.Location = new System.Drawing.Point(335, 427);
            this.lbl_loss.Name = "lbl_loss";
            this.lbl_loss.Size = new System.Drawing.Size(100, 13);
            this.lbl_loss.TabIndex = 8;
            this.lbl_loss.Text = "Interest Pigmy Profit";
            this.lbl_loss.Click += new System.EventHandler(this.label130_Click);
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(206, 424);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(104, 13);
            this.label127.TabIndex = 7;
            this.label127.Text = "Interest Pigmy Loss :";
            // 
            // lbl_pig_int
            // 
            this.lbl_pig_int.AutoSize = true;
            this.lbl_pig_int.Location = new System.Drawing.Point(332, 374);
            this.lbl_pig_int.Name = "lbl_pig_int";
            this.lbl_pig_int.Size = new System.Drawing.Size(100, 13);
            this.lbl_pig_int.TabIndex = 7;
            this.lbl_pig_int.Text = "Interest Pigmy Profit";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(206, 372);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(106, 13);
            this.label126.TabIndex = 7;
            this.label126.Text = "Interest Pigmy Profit :";
            // 
            // lbl_intrest
            // 
            this.lbl_intrest.AutoSize = true;
            this.lbl_intrest.Location = new System.Drawing.Point(333, 324);
            this.lbl_intrest.Name = "lbl_intrest";
            this.lbl_intrest.Size = new System.Drawing.Size(69, 13);
            this.lbl_intrest.TabIndex = 7;
            this.lbl_intrest.Text = "Interest Loan";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(239, 323);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(75, 13);
            this.label124.TabIndex = 7;
            this.label124.Text = "Interest Loan :";
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(382, 478);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(93, 24);
            this.button76.TabIndex = 6;
            this.button76.Text = "Exit";
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Click += new System.EventHandler(this.button76_Click);
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(141, 477);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(93, 24);
            this.button74.TabIndex = 5;
            this.button74.Text = "Save";
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Click += new System.EventHandler(this.button74_Click_1);
            // 
            // cmb_agent
            // 
            this.cmb_agent.FormattingEnabled = true;
            this.cmb_agent.Location = new System.Drawing.Point(134, 125);
            this.cmb_agent.Name = "cmb_agent";
            this.cmb_agent.Size = new System.Drawing.Size(228, 24);
            this.cmb_agent.TabIndex = 9;
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(43, 57);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(51, 16);
            this.label117.TabIndex = 11;
            this.label117.Text = "Name :";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(63, 127);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(49, 16);
            this.label133.TabIndex = 12;
            this.label133.Text = "Agent :";
            // 
            // Form1
            // 
            this.AcceptButton = this.button1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.button2;
            this.ClientSize = new System.Drawing.Size(1054, 871);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.groupBox18);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel19);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox10);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SDM Finance";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource3)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piggyCustomerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piggyCustomerBindingSource1)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPiggyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource)).EndInit();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDMGroupDataSet8BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPiggyBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDMGroupDataSet9BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerloanBindingSource3)).EndInit();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDM_GroupDataSet19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanCustomerBindingSource5)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion 

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.DateTimePicker date_started_pig;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_phone_pig;
        private System.Windows.Forms.TextBox txt_Name_pig;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_trade_pig;
        private System.Windows.Forms.TextBox txt_Address_pig;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cmb_name_pig;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txt_phone_chit;
        private System.Windows.Forms.TextBox txt_Cust_chit;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txt_trade_chit;
        private System.Windows.Forms.TextBox txt_address_chit;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.DateTimePicker Paid_date_chit;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txt_amount_chit_paid;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DateTimePicker date_due_loan;
        private System.Windows.Forms.DateTimePicker date_paid_loan;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_amount_laon;
        private System.Windows.Forms.ComboBox cmb_name;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txt_amount_pig;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txt_id_pig;
        private System.Windows.Forms.TextBox Total_Paid;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_pass;
        private System.Windows.Forms.TextBox txt_user;
        private System.Windows.Forms.TextBox txt_id_chit;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txt_total_amount;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        public System.Windows.Forms.DateTimePicker dateTimePicker2;
        public System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txt_password_c;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.TextBox txt_user_name;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem loanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentForCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem piggyBankToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCusytomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCustomerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem paymentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem displayReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ComboBox bIDDER;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.TextBox txt_balance;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txt_bid_amount;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.TextBox txt_total_bid;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.ComboBox cmb_chit_bid;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem renewalToolStripMenuItem;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox cmb_name_exc;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txt_total;
        private System.Windows.Forms.TextBox txt_due_after;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.ComboBox cmb_Chit;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ToolStripMenuItem addChitToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txt_Amount_total;
        private System.Windows.Forms.DateTimePicker End_date_chit;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DateTimePicker Start_date_chit;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem bidToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmb_chit_name;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.ComboBox cmb_name_chit;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.DateTimePicker date_bid;
        private System.Windows.Forms.ComboBox cmb_amount_bid;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.ComboBox cmb_id;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.ComboBox Cmb_id_pigme;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox Overdue;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem withdrawToolStripMenuItem;
        private System.Windows.Forms.DateTimePicker date_pig;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txt_withdraw;
        private System.Windows.Forms.TextBox txt_withdraw_amount;
        private System.Windows.Forms.TextBox txt_total_taken;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.TextBox txt_profit;
        private System.Windows.Forms.TextBox txt_total_balance_with;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.ComboBox Cmb_name_wd;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.ComboBox Id;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbl_duration;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.DateTimePicker date_pd_up;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox txt_amount_pd_up;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txt_name_update;
        private SDM_GroupDataSet1 sDM_GroupDataSet1;
        private System.Windows.Forms.BindingSource loanCustomerBindingSource;
        private SDM_GroupDataSet1TableAdapters.Loan_CustomerTableAdapter loan_CustomerTableAdapter;
        private SDM_GroupDataSet2 sDM_GroupDataSet2;
        private System.Windows.Forms.BindingSource loanCustomerBindingSource1;
        private SDM_GroupDataSet2TableAdapters.Loan_CustomerTableAdapter loan_CustomerTableAdapter1;
        private SDM_GroupDataSet3 sDM_GroupDataSet3;
        private System.Windows.Forms.BindingSource loanCustomerBindingSource2;
        private SDM_GroupDataSet3TableAdapters.Loan_CustomerTableAdapter loan_CustomerTableAdapter2;
        private SDM_GroupDataSet4 sDM_GroupDataSet4;
        private System.Windows.Forms.BindingSource loanCustomerBindingSource3;
        private SDM_GroupDataSet4TableAdapters.Loan_CustomerTableAdapter loan_CustomerTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datePaidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nextdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn balanceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.ToolStripMenuItem updatreToolStripMenuItem;
        private System.Windows.Forms.TextBox txt_id_up;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.TextBox txt_id_up_pig;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.TextBox txt_name_pig_up;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.DateTimePicker date_pd_pig;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox txt_pig_amount_up;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private SDM_GroupDataSet5 sDM_GroupDataSet5;
        private System.Windows.Forms.BindingSource piggyCustomerBindingSource;
        private SDM_GroupDataSet5TableAdapters.Piggy_CustomerTableAdapter piggy_CustomerTableAdapter;
        private SDM_GroupDataSet6 sDM_GroupDataSet6;
        private System.Windows.Forms.BindingSource piggyCustomerBindingSource1;
        private SDM_GroupDataSet6TableAdapters.Piggy_CustomerTableAdapter piggy_CustomerTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountpaidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datepaidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn balanceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn withdrawalDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox cmb_area_pig;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox txt_area;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.DateTimePicker date_show;
        private System.Windows.Forms.DateTimePicker date_now;
        private System.Windows.Forms.ComboBox cmb_id_loan;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.ToolStripMenuItem pigmeToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ComboBox cmb_id_rpt;
        private System.Windows.Forms.ComboBox cmb_rpt_name;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.ComboBox cmb_area_rpt;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.ToolStripMenuItem totalCollectionToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.ComboBox cmb_area_all;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.ComboBox cmb_id_all;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        public System.Windows.Forms.DateTimePicker dateTimePicker4;
        public System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox txt_Agent;
        private System.Windows.Forms.ComboBox cmb_agent_id;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.DateTimePicker Date_end_pig;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox txt_amount;
        private System.Windows.Forms.ComboBox cmb_trade_Pig;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.ComboBox txt_cmb_trade_loan;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmb_agend_id_loan;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox Area_Combox_Pig;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DateTimePicker Date_Started;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label Customer;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.TextBox txt_Cutomer_name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_Interest;
        private System.Windows.Forms.TextBox txt_Loan_Amt;
        private System.Windows.Forms.TextBox txt_trade;
        private System.Windows.Forms.TextBox txt_Address;
        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.TextBox txt_agenrt_name;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.ComboBox cmb_Name_pay;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.ComboBox cmb_id_pay;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.ComboBox cmb_trade_pay;
        private System.Windows.Forms.ComboBox cmb_trade_rep;
        private System.Windows.Forms.ComboBox cmb_all_name;
        private System.Windows.Forms.ToolStripMenuItem checkPaymentToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmb_trade_rpt;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.TextBox txt_id_Main;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.TextBox txt_nam_main;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.TextBox txt_trade_main;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.DataGridView dataGridView3;
        private SDM_GroupDataSet8 sDM_GroupDataSet8;
        private System.Windows.Forms.BindingSource customerloanBindingSource;
        private SDM_GroupDataSet8TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tradeNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn areaDataGridViewTextBoxColumn;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.BindingSource customerPiggyBindingSource;
        private SDM_GroupDataSet8TableAdapters.Customer_PiggyTableAdapter customer_PiggyTableAdapter;
        private System.Windows.Forms.ToolStripMenuItem updateCuisrtomerDetailsLoanPiggyToolStripMenuItem;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label Amt;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.TextBox txt_application_number;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox txt_app_no;
        private System.Windows.Forms.TextBox txt_phone_up;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox txt_address_up;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.TextBox txt_app_up;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.ComboBox cmb_agent_up;
        private System.Windows.Forms.ComboBox cmb_area_up;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TextBox txt_Close;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.ComboBox cmb_id_cl;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.ComboBox cmb_trade_Cl;
        private System.Windows.Forms.ComboBox Cmb_name_pig_cl;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.DateTimePicker due_after;
        private System.Windows.Forms.CheckBox chk_admin;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem totalCollectionPigmyLoanToolStripMenuItem;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.ToolStripMenuItem nearCompletionOfLoanToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.ToolStripMenuItem sendMessageToolStripMenuItem;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.ToolStripMenuItem contactInformationToolStripMenuItem;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.DateTimePicker dateTimePicker8;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.BindingSource sDMGroupDataSet8BindingSource;
        private System.Windows.Forms.BindingSource customerPiggyBindingSource1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.BindingSource customerloanBindingSource1;
        private SDM_GroupDataSet9 sDM_GroupDataSet9;
        private System.Windows.Forms.BindingSource sDMGroupDataSet9BindingSource;
        private SDM_GroupDataSet9TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter1;
        private System.Windows.Forms.BindingSource customerloanBindingSource2;
        private SDM_GroupDataSet16 sDM_GroupDataSet16;
        private System.Windows.Forms.BindingSource customerloanBindingSource3;
        private SDM_GroupDataSet16TableAdapters.Customer_loanTableAdapter customer_loanTableAdapter2;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.ComboBox cmb_agent_name;
        private System.Windows.Forms.ToolStripMenuItem loanReportToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument printDocument2;
        private SDM_GroupDataSet17 sDM_GroupDataSet17;
        private System.Windows.Forms.BindingSource loanCustomerBindingSource4;
        private SDM_GroupDataSet17TableAdapters.Loan_CustomerTableAdapter loan_CustomerTableAdapter4;
        private SDM_GroupDataSet19 sDM_GroupDataSet19;
        private System.Windows.Forms.BindingSource loanCustomerBindingSource5;
        private SDM_GroupDataSet19TableAdapters.Loan_CustomerTableAdapter loan_CustomerTableAdapter5;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.ComboBox cmb_name_msg;
        private System.Windows.Forms.ComboBox cmb_id_msg;
        private System.Windows.Forms.DateTimePicker col_Day;
        private System.Windows.Forms.CheckBox chk_all;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.TextBox txt_exp;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.ToolStripMenuItem profitLossAccountToolStripMenuItem;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label lbl_loss;
        private System.Windows.Forms.Label lbl_pig_int;
        private System.Windows.Forms.Label lbl_intrest;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.DateTimePicker dateTimePicker9;
        private System.Windows.Forms.TextBox txt_exp_amt;
        private System.Windows.Forms.ComboBox cmb_exp;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem masterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addExpensesToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem profitLossAccountToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reOpenClosePigmyAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem enterAreaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem enterAgentIdToolStripMenuItem1;
        private System.Windows.Forms.DateTimePicker date_end;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.TextBox txt_Nominee_aadress;
        private System.Windows.Forms.TextBox txt_Nominee_rel;
        private System.Windows.Forms.TextBox txt_Nominee_Age;
        private System.Windows.Forms.TextBox txt_Nominee;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.TextBox txt_Nominee_aadress_Busioness;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.TextBox txt_nominee_pig;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.TextBox txt_nominee_pig_Address;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.ComboBox cmb_agent;

    }
}

