﻿namespace WindowsFormsApplication10 {
    
    
    public partial class DataSet1 {
        partial class Loan_CustomerDataTable
        {
        }
    
        partial class Piggy_CustomerDataTable
        {
        }
    }
}

namespace WindowsFormsApplication10.DataSet1TableAdapters {
    
    
    public partial class Loan_CustomerTableAdapter {
    }
}
