﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication10
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            int a;
            if (txt_id.Text == "")
            {// TODO: This line of code loads data into the 'SDM_GroupDataSet7.Customer_Piggy' table. You can move, or remove it, as needed.
                this.Customer_PiggyTableAdapter.Fill(this.SDM_GroupDataSet7.Customer_Piggy, Convert.ToDateTime(txt_d1.Text), Convert.ToDateTime(txt_d2.Text));
                // TODO: This line of code loads data into the 'SDM_GroupDataSet7.Customer_loan' table. You can move, or remove it, as needed.
                this.Customer_loanTableAdapter.Fill(this.SDM_GroupDataSet7.Customer_loan,Convert.ToDateTime(txt_d1.Text),Convert.ToDateTime(txt_d2.Text));
            }
            else if (int.TryParse(txt_id.Text, out a))
            {
                this.Customer_PiggyTableAdapter.FillBy(this.SDM_GroupDataSet7.Customer_Piggy, Convert.ToDateTime(txt_d1.Text), Convert.ToDateTime(txt_d2.Text), int.Parse(txt_id.Text));
                // TODO: This line of code loads data into the 'SDM_GroupDataSet7.Customer_loan' table. You can move, or remove it, as needed.
                this.Customer_loanTableAdapter.FillBy(this.SDM_GroupDataSet7.Customer_loan, Convert.ToDateTime(txt_d1.Text), Convert.ToDateTime(txt_d2.Text), int.Parse(txt_id.Text));
            }
            else
            {
                this.Customer_PiggyTableAdapter.FillBy1(this.SDM_GroupDataSet7.Customer_Piggy, Convert.ToDateTime(txt_d1.Text), Convert.ToDateTime(txt_d2.Text), txt_id.Text);
                // TODO: This line of code loads data into the 'SDM_GroupDataSet7.Customer_loan' table. You can move, or remove it, as needed.
                this.Customer_loanTableAdapter.FillBy1(this.SDM_GroupDataSet7.Customer_loan, Convert.ToDateTime(txt_d1.Text), Convert.ToDateTime(txt_d2.Text), txt_id.Text);
            }
            this.reportViewer1.RefreshReport();
            this.reportViewer2.RefreshReport();
            this.reportViewer2.RefreshReport();
            this.reportViewer3.RefreshReport();
        }

        private void txt_d1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
