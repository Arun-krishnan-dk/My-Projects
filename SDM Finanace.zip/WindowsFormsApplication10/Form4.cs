﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication10
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
           
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
            //this.Customer_loanTableAdapter.Fill(this.sDM_GroupDataSet9.Customer_loan);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'sDM_GroupDataSet15.Customer_loan' table. You can move, or remove it, as needed.
            this.customer_loanTableAdapter7.Fill(this.sDM_GroupDataSet15.Customer_loan);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'sDM_GroupDataSet14.Customer_loan' table. You can move, or remove it, as needed.
           
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
          
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'sDM_GroupDataSet12.Customer_loan' table. You can move, or remove it, as needed.
            //this.customer_loanTableAdapter4.Fill(this.sDM_GroupDataSet12.Customer_loan,txt_Agent.Text);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
            //this.Customer_loanTableAdapter.Fill(this.sDM_GroupDataSet9.Customer_loan);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet11.Customer_loan' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
            
            //this.Customer_loanTableAdapter.Fill(this.sDM_GroupDataSet9.Customer_loan);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
           
            // TODO: This line of code loads data into the 'sDM_GroupDataSet10.Customer_loan' table. You can move, or remove it, as needed.
                        // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'SDM_GroupDataSet8.Customer_loan' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'sDM_GroupDataSet9.Customer_loan' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'SDM_GroupDataSet8.Customer_loan' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'SDM_GroupDataSet8.Customer_Piggy' table. You can move, or remove it, as needed.
            this.Customer_PiggyTableAdapter.Fill(this.SDM_GroupDataSet8.Customer_Piggy,txt_Agent.Text);
            // TODO: This line of code loads data into the 'SDM_GroupDataSet7.Renewal' table. You can move, or remove it, as needed.
            this.RenewalTableAdapter.Fill(this.SDM_GroupDataSet7.Renewal);

            this.reportViewer1.RefreshReport();
            this.reportViewer2.RefreshReport();
            this.reportViewer3.RefreshReport();
            this.reportViewer4.RefreshReport();
          
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
