﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Http;
using Microsoft.Office.Interop.Excel;


namespace WindowsFormsApplication10
{

    public partial class Form1 : Form
    {
        DateTime time;
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataReader sd = null;
        double total_pig = 0, total_chit = 0, total_loan = 0, total_paid = 0, balance_pig = 0, balance_chit = 0, bid_total = 0, interest = 0, balance_bid = 0,amount_bid=0;
        double balance = 0, amount = 0, type, Rept, all = 0;
        DateTime start_date = DateTime.Now;
        string arl="",area_pig1 = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

            panel1.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel2.Show();
            panel1.Hide();
            panel3.Hide();
            panel4.Hide();

        }

        private void button10_Click(object sender, EventArgs e)
        {
            //txt_Interest.Text = ((Convert.ToInt64(txt_Loan_Amt.Text) * 10) / 100).ToString();
            conn.Open();
            cmd.CommandText = "Insert into Customer_piggy values('" + txt_Name_pig.Text + "','" + txt_Address_pig.Text + "','" + txt_phone_pig.Text + "','" + txt_trade_pig.Text + "','" + date_started_pig.Value.ToString("MM/dd/yyyy") + "','" + type.ToString() + "','" + txt_amount.Text + "','" + (double.Parse(textBox1.Text) * double.Parse(txt_amount.Text)).ToString() + "','" + Date_end_pig.Value.ToString("MM/dd/yyyy") + "','" + cmb_area_pig.Text + "','" + cmb_agent_id.Text + "','" + txt_app_no.Text + "','" + txt_Close.Text +"','"+txt_nominee_pig.Text+ "','"+ txt_nominee_pig_Address.Text +"')";
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Created Customer For Piggy Bank");
            conn.Close();
            cmd.CommandText = "select * from Customer_piggy where Customer = '" + txt_Name_pig.Text.Trim() + "'";
            string id = "";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            string name = "";
            while (sd.Read())
            {
                //    cmb_name.Items.Add(sd[1].ToString());
                amount = double.Parse(sd["Amount"].ToString());
                id = sd[0].ToString();
            }
            conn.Close();
            string send = "http://sms2.microtreesolutions.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY=5c87f7517cc0d2989f1394a89dd16948&message=" + "SDM Finance" + System.Environment.NewLine + " Dear " + txt_Name_pig.Text + ", The Account Number for your Pigmy account is " + id + System.Environment.NewLine + "ThankYou" + System.Environment.NewLine + " Contact 0821-4191755" + " &senderId=SDMFIN&routeId=1&mobileNos=" + txt_phone_pig.Text + "&smsContentType=english";
            //    MessageBox.Show(send);
            System.Net.HttpWebRequest req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(send);
            System.Net.HttpWebResponse res = (System.Net.HttpWebResponse)req.GetResponse();
            StreamReader sr = new StreamReader(res.GetResponseStream());
            String file = sr.ReadToEnd();
            sr.Close();
            txt_id_pig.Text = "";
            txt_Name_pig.Text = "";
            txt_Address_pig.Text = "";
            txt_phone_pig.Text = "";
            txt_trade_pig.Text = "";
            //txt_amount_pig.Text = "";
            //textBox1.Text = "";
            Date_end_pig.Text = "";
            txt_app_no.Text = "";
            cmb_area_pig.Text = ""; 
            cmb_agent_id.Text= "";
            textBox4.Text = file;
            txt_nominee_pig.Text = ""; 
            txt_nominee_pig_Address.Text = "";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {

                txt_amount.Show();
                label19.Show();
                type = 0;
            }
            else
            {
                txt_amount.Hide();
                label19.Hide();
                type = 1;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                txt_amount.Hide();
                label19.Hide();
                type = 1;

            }
            else
            {
                txt_amount.Show();
                label19.Show();
                type = 0;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            balance = 0;
            cmd.CommandText = "select * from loan_Customer where Id = '" +cmb_id.Text.Trim() + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            total_paid = 0;
            while (sd.Read())
            {

                if (sd[2].ToString() != "")
                {
                    total_paid = total_paid + double.Parse(sd[2].ToString());
                }
                else
                {
                    total_paid = 0;
                }
                if (sd[5].ToString() != "")
                {
                    balance = double.Parse(sd[5].ToString());
                }
                else
                {
                   balance = 0;
                }
            }
            conn.Close();
            cmd.CommandText = "select * from Customer_loan where Id = '" + cmb_id.Text.Trim() + "'";
            string id = "";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            button11.Enabled = true;
            string name = "";
            groupBox7.Visible = true;
            while (sd.Read())
            {
                //    cmb_name.Items.Add(sd[1].ToString());
                area_loan = sd[8].ToString();
                Date_Started.Value = Convert.ToDateTime(sd[5].ToString());
                name = sd["Customer"].ToString();
                amount = double.Parse(sd["Amount"].ToString());
                id = sd[0].ToString();
            }
            conn.Close();
            cmb_name.Text = name;
            cmb_id.Text = id;
            if (Date_Started.Value.AddDays(100) < DateTime.Now)
            {
                if (total_paid < amount)
                {
                    groupBox6.Visible = true;
                    groupBox7.Enabled = false;
                    cmd.CommandText = "select * from Loan_Alert where Name = '" + cmb_name.Text.Trim() + "'";
                    label25.Show();
                    textBox15.Show();
                    textBox15.Text = (amount - total_paid).ToString();
                    cmd.Connection = conn;
                    conn.Open();
                    sd = cmd.ExecuteReader();
                    if (sd.HasRows)
                    {
                        while (sd.Read())
                        {
                            txt_total.Text = sd[3].ToString();
                        }
                    }
                    conn.Close();

                }
                else
                {
                    MessageBox.Show("New Customer Please enter details");
                }

            }
            else
            {
                groupBox6.Visible = false;
                groupBox7.Enabled = true;
            }
            
            //MessageBox.Show(total_paid.ToString());
            balance = amount - total_paid;
            date_due_loan.Value = date_paid_loan.Value.AddDays(1);
            if (groupBox7.Enabled == true)
            {
                conn.Open();
                cmd.Connection = conn;
                total_paid  = total_paid  + double.Parse(txt_amount_laon.Text);
                balance = amount - total_paid;
                cmd.CommandText = "Insert into Loan_Customer values ('" + cmb_id.Text + "','" + cmb_name.Text + "','" + txt_amount_laon.Text + "','" + date_paid_loan.Value.ToString("MM/dd/yyyy HH:mm:ss") + "','" + date_due_loan.Value.AddDays(1).ToString("MM/dd/yyyy HH:mm:ss") + "','" + total_paid.ToString() + "','" + balance.ToString() + "','" + area_loan.ToString() + "')";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated amount");
                txt_amount_laon.Text = total_paid.ToString();
                conn.Close();   

                //MessageBox.Show(total_paid.ToString());
            }
            if (groupBox7.Enabled == false)
            {
                conn.Open();
                cmd.Connection = conn;
                double total = 0;
                total = double.Parse(txt_total.Text);
                total = total + double.Parse(txt_due_after.Text);
                cmd.CommandText = "Insert into Loan_Alert values ('" + cmb_name.Text + "','" + txt_due_after.Text + "','" + due_after.Value.ToString("MM/dd/yyyy") + "','" + total.ToString() + "')";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated amount After Due");
                conn.Close();
                
            }
            cmb_id.Text = ""; 
            cmb_name.Text = "";
            txt_amount_laon.Text = "";
            txt_cmb_trade_loan.Text = "";

        }
        int hide =0;
        private void button1_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from login";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (txt_user.Text == "Admin" && txt_pass.Text == "Admin123")
            {
                MessageBox.Show("Autheticated");
                menuStrip1.Show();
                groupBox1.Hide();
                helpToolStripMenuItem.Visible = true;
                helpToolStripMenuItem.Enabled = true;
                reportsToolStripMenuItem.Visible= true;
                reportsToolStripMenuItem.Enabled = true;
                label51.Hide();
                pictureBox1.Hide();
                txt_user.Text = "" ;
                txt_pass.Text = "";
                reportsToolStripMenuItem.Enabled = true;
                hide = 0;
            }
            while (sd.Read())
            {
                if (txt_user.Text == sd[1].ToString().Trim() && txt_pass.Text == sd[2].ToString().Trim())
                {
                    MessageBox.Show("Autheticated");
                    //reportsToolStripMenuItem.Visible = false;
                    helpToolStripMenuItem.Visible = false;
                    hide = 1;
                    if ((txt_user.Text == "Mahesh" && txt_pass.Text == "Mahesh4398")|| sd[3].ToString().Trim()=="1")
                    {
                        reportsToolStripMenuItem.Visible = true;//groupBox2.Show();
                         helpToolStripMenuItem.Visible = false;
                         reportsToolStripMenuItem.Enabled = true;
                         hide = 0;
                     }
                    //groupBox3.Show();
                    //groupBox4.Show();
                    //groupBox5.Show();
                    groupBox1.Hide();
                    label51.Hide();
                    pictureBox1.Hide();
                    //groupBox1.Hide();
                    menuStrip1.Show();
                    txt_user.Text = "";
                    txt_pass.Text = "";
                    conn.Close();
                    return;
                }
                

            } 
            conn.Close();
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                cmb_name.Items.Add(sd[1].ToString());

            }

            conn.Close();

            cmd.CommandText = "select * from loan_Customer";
            
            panel3.Show();
            panel2.Hide();
            panel1.Hide();
            panel4.Hide();


        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel4.Show();
            panel2.Hide();
            panel3.Hide();
            panel1.Hide();
            cmd.CommandText = "select * from Customer_Piggy";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                cmb_name_pig.Items.Add(sd[1].ToString());
                 Date_Started.Value = Convert.ToDateTime(sd[5].ToString());


            }
            conn.Close();
        }


        private void button13_Click(object sender, EventArgs e)
        {
            panel4.Hide();
            panel6.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel2.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            panel3.Hide();

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {
            panel5.Show();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            panel6.Show();
            if (time.AddMonths(6) > DateTime.Now)
            {

                txt_total_taken.ForeColor = Color.Red;
                txt_withdraw_amount.ForeColor = Color.Red;
                
            }
            else if (time.AddMonths(6) < DateTime.Now)
            {
                txt_total_taken.ForeColor = Color.Green;
                txt_withdraw_amount.ForeColor = Color.Green;
            }
            txt_total_balance_with.Text = Total_Paid.Text;
            //panel6.Hide();
            
        }

        private void button22_Click(object sender, EventArgs e)
        {
            panel6.Hide();
            double total=0;
            double total_pig_now = 0;
            conn.Open();
            cmd.Connection = conn;
           
                if(time.AddMonths(6) > DateTime.Now)
                {

                    total = double.Parse(total_pig.ToString()) - (double.Parse(txt_withdraw_amount.Text) - ((double.Parse(txt_withdraw.Text)) * (double.Parse(txt_withdraw_amount.Text))) / 100);
                    total_pig_now = (double.Parse(txt_withdraw_amount.Text) - ((double.Parse(txt_withdraw.Text)) * (double.Parse(txt_withdraw_amount.Text))) / 100);
                    txt_total_taken.ForeColor = Color.Red;
                    cmd.CommandText = "Insert into withdrawal values('" + txt_withdraw_amount.Text + "','0','" + Cmb_name_wd.Text + "','" + dateTimePicker3.Value.ToString("MM/dd/yyyy") + "','" + txt_profit.Text + "')";
                }
                    else if(time.AddMonths(6)< DateTime.Now)
                    {
                        
                        total = double.Parse(Total_Paid.Text)  - (double.Parse(txt_withdraw_amount.Text) + ((double.Parse(txt_withdraw.Text)) * (double.Parse(txt_withdraw_amount.Text))) / 100);
                        total_pig_now = (double.Parse(txt_withdraw_amount.Text) + ((double.Parse(txt_withdraw.Text)) * (double.Parse(txt_withdraw_amount.Text))) / 100);
                        txt_total_taken.ForeColor = Color.Green;
                        cmd.CommandText = "Insert into withdrawal values('" + txt_withdraw_amount.Text + "','" + txt_profit.Text + "','" + Cmb_name_wd.Text + "','" + date_pig.Value.ToString("MM/dd/yyyy") + "','0'+)";
                }
                Total_Paid.Text = total.ToString();
                txt_total_taken.Text = total_pig_now.ToString();
                cmd.ExecuteNonQuery();
                conn.Close();
                conn.Open();
                cmd.Connection = conn;
                if (double.Parse(txt_withdraw_amount.Text) > 0)
                {
                    cmd.CommandText = "Insert into Piggy_Customer values ('" + Id.Text + "','" + Cmb_name_wd.Text + "','" + (-System.Math.Abs(double.Parse(txt_withdraw_amount.Text))).ToString() + "','" + date_pig.Value.ToString("MM/dd/yyyy") + "','" + txt_total_balance_with.Text + "','" + balance_chit.ToString() + "','" + txt_withdraw_amount.Text + "','" + area_pig1.ToString() + "')";
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Updated amount for piggy bank " + total_pig.ToString());
                }
                conn.Close();
                conn.Open();
                cmd.CommandText = "UPDATE Customer_piggy SET Start_Date ='"+ dateTimePicker3.Value.ToString("MM/dd/yyyy")+  "' where id = '"+ Id.Text +"'";
                cmd.ExecuteNonQuery();
                 MessageBox.Show("Amount Withdrawed by Customer");
                txt_amount_pig.Text = "0";
            //    txt_amount_pig.Enabled = false;
                 conn.Close();
                 conn.Open();
                 cmd.CommandText = "select * from Customer_piggy where Id = '" + Id.Text.Trim() + "'";
                 button23.Enabled = false;
                 long phone = 0;
                 conn.Close();
                 //string area = "";
                 conn.Open();
                 sd = cmd.ExecuteReader();
                 if (sd.HasRows)
                 {
                     while (sd.Read())
                     {
                         phone = long.Parse(sd[3].ToString());
                     }
                     button14.Enabled = true;

                 }
                 conn.Close();
                 string send = "http://sms2.microtreesolutions.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY=5c87f7517cc0d2989f1394a89dd16948&message=" + "Dear " + Cmb_name_wd.Text + ", the Customer of Account Number " + Id.Text + " has withdrawn the amount of " + txt_withdraw_amount.Text + "  and the Available balance in Account is " + txt_total_balance_with.Text + "for  your Pigmy account."+ System.Environment.NewLine +"Thanks-Contact 08214191755"+" &senderId=SDMFIN&routeId=1&mobileNos=" + phone + "&smsContentType=english";
            //     MessageBox.Show(send);
                 System.Net.HttpWebRequest req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(send);
                 System.Net.HttpWebResponse res = (System.Net.HttpWebResponse)req.GetResponse();
                 StreamReader sr = new StreamReader(res.GetResponseStream());
                 String file = sr.ReadToEnd();
                 sr.Close();
                 textBox4.Text = file;
            txt_withdraw_amount.Text="";
            txt_total_balance_with.Text="";
            Total_Paid.Text="";
            panel6.Hide();
            txt_withdraw_amount.Text = "0";
           
        }

        private void button22_Click_1(object sender, EventArgs e)
        {
            panel6.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txt_Interest.Text = (Convert.ToInt64(txt_Loan_Amt.Text) * double.Parse(txt_Interest.Text) / 100).ToString();
            conn.Open();
            cmd.CommandText = "Insert into Customer_loan values('" + txt_Cutomer_name.Text + "','" + txt_Address.Text + "','" + txt_phone.Text + "','" + txt_trade.Text + "','" + Date_Started.Value.ToString("MM/dd/yyyy") + "','" + txt_Interest.Text + "','" + txt_Loan_Amt.Text + "','" + Area_Combox_Pig.Text + "','" + cmb_agend_id_loan.Text + "','" + txt_application_number.Text  + "','" +  txt_Nominee.Text  + "','" + txt_Nominee_Age.Text +  "','" + txt_Nominee_rel.Text +  "','" + txt_Nominee_aadress.Text + "','"+txt_Nominee_aadress_Busioness.Text+"')";
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            conn.Close();
            cmd.CommandText = "select * from Customer_Loan where Customer = '" + txt_Cutomer_name.Text + "'";
            conn.Open();
            sd = cmd.ExecuteReader();
            string id = "";
                while (sd.Read())
                {
                    //MessageBox.Show(sd[6].ToString());
                    //amount_pig = double.Parse(sd[7].ToString());
                    id = sd[0].ToString();
              }
            conn.Close();
            conn.Open();
            cmd.CommandText = "Insert into Loan_Customer values('" + id.ToString() + "','" + txt_Cutomer_name.Text + "','0','" + Date_Started.Value.ToString("MM/dd/yyyy") + "','" + Date_Started.Value.AddDays(1).ToString("MM/dd/yyyy") + "','0','" + txt_Loan_Amt.Text + "','" + Area_Combox_Pig.Text + "')";
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
             MessageBox.Show("Successfully Created Customer");
            double amt = double.Parse(txt_Loan_Amt.Text) - double.Parse(txt_Interest.Text);
            MessageBox.Show("Amount to be given to Customer  : " + amt.ToString());
            Amt.Text = "Amount to be Givent to Customer : " +amt.ToString() +" and the id is : "+id.ToString();
            conn.Close();
            string send = "http://sms2.microtreesolutions.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY=5c87f7517cc0d2989f1394a89dd16948&message=" + "SDM Finance " + System.Environment.NewLine + " Dear " + txt_Cutomer_name.Text + ", The  Account Number for your Loan account is " + id.ToString() + " The Loan Amount  for your account is " + txt_Loan_Amt.Text + System.Environment.NewLine + "Thanks Contact 0821-4191755" + "&senderId=SDMFIN&routeId=1&mobileNos=" + txt_phone.Text + "&smsContentType=english";
            //    MessageBox.Show(send);
            System.Net.HttpWebRequest req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(send);
            System.Net.HttpWebResponse res = (System.Net.HttpWebResponse)req.GetResponse();
            StreamReader sr = new StreamReader(res.GetResponseStream());
            String file = sr.ReadToEnd();
            sr.Close();
            txt_Cutomer_name.Text = "";
            txt_id.Text = "";
            txt_Address.Text = "";
            txt_phone.Text = "";
            txt_trade.Text = "";
            txt_Loan_Amt.Text = "";
            txt_Interest.Text = "";
            txt_application_number.Text = "";
            Area_Combox_Pig.Text="";
            cmb_agend_id_loan.Text = "";
            txt_Nominee.Text = "";
            txt_Nominee_Age.Text = ""; 
            txt_Nominee_rel.Text = "";
            txt_Nominee_aadress_Busioness.Text = "";
            txt_Nominee_aadress.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sDM_GroupDataSet19.Loan_Customer' table. You can move, or remove it, as needed.
            this.loan_CustomerTableAdapter5.Fill(this.sDM_GroupDataSet19.Loan_Customer);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet17.Loan_Customer' table. You can move, or remove it, as needed.
            //this.loan_CustomerTableAdapter4.Fill(this.sDM_GroupDataSet17.Loan_Customer);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet6.Piggy_Customer' table. You can move, or remove it, as needed.
            this.piggy_CustomerTableAdapter1.Fill(this.sDM_GroupDataSet6.Piggy_Customer);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet5.Piggy_Customer' table. You can move, or remove it, as needed.
            this.piggy_CustomerTableAdapter.Fill(this.sDM_GroupDataSet5.Piggy_Customer);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet4.Loan_Customer' table. You can move, or remove it, as needed.
            //this.loan_CustomerTableAdapter3.Fill(this.sDM_GroupDataSet4.Loan_Customer);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet3.Loan_Customer' table. You can move, or remove it, as needed.
           // this.loan_CustomerTableAdapter2.Fill(this.sDM_GroupDataSet3.Loan_Customer);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet2.Loan_Customer' table. You can move, or remove it, as needed.
            //this.loan_CustomerTableAdapter1.Fill(this.sDM_GroupDataSet2.Loan_Customer);
            // TODO: This line of code loads data into the 'sDM_GroupDataSet1.Loan_Customer' table. You can move, or remove it, as needed.
            //this.loan_CustomerTableAdapter.Fill(this.sDM_GroupDataSet1.Loan_Customer);
            conn.ConnectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=SDM_Group;Integrated Security=SSPI;";
            //menuStrip1.Show();
            // groupBox1.Hide();
            //helpToolStripMenuItem.Enabled = true;
            //label51.Hide();
            //pictureBox1.Hide();
            menuStrip1.Hide();
            cmd.CommandText = "select * from Agent";
            conn.Open();
            cmd.Connection = conn;
            cmb_agent_name.Items.Clear();
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                cmb_agent_name.Items.Add(sd[1].ToString().Trim());
            }
            conn.Close();
            //for(int i = 0;i < dataGridView4.Rows.Count-1;i++)
            //{
            //    lbl_date.Text = "Date : " + DateTime.Now.Date;

            //    dataGridView4.Rows[i].Cells[4].Value = "pigmy";
            //    cmd.CommandText = "select * from Customer_loan where Address != 'Renewal'";
            //    cmd.Connection =conn;
            //    conn.Open();
            //    sd =  cmd.ExecuteReader();
            //    while (sd.Read())
            //    {
            //        dataGridView4.Rows[i].Cells[3].Value =(-1)*(int.Parse(Convert.ToDateTime(sd[5].ToString()).Subtract(DateTime.Now).Days.ToString()));

            //    }
            //    conn.Close();
            //dataGridView4.Refresh();
            //}
        }

        private void button14_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_piggy where Id = '" + Cmb_id_pigme.Text.Trim() + "'";
            cmd.Connection = conn;
            int amount_pig = 0;
            conn.Open();
            sd = cmd.ExecuteReader();
            string name = "";
            total_pig = 0;
            if (sd.HasRows)
            {
                while (sd.Read())
                {
                    area_pig = sd[10].ToString();

                    //MessageBox.Show(sd[6].ToString());
                    
                    name = sd[1].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                }
                button14.Enabled = true;
            }
            else
            {
                MessageBox.Show("New Customer Please enter details");
            }
            conn.Close();

            cmd.CommandText = "select * from piggy_Customer where Id= '" + Cmb_id_pigme.Text.Trim() + "'";
            cmd.Connection = conn;
            conn.Open();
            sd = cmd.ExecuteReader();
            //Total_Paid.Text = "0";
            while (sd.Read())
            {
                if (sd[4].ToString() == "")
                {
                }
                else
                {
                    Total_Paid.Text = sd[4].ToString();
                    total_pig = total_pig + double.Parse(sd[2].ToString());
                }
            }
            conn.Close();
            balance_chit = amount_pig - total_pig;
            txt_amount_pig.Enabled = true;
            cmb_name_pig.Text = name;

            conn.Open();
            cmd.Connection = conn;
            total_pig = total_pig + double.Parse(txt_amount_pig.Text);
            cmd.CommandText = "Insert into Piggy_Customer values ('" + Cmb_id_pigme.Text + "','" + cmb_name_pig.Text + "','" + txt_amount_pig.Text + "','" + date_pig.Value.ToString("MM/dd/yyyy HH:mm") + "','" + total_pig.ToString() + "','" + balance_chit.ToString() + "','" + txt_withdraw_amount.Text + "','" + area_pig.ToString() + "')";
            txt_amount_pig.Text = "";
            Total_Paid.Text = "";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated amount for piggy bank " + total_pig.ToString());
            conn.Close();
             Cmb_id_pigme.Text ="" ;
             cmb_name_pig.Text = "";
             cmb_trade_Pig.Text = "";
          
        }
 
        private void button26_Click(object sender, EventArgs e)        
        {
            
            cmd.CommandText = "select * from loan_Customer where Name = '" + cmb_name.Text.Trim() + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            total_paid = 0;
            while (sd.Read())
            {
                
                if (sd[2].ToString() != "")
                {
                    total_paid = total_paid + double.Parse(sd[2].ToString());
                }
                else
                {
                    total_paid = 0;
                }
                if (sd[5].ToString() != "")
                {
                    balance = double.Parse(sd[5].ToString());
                }
                else
                {
                    balance = 0;
                }
            }
            conn.Close();
            cmd.CommandText = "select * from Customer_loan where Id = '" + cmb_id.Text.Trim() + "'";
            string id= "";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            button11.Enabled = true;
            string name="";
            groupBox7.Visible = true;
            while (sd.Read())
            {
            //    cmb_name.Items.Add(sd[1].ToString());
                area_loan = sd[8].ToString();
                Date_Started.Value = Convert.ToDateTime(sd[5].ToString());
                name = sd["Customer"].ToString();
                amount = double.Parse(sd["Amount"].ToString());
                id = sd[0].ToString();
            }
            conn.Close();
            cmb_name.Text = name;
            cmb_id.Text = id;
            if (Date_Started.Value.AddDays(100) < DateTime.Now)
            {
                if (total_paid < amount)
                {
                    groupBox6.Visible = true;
                    groupBox7.Enabled = false;
                    cmd.CommandText = "select * from Loan_Alert where Name = '" + cmb_name.Text.Trim() + "'";
                    label25.Show();
                    textBox15.Show();
                    textBox15.Text  = (amount - total_paid).ToString();
                    cmd.Connection = conn;
                    conn.Open();
                    sd = cmd.ExecuteReader();
                    if (sd.HasRows)
                    {
                        while (sd.Read())
                        {
                        txt_total.Text = sd[3].ToString();
                        }
                }
                    conn.Close();
                    
                }
                    else
                    {
                        MessageBox.Show("New Customer Please enter details");
                    }
                
            }
            else
            {
              groupBox6.Visible = false  ;
              groupBox7.Enabled = true;
            }
            balance = amount - total_paid; 
            //MessageBox.Show(total_paid.ToString());
            
        }

        private void button27_Click(object sender, EventArgs e)
        {
            
            cmd.CommandText = "select * from Customer_piggy where Id = '" +  Cmb_id_pigme.Text.Trim()  + "'";
            cmd.Connection = conn;
             double amount_pig=0;
            conn.Open();
            sd = cmd.ExecuteReader();
            string name = "";
            total_pig = 0;
            if (sd.HasRows)
            {
                while (sd.Read())
                {
                    area_pig = sd[10].ToString();

                    //MessageBox.Show(sd[6].ToString());
                    if (sd[6].ToString() == "0" || sd[6].ToString()  =="False" )
                    {

                        txt_amount_pig.Text = sd[7].ToString();
                        //txt_amount_pig.Enabled = false;
                        
                        //amount_pig = double.Parse(sd[7].ToString());
                    }
                    name = sd[1].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                }
                button14.Enabled = true;
            }
            else
            {
                MessageBox.Show("New Customer Please enter details");
            }
            conn.Close();
      
            cmd.Connection = conn;
            conn.Open();
            sd = cmd.ExecuteReader();
            //Total_Paid.Text = "0";
            while (sd.Read())
            {
                if (sd[4].ToString() == "")
                {
                }
                else
                {
                    Total_Paid.Text = sd[4].ToString();
                    total_pig = total_pig + double.Parse(sd[2].ToString());
                }
             }
            conn.Close();
            balance_chit = amount_pig - total_pig;
            txt_amount_pig.Enabled = true;
            cmb_name_pig.Text = name;
            
        }

        private void button20_Click(object sender, EventArgs e)
        {

            conn.Open();
            cmd.CommandText = "Insert into Customer_chit values('" + txt_id_chit.Text + "','" + txt_Cust_chit.Text + "','" + txt_address_chit.Text + "','" + txt_phone_chit.Text + "','" + txt_trade_chit.Text + "','" + cmb_Chit.Text + "')";
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Created Customer");
            conn.Close();
            txt_id_chit.Text = "";
            txt_Cust_chit.Text = "";
            txt_address_chit.Text = "";
            txt_phone_chit.Text = "";
            txt_trade_chit.Text = "";
            
        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {
            panel5.Hide();

        }

        private void txt_id_chit_TextChanged(object sender, EventArgs e)
        {

        }

        private void Start_date_chit_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void txt_phone_chit_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Cust_chit_TextChanged(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void label31_Click(object sender, EventArgs e)
        {

        }

        private void label32_Click(object sender, EventArgs e)
        {

        }

        private void txt_amount_chit_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_trade_chit_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_address_chit_TextChanged(object sender, EventArgs e)
        {

        }

        private void End_date_chit_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button28_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Chit_Customer where name = '" + cmb_name_chit.Text.Trim() + "'";
            cmd.Connection = conn;
            conn.Open();
            int amount_pig=0;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {

                txt_total_amount.Text = sd[3].ToString();
                total_chit = double.Parse(txt_total_amount.Text);
                balance_chit = double.Parse(sd[4].ToString());
              
            }
            conn.Close();
            conn.Open();
            button25.Enabled = true;
            cmd.CommandText = "select * from Chit_Start where Started_Date = '" + cmb_chit_bid.Text.Trim() + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                DateTime hj =Convert.ToDateTime(sd[2].ToString());
                //     MessageBox.Show(hj.ToString());
                
                if (hj < DateTime.Now)
                {
                    MessageBox.Show("Chit has ended");
                    button25.Enabled = false ;
              //      return;
                }

            }
            conn.Close();
            
        }

        private void button25_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            balance_chit = balance_chit - double.Parse(txt_amount_chit_paid.Text);
            total_chit = total_chit + double.Parse(txt_amount_chit_paid.Text);
            txt_total_amount.Text = total_chit.ToString();
            cmd.CommandText = "Insert into chit_customer values ('"+ cmb_chit_name.Text + "','"+ cmb_name_chit.Text + "','" + txt_amount_chit_paid.Text + "','" + Paid_date_chit.Value.ToString("MM/dd/yyyy") + "','" + total_chit.ToString() + "','" + balance_chit.ToString()+ "')";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated amount for Chits");
            conn.Close();
        
        }







        private void button17_Click(object sender, EventArgs e)
        {

            cmd.CommandText = "select * from Customer_chit";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                cmb_name_chit.Items.Add(sd[1].ToString());
            }
            conn.Close();
            panel7.Show();
            panel2.Hide();
            panel3.Hide();
            panel1.Hide();
        
        }

        private void button29_Click(object sender, EventArgs e)
        {
            Form2 rep= new Form2();
            rep.textBox1.Text = dateTimePicker1.Value.ToString("MM/dd/yyyy 00:00:00");
            rep.textBox2.Text = dateTimePicker2.Value.ToString("MM/dd/yyyy 23:59:59");
            rep.txt_id.Text = chim;
            rep.Show();
            
            if( Rept == 0)
            {
                rep.reportViewer1.Visible=true;
                rep.reportViewer2.Visible = false;
                rep.reportViewer3.Visible = false ;
            }
            if( Rept == 1)
            {
                rep.reportViewer2.Visible=true;
                rep.reportViewer3.Visible = false;
                rep.reportViewer1.Visible = false;

            }if( Rept == 2)
            {
                rep.reportViewer3.Visible=true;
                rep.reportViewer2.Visible = false;
                rep.reportViewer1.Visible = false;
            }


        }

        private void button29_Click_1(object sender, EventArgs e)
        {
            groupBox9.Hide();
        }

        private void button24_Click(object sender, EventArgs e)
        {
            panel7.Hide();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            groupBox9.Show();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_rpt_name.Items.Clear();
            cmb_id_rpt.Items.Clear();
            cmb_trade_rpt.Items.Clear();
            while (sd.Read())
            {
                cmb_rpt_name.Items.Add(sd[1].ToString());
                cmb_id_rpt.Items.Add(sd[0].ToString());
                cmb_trade_rpt.Items.Add(sd[4].ToString());
            }
            //groupBox9.Show();
            conn.Close();
            Rept = 0;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_Piggy";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_rpt_name.Items.Clear();
            cmb_id_rpt.Items.Clear();
            cmb_trade_rpt.Items.Clear();
            while (sd.Read())
            {
                cmb_rpt_name.Items.Add(sd[1].ToString());
                cmb_id_rpt.Items.Add(sd[0].ToString());
                cmb_trade_rpt.Items.Add(sd[4].ToString());
            }
            conn.Close();
            Rept = 1;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Rept = 2;
        }

        private void button32_Click(object sender, EventArgs e)
        {
            int ad = 0;
            if (txt_user_name.Text != "" && txt_password.Text == txt_password_c.Text)
            {
                conn.Open();
                cmd.Connection = conn;
                if (chk_admin.Checked == true)
                ad =1;
                cmd.CommandText = "Insert into Login values ('" + txt_user_name.Text + "','" + txt_password_c.Text +"','" + ad.ToString()+ "')";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Use Created");
                conn.Close();
            }
            else
            {
                MessageBox.Show("Invalid UserNamr or password");
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void logToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            cmd.CommandText = "select * from Area";
            panel1.Cursor = DefaultCursor;
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            Area_Combox_Pig.Items.Clear();
            while (sd.Read())
            {

                Area_Combox_Pig.Items.Add(sd[0].ToString());
            }
            cmd.CommandText = "select * from Agent";
            conn.Close();
            conn.Open();
            cmd.Connection = conn;
            cmb_agend_id_loan.Items.Clear();
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                cmb_agend_id_loan.Items.Add(sd[1].ToString().Trim());
            }
            conn.Close();
            date_end.Value = Date_Started.Value.AddDays(100);
            panel1.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            Amt.Text = "";
        }

        private void paymentForCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_name.Items.Clear();
            cmb_id.Items.Clear();
           txt_cmb_trade_loan.Items.Clear();
            while (sd.Read())
            {
                if (sd[2].ToString() != "Renewal")
                {
                    cmb_name.Items.Add(sd[1].ToString());
                    cmb_id.Items.Add(sd[0].ToString());
                    txt_cmb_trade_loan.Items.Add(sd[4].ToString());
                }
            }
            conn.Close();            
            panel3.Show();
            panel2.Hide();
            panel1.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            renewalToolStripMenuItem.Enabled = true; 

        }

        private void addCusytomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmb_agend_id_loan.Items.Clear();
            cmd.CommandText = "select * from Area";
            conn.Open();
            cmd.Connection = conn;
            cmb_area_pig.Items.Clear();
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {

                cmb_area_pig.Items.Add(sd[0].ToString());
            }
            conn.Close();
            cmd.CommandText = "select * from Agent";
            conn.Open();
            cmd.Connection = conn;
            cmb_agent_id.Items.Clear();
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                cmb_agent_id.Items.Add(sd[1].ToString().Trim());
            }
            conn.Close();
            panel2.Show();
            //panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel1.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel4.Show();
            panel2.Hide();
            panel3.Hide();
            panel1.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            cmd.CommandText = "select * from Customer_Piggy";
            //button14.Enabled = false;
            cmb_trade_Pig.Items.Clear();
            cmb_name_pig.Items.Clear();
            Cmb_id_pigme.Items.Clear();
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                
             Date_Started.Value = Convert.ToDateTime(sd[5].ToString());
                Cmb_id_pigme.Items.Add(sd[0].ToString());
             cmb_name_pig.Items.Add(sd[1].ToString());
                cmb_trade_Pig.Items.Add(sd[4].ToString());
            }
            conn.Close();
           
        
        }

        private void addCustomerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Chit_start";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_Chit.Items.Clear();
            while (sd.Read())
            {
                cmb_Chit.Items.Add(sd[1].ToString());
            }
            conn.Close();
            panel1.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel1.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel5.Show();
        }

        private void paymentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Chit_start";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_chit_name.Items.Clear();
            cmb_chit_bid.Items.Clear();
            while (sd.Read())
            {
                cmb_chit_name.Items.Add(sd[1].ToString());
                cmb_chit_bid.Items.Add(sd[1].ToString());
            }
            conn.Close();
            panel1.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel1.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
        
            panel7.Show();
            panel2.Hide();
            panel3.Hide();
            panel1.Hide();
        
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel15.Hide();
            panel16.Hide();
            panel14.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            groupBox10.Show();
        }

        private void button31_Click(object sender, EventArgs e)
        {
            groupBox10.Hide();
        }

        private void displayReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_rpt_name.Items.Clear();
            cmb_id_rpt.Items.Clear();
            cmb_trade_rpt.Items.Clear();
            dateTimePicker1.Value = Convert.ToDateTime(DateTime.Now.Date.ToString("MM/01/yyyy"));
            while (sd.Read())
            {
                cmb_rpt_name.Items.Add(sd[1].ToString());
                cmb_id_rpt.Items.Add(sd[0].ToString());
                cmb_trade_rpt.Items.Add(sd[4].ToString());
                
            }
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel15.Hide();
            panel16.Hide();
            panel14.Hide();
           groupBox9.Show();
           groupBox14.Hide();
            conn.Close();
            
            cmd.CommandText = "select * from Area";
            conn.Open();
            cmd.Connection = conn;
            cmb_area_pig.Items.Clear();
            sd = cmd.ExecuteReader();
            cmb_area_rpt.Items.Clear();
            while (sd.Read())
            {

                   cmb_area_rpt.Items.Add(sd[0].ToString());

            }
            conn.Close();

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult  ha = MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.OKCancel);
            if (ha == DialogResult.OK)
            {
                System.Windows.Forms.Application.Exit();
            }
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult ha = MessageBox.Show("Are you sure you want to Logout?", "Logout", MessageBoxButtons.OKCancel);
            if (ha == DialogResult.OK)
            {
                groupBox1.Show();
                panel1.Hide();
                panel2.Hide();
                panel3.Hide();
                panel4.Hide();
                panel5.Hide(); 
                panel6.Hide();
                panel7.Hide();
                panel8.Hide();
                panel9.Hide();
                panel10.Hide();
                panel11.Hide();
                panel12.Hide();
                panel13.Hide();
                panel15.Hide();
                panel16.Hide();
                groupBox9.Hide();
                groupBox14.Hide();
                menuStrip1.Visible = false;
                label51.Show();
                pictureBox1.Visible = true;
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Finance Software for calculating finance.Designed By Arun(Abound infotech)", "About");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button33_Click(object sender, EventArgs e)
        {
            panel8.Show();
        }

        private void button34_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            double balance_biddy = double.Parse(cmb_amount_bid.Text) - double.Parse(txt_bid_amount.Text);
            txt_balance.Text = balance_biddy.ToString();
            bid_total= bid_total+double.Parse(txt_bid_amount.Text);
            balance_bid = balance_bid + double.Parse(txt_balance.Text);
            txt_balance.Text = balance_bid.ToString();
            txt_total_bid.Text = bid_total.ToString();
            cmd.CommandText = "Insert into Bid values ('" + cmb_chit_bid.Text + "','" + bIDDER.Text + "'," + cmb_amount_bid.Text + ",'" + date_bid.Value.ToString("MM/dd/yyyy") + "'," + txt_bid_amount.Text + "," + txt_balance.Text + "," + txt_total_bid.Text + ")";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Amount");
            conn.Close();
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void renewalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmb_name_exc.Items.Clear();
            cmb_id_loan.Items.Clear();
            for (int i = 0; i <= cmb_name.Items.Count-1 ; i++)
            {
                double total_paid = 0;
                string id = "";
                string adr = "";
                cmd.CommandText = "select * from Customer_loan where Id = '" + cmb_id.Items[i].ToString().Trim() + "'";
                conn.Open();
                cmd.Connection = conn;
                sd = cmd.ExecuteReader();
                while (sd.Read())
                {
                    Date_Started.Value = Convert.ToDateTime(sd[5].ToString());
                    amount = double.Parse(sd["Amount"].ToString());
                    id = sd[0].ToString();
                    adr=sd[2].ToString();
                    try
                    {
                       interest = double.Parse(sd[6].ToString());
                    }
                    catch(Exception ex)
                    {
                        continue;
                    }
                }
                conn.Close();
                cmd.CommandText = "select * from loan_Customer where Id = '" + cmb_id.Items[i].ToString() + "'";
                conn.Open();
                cmd.Connection = conn;
                
                sd = cmd.ExecuteReader();
                
                while (sd.Read())
                {
                    if (sd[2].ToString() != "")
                    {
                        total_paid = total_paid + double.Parse(sd[2].ToString());
                    }
                }
                        if (total_paid < amount && adr != "Renewal")
                        {
                            label25.Show();
                            textBox15.Show();
                            groupBox6.Show();
                            textBox15.Text = (amount - total_paid).ToString();
                            cmb_name_exc.Items.Add(cmb_name.Items[i].ToString());
                            cmb_id_loan.Items.Add(id);
                       }
                   
                                
                txt_total.Text = total_paid.ToString();
                panel9.Show();
                conn.Close();
                }
            panel9.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel1.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
        }

        
        string trd_r = "";

        private void button35_Click(object sender, EventArgs e)
        {
            string phone_r= "";
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Insert into Renewal values('" + cmb_id_loan.Text + "','" + cmb_name_exc.Text + "','" + textBox15.Text + "','" + ((double.Parse(textBox2.Text) * double.Parse(textBox15.Text)) / 100).ToString() + "','" + txt_due_after.Text + "','" + ((double.Parse(txt_due_after.Text) * double.Parse(textBox5.Text)) / 100) + "','" + textBox3.Text + "','" + due_after.Value.ToString("MM/dd/yyyy") + "')";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Renewal Updated");
            textBox2.Text = ((double.Parse(textBox2.Text) * double.Parse(textBox15.Text)) / 100).ToString();
            conn.Close(); 
            conn.Open();
            cmd.Connection = conn;
            //total_u = total_u + double.Parse(txt_amount_pd_up.Text);
            cmd.CommandText = "UPDATE Customer_Loan SET Address='Renewal'  where Id = '" + cmb_id_loan.Text+"'"; 
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Customer Details");
            conn.Close();
            conn.Open();
            cmd.CommandText = "select * from Customer_Loan where Customer = '" + cmb_name_exc.Text + "'";
            conn.Close();
            conn.Open();
            sd = cmd.ExecuteReader();
            string id = "";
            while (sd.Read())
            {
                //MessageBox.Show(sd[6].ToString());
                //amount_pig = double.Parse(sd[7].ToString());
                id = sd[0].ToString();
                phone_r = sd[3].ToString();
            }
            conn.Close();
            conn.Open();
            cmd.Connection = conn;
            textBox2.Text = ((double.Parse(textBox2.Text)*double.Parse(textBox15.Text))/100).ToString() ;
            cmd.CommandText = "Insert into Customer_loan values('"+ cmb_name_exc.Text + "','"+add.ToString()+"','"+ phone_r+"','" + trd_r + "','" + due_after.Value.ToString("MM/dd/yyyy") + "','" + textBox2.Text + "','" + txt_due_after.Text + "','" + Area.ToString() + "','" + agent.ToString()+ "','" +  App_no.ToString() +"')";
            cmd.ExecuteNonQuery();
            conn.Close();
            conn.Open();
            cmd.CommandText = "Insert into Loan_Customer values('" + id + "','" + cmb_name_exc.Text + "','0','" + due_after.Value.ToString("MM/dd/yyyy") + "','" + due_after.Value.AddDays(1).ToString("MM/dd/yyyy") + "','"+ phone_r+"','" + txt_due_after.Text + "','" + Area.ToString() + "')";
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            conn.Close();
            cmd.CommandText = "select * from Customer_Loan where Customer = '" + cmb_name_exc.Text + "'";
            conn.Open();
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                //MessageBox.Show(sd[6].ToString());
                //amount_pig = double.Parse(sd[7].ToString());
                id = sd[0].ToString();
            }
            conn.Close();
            MessageBox.Show("Updated Customer");
            string send = "http://sms2.microtreesolutions.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY=5c87f7517cc0d2989f1394a89dd16948&message=" + "SDM Finance"+ System.Environment.NewLine +"Dear " + cmb_name_exc.Text + ", account Has been Renewed and new  Account No is " + id + " and the Total Amount Loan is " + txt_due_after.Text + " for your account" + System.Environment.NewLine + "Thanks-Contact 08214191755" + " &senderId=SDMFIN&routeId=1&mobileNos=" + phone_r + "&smsContentType=english";
            //MessageBox.Show(send);
            System.Net.HttpWebRequest req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(send);
            System.Net.HttpWebResponse res = (System.Net.HttpWebResponse)req.GetResponse();
            StreamReader sr = new StreamReader(res.GetResponseStream());
            String file = sr.ReadToEnd();
            sr.Close();
            textBox4.Text = file;
            MessageBox.Show("Message sent");
            cmb_id_loan.Text="";
            cmb_name_exc.Text ="";
            textBox15.Text ="";
            txt_due_after.Text ="";
            textBox3.Text ="";
            txt_due_after.Text = "";
            textBox2.Text = "";
            textBox5.Text = "";
        }
        string add = "";
        private void cmb_name_exc_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id="",trd="";
            double total_paid = 0;
            cmd.CommandText = "select * from Customer_loan where Customer = '" + cmb_name_exc.Text + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                Date_Started.Value = Convert.ToDateTime(sd[5].ToString());
                id = sd[0].ToString();
                amount = double.Parse(sd["Amount"].ToString());
                trd_r = sd[4].ToString();
                Area = sd[8].ToString();
                phone = sd[3].ToString();
                  add = sd[2].ToString();
                 agent = sd[9].ToString();
                  App_no = sd[10].ToString();
                Overdue.Text  = DateTime.Now.Date.Subtract(Date_Started.Value.Date).TotalDays.ToString();
            }
            conn.Close();
            cmd.CommandText = "select * from loan_Customer where Name = '" + cmb_name_exc.Text + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                if (sd[2].ToString() != "")
                {
                    total_paid = total_paid + double.Parse(sd[2].ToString());
                }
            }
            textBox15.Text = (amount - total_paid).ToString();
            conn.Close();
            cmb_id_loan.Text = id.ToString();
       }

        private void button36_Click(object sender, EventArgs e)
        {
            panel9.Hide();
        }

        private void addChitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel1.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel10.Show();
            groupBox9.Hide();
            groupBox14.Hide();
        }

        private void button38_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Insert into Chit_start values (" + txt_Amount_total.Text + ",'" + Start_date_chit.Value.ToString("MM/dd/yyyy") + "','" + End_date_chit.Value.ToString("MM/dd/yyyy") + "')";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Amount");
            conn.Close();
        }

        private void button37_Click(object sender, EventArgs e)
        {
            panel10.Hide();
        }

        private void cmb_chit_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_chit Where Chit ='" + cmb_chit_name.Text  + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_name_chit.Items.Clear();
            bIDDER.Items.Clear();
            while (sd.Read())
            {
                cmb_name_chit.Items.Add(sd[1].ToString());
                
            }
            conn.Close();
        }

        private void bidToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel1.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
        
            panel8.Show();
        }

        private void cmb_chit_bid_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_chit Where Chit ='" + cmb_chit_bid.Text + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_name_chit.Items.Clear();
            bIDDER.Items.Clear();
            while (sd.Read())
            {
                bIDDER.Items.Add(sd[1].ToString());

            }
            conn.Close();
            cmd.CommandText = "select * from chit_start Where Started_Date ='" + cmb_chit_bid.Text + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_name_chit.Items.Clear();
           
            while (sd.Read())
            {
                cmb_amount_bid.Items.Add(sd[0].ToString());

            }
            conn.Close();
            cmd.CommandText = "select * from Bid Where Chit ='" + cmb_chit_bid.Text + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_name_chit.Items.Clear();
            
            while (sd.Read())
            {
                bid_total = double.Parse(sd[5].ToString());
                balance_bid = double.Parse(sd[6].ToString());
                cmb_amount_bid.Items.Add(sd[6].ToString());
               
            }
            conn.Close();


        }

        private void bIDDER_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button39_Click(object sender, EventArgs e)
        {
           panel8.Hide();
        }

        private void button40_Click(object sender, EventArgs e)
        {
            double total=0,total_pig_now=0;
            //double tot = double.Parse(txt_withdraw_amount.Text);
            if (time.AddMonths(6) > DateTime.Now)
            {
                txt_profit.ForeColor = Color.Green;
                 total = double.Parse(txt_total_balance_with.Text) - (double.Parse(txt_withdraw_amount.Text));
                total_pig_now = (double.Parse(txt_withdraw_amount.Text) - ((double.Parse(txt_withdraw.Text)) * (double.Parse(txt_withdraw_amount.Text))) / 100);
                txt_total_taken.ForeColor = Color.Green;
                lbl_duration.Text = "No of months still left : "+((time.AddMonths(6).Month - DateTime.Now.Month) + 12 * ((time.AddMonths(6).Year) - (DateTime.Now.Year))).ToString();
                
            }
            else if (time.AddMonths(6) < DateTime.Now)
            {
                txt_profit.ForeColor = Color.Red;
                total = double.Parse(txt_total_balance_with.Text) - (double.Parse(txt_withdraw_amount.Text));
                total_pig_now = (double.Parse(txt_withdraw_amount.Text) + ((double.Parse(txt_withdraw.Text)) * (double.Parse(txt_withdraw_amount.Text))) / 100);
                txt_total_taken.ForeColor = Color.Red;
                lbl_duration.Text = "No of months overdue in Months : " +(DateTime.Now.Month - (time.AddMonths(6).Month) + 12 * ((DateTime.Now.Year) - (time.AddMonths(6).Year))).ToString();
            }
            txt_total_balance_with.Text = total.ToString();
            txt_total_taken.Text  = "No of months overdue in Months";
            txt_total_taken.Text = total_pig_now.ToString();
            txt_profit.Text = ((double.Parse(txt_withdraw.Text)) * (double.Parse(txt_withdraw_amount.Text)) / 100).ToString();
            button23.Enabled = true;

            
        }

        private void txt_due_after_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void button41_Click(object sender, EventArgs e)
        {
            double bal = double.Parse(txt_due_after.Text) - (double.Parse(textBox15.Text) + ((double.Parse(textBox2.Text) * double.Parse(textBox15.Text)) / 100) + ((double.Parse(txt_due_after.Text) * double.Parse(textBox5.Text)) / 100));
            textBox3.Text = bal.ToString();
        }

        private void withdrawToolStripMenuItem_Click(object sender, EventArgs e)
        {

            cmd.CommandText = "select * from Customer_Piggy";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            Id.Items.Clear();
            Cmb_name_wd.Items.Clear();
            while (sd.Read())
            {

                Date_Started.Value = Convert.ToDateTime(sd[5].ToString());
                Id.Items.Add(sd[0].ToString());
                Cmb_name_wd.Items.Add(sd[1].ToString());
            }
            conn.Close();
            panel1.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel1.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            panel6.Show();
            
        }

        private void Cmb_id_pigme_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_piggy where Id = '" + Cmb_id_pigme.Text.Trim() + "'";
            string name = "";
            double amount_pig = 0;
            string stn = "";
            double cl = 0;
            conn.Open();
            //button14.Enabled = false;
            sd = cmd.ExecuteReader();
            if (sd.HasRows)
            {
                while (sd.Read())
                {
                    area_pig = sd[10].ToString();
                    stn = sd[4].ToString();
                    //MessageBox.Show(sd[6].ToString());
                    
                    //amount_pig = double.Parse(sd[7].ToString());
                                       name = sd[1].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                    cl = double.Parse(sd[13].ToString());
                }
            

            }
            else
            {
                MessageBox.Show("New Customer Please enter details");
            }
            txt_amount_pig.Enabled = true;
            if (cl > 0)
            {
                MessageBox.Show("Account Closed");
                txt_amount_pig.Enabled = false;
            }
            conn.Close();
            cmb_name_pig.Text = name;
            cmb_trade_Pig.Text = stn;

        }

        private void cmb_name_pig_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_piggy where Customer = '" + cmb_name_pig.Text + "'";
            conn.Open();
            sd = cmd.ExecuteReader();
            double cl = 0;
            string id = "",stn="";
             // button14.Enabled = false;
            if (sd.HasRows)
            {
                while (sd.Read())
                {


                    //MessageBox.Show(sd[6].ToString());
                    area_pig = sd[10].ToString();
                    //amount_pig = double.Parse(sd[7].ToString());
                    id = sd[0].ToString();
                    stn = sd[4].ToString();
                    cl = double.Parse(sd[13].ToString());
                    time = DateTime.Parse(sd[5].ToString());
                }
                
            }
            else
            {
                MessageBox.Show("New Customer Please enter details");
            }
            txt_amount_pig.Enabled = true;
            if (cl > 0)
            {
                MessageBox.Show("Account Closed");
                txt_amount_pig.Enabled = false;
            }

            conn.Close();
            Cmb_id_pigme.Text = id;
            cmb_trade_Pig.Text = stn;
        }

        private void Id_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_piggy where Id = '" + Id.Text.Trim() + "'";
            button23.Enabled = false;
            string name ="";
            //string area = "";
            int amount_pig = 0;
            conn.Open();
            sd = cmd.ExecuteReader();
            if (sd.HasRows)
            {
                while (sd.Read())
                {


                    //MessageBox.Show(sd[6].ToString());

                    //amount_pig = double.Parse(sd[7].ToString());
                    name = sd[1].ToString();
                    area_pig1 = sd[10].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                }
                button14.Enabled = true;
                
            }
            else
            {
                MessageBox.Show("New Customer Please enter details");
            }
            conn.Close();
            Cmb_name_wd.Text = name;
            cmd.CommandText = "select * from piggy_Customer where Id= '" + Id.Text.Trim() + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {

                txt_total_balance_with.Text = sd[3].ToString();
                total_pig = double.Parse(sd["Total"].ToString());
                lbl_duration.ForeColor = Color.Green;
                 
            }
            conn.Close();
            balance_chit = amount_pig - total_pig;
            txt_amount_pig.Enabled = true;
            if (time.AddMonths(6) > DateTime.Now)
            {

                txt_total_taken.ForeColor = Color.Green;
                txt_withdraw_amount.ForeColor = Color.Green;
                lbl_duration.ForeColor = Color.Green;

            }
            else if (time.AddMonths(6) < DateTime.Now)
            {
                txt_total_taken.ForeColor = Color.Red;
                txt_withdraw_amount.ForeColor = Color.Red;
                lbl_duration.ForeColor = Color.Red;
            }
            //txt_total_balance_with.Text = Total_Paid.Text;
            txt_total_balance_with.Text = total_pig.ToString();
            panel6.Show();
        }

        private void Cmb_name_wd_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_piggy where Customer = '" + Cmb_name_wd.Text.Trim() + "'";
            button23.Enabled = false;
            int amount_pig = 0;
            conn.Open();
            sd = cmd.ExecuteReader();
            string id="";
            if (sd.HasRows)
            {
                while (sd.Read())
                {


                    //MessageBox.Show(sd[6].ToString());
                    area_pig1 = sd[10].ToString();
                    //amount_pig = double.Parse(sd[7].ToString());
                    id = sd[0].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                }
                button14.Enabled = true;
            }
            else
            {
                MessageBox.Show("New Customer Please enter details");
            }
            conn.Close();
            Id.Text = id;
            cmd.CommandText = "select * from piggy_Customer where Id= '" + Id.Text.Trim() + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {

                txt_total_balance_with.Text = sd[3].ToString();
                total_pig = double.Parse(sd["Total"].ToString());
            }
            conn.Close();
            balance_chit = amount_pig - total_pig;
            txt_amount_pig.Enabled = true;
            if (time.AddMonths(6) > DateTime.Now)
            {

                txt_total_taken.ForeColor = Color.Green;
                txt_withdraw_amount.ForeColor = Color.Green;
                lbl_duration.ForeColor = Color.Green;
            }
            else if (time.AddMonths(6) < DateTime.Now)
            {
                txt_total_taken.ForeColor = Color.Red;
                txt_withdraw_amount.ForeColor = Color.Red;
                lbl_duration.ForeColor = Color.Red;
            }
            txt_total_balance_with.Text = total_pig.ToString();
            panel6.Show();
        }

        private void piggyBankToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button42_Click(object sender, EventArgs e)
        {

        }
        string area_loan="",area_pig="";
        private void cmb_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan where Customer = '" + cmb_name.Text + "'";
            conn.Open();
            string id = "",trdn = "";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                area_loan = sd[8].ToString();
                id = sd[0].ToString();
                trdn = sd[4].ToString();
            }
            conn.Close();
            cmb_id.Text = id;
            txt_cmb_trade_loan.Text = trdn;
        }

        private void cmb_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan where Id = '" + cmb_id.Text.Trim() + "'";
            conn.Open();
            string name="",trdn="";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                area_loan = sd[8].ToString();    
                name = sd["Customer"].ToString();
                trdn = sd[4].ToString();
                
            }
            conn.Close();
            cmb_name.Text = name;
            txt_cmb_trade_loan.Text = trdn;
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        string name_up, amt_up, id_up, date_up;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
     
        }

        private void button45_Click(object sender, EventArgs e)
        {
            double total_u, balance_u;
            conn.Open();
            cmd.Connection = conn;
            total_u = double.Parse(dataGridView1.SelectedRows[0].Cells[5].Value.ToString());
            balance_u = double.Parse(dataGridView1.SelectedRows[0].Cells[6].Value.ToString());
            if (double.Parse(txt_amount_pd_up.Text) < double.Parse(amt_up) )
            {
                total_u = total_u - (double.Parse(amt_up) - double.Parse(txt_amount_pd_up.Text));
                balance_u = balance_u - (double.Parse(amt_up) - double.Parse(txt_amount_pd_up.Text));
            }
            else
            {
                total_u = (double.Parse(txt_amount_pd_up.Text) - double.Parse(amt_up)) + total_u;
                balance_u = balance_u + (double.Parse(txt_amount_pd_up.Text) - double.Parse(amt_up));
            }
            //total_u = total_u + double.Parse(txt_amount_pd_up.Text);
            cmd.CommandText = "UPDATE Loan_Customer SET Name ='" + txt_name_update.Text + "', Amount='" + txt_amount_pd_up.Text + "' ,Date_Paid='" + date_pd_up.Value.ToString("MM/dd/yyyy") + "' ,Id='" + txt_id_up.Text + "',Total='"+total_u.ToString()+"',Balance = '"+balance_u.ToString()+"'  where Id = '" + id_up.ToString() + "' and Name = '" + name_up.ToString() + "'and Amount='" + amt_up.ToString() + "'and Date_Paid='" + date_up.ToString() + "'";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Customer");
            conn.Close();
            
        }

        private void button44_Click(object sender, EventArgs e)
        {

        }

        private void button42_Click_1(object sender, EventArgs e)
        {
            panel11.Hide();
        }

        private void updatreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //panel11.Visible = true;
            panel11.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel1.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
        }
        int total_loan_up;
        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            txt_id_up.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txt_name_update.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txt_amount_pd_up.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            date_pd_up.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            id_up = txt_id_up.Text;
            name_up = txt_name_update.Text;
            amt_up = txt_amount_pd_up.Text;
            date_up = date_pd_up.Value.ToString("MM/dd/yyyy");
        }

        private void button43_Click(object sender, EventArgs e)
        {
            //dataGridView1.Update();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Loan_Customer where Date_Paid = '" + date_show.Value.ToString("MM/dd/yyyy hh:mm:ss") + "'", conn);
            System.Data.DataTable dt = new System.Data.DataTable();
           
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();



        }

        private void button44_Click_1(object sender, EventArgs e)
        {
            //dataGridView1.Update();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Piggy_Customer where Date_Paid = '" + Convert.ToDateTime(date_now.Value.ToString("MM/dd/yyyy hh:mm:ss")) + "'", conn);
            System.Data.DataTable dt = new System.Data.DataTable();
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            dataGridView2.Refresh();


        }

        private void button46_Click(object sender, EventArgs e)
        {
            panel12.Hide();
        }

        private void button47_Click(object sender, EventArgs e)
        {
            
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "UPDATE Piggy_Customer SET Name ='" + txt_name_pig_up.Text + "', Amount_paid='" + txt_pig_amount_up.Text + "' ,Date_Paid='" + date_pd_pig.Value.ToString("MM/dd/yyyy") + "' ,Id='" + txt_id_up_pig.Text + "'  where Id = '" + id_upp.ToString() + "' and Name = '" + name_upp.ToString() + "'and Amount_paid='" + amt_upp.ToString() + "'and Date_Paid='" + date_upp.ToString() + "'";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Customer");
            conn.Close();
            
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        string name_upp, amt_upp, id_upp, date_upp;
        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            txt_id_up_pig.Text = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();
            txt_name_pig_up.Text = dataGridView2.SelectedRows[0].Cells[1].Value.ToString();
            txt_pig_amount_up.Text = dataGridView2.SelectedRows[0].Cells[2].Value.ToString();
            date_pd_pig.Text = dataGridView2.SelectedRows[0].Cells[3].Value.ToString();
            id_upp = txt_id_up_pig.Text;
            name_upp = txt_name_pig_up.Text;
            amt_upp =txt_pig_amount_up.Text;
            date_upp = date_pd_pig.Value.ToString("MM/dd/yyyy");
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            panel1.Show();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel1.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            panel12.Show();
        
        }

        private void button48_Click(object sender, EventArgs e)
        {
         panel13.Hide();   
        }

        private void button49_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Insert into Area values('" + txt_area.Text + "')";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Area");
            txt_area.Text = "";
            conn.Close();
        }

        private void panel13_Paint(object sender, PaintEventArgs e)
        {

        }

        private void enterAreaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            panel13.Show();
        }

        private void loanToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        string Area = "",agent="",App_no="",phone="";
        private void cmb_id_loan_SelectedIndexChanged(object sender, EventArgs e)
        {
            double total_paid = 0;
            cmd.CommandText = "select * from Customer_loan where Id = '" + cmb_id_loan.Text  + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                Date_Started.Value = Convert.ToDateTime(sd[5].ToString());
                Name = sd[1].ToString();
                amount = double.Parse(sd["Amount"].ToString());
                Overdue.Text = DateTime.Now.Date.Subtract(Date_Started.Value.Date).TotalDays.ToString();
                trd_r = sd[4].ToString();
                Area = sd[8].ToString();
                agent = sd[9].ToString();
                App_no = sd[10].ToString();
                phone = sd[3].ToString();
                add = sd[2].ToString();    

            }
            conn.Close();
            cmd.CommandText = "select * from loan_Customer where Id = '" + cmb_id_loan.Text + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                if (sd[2].ToString() != "")
                {
                    total_paid = total_paid + double.Parse(sd[2].ToString());
                }
            }
            textBox15.Text = (amount - total_paid).ToString();
            conn.Close();
            cmb_name_exc.Text = Name.ToString();
            
        }
        string chim;
        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            groupBox11.Hide();
            chim = "";
            groupBox12.Hide();
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            groupBox11.Show();
            chim = cmb_id_rpt.Text;
            groupBox12.Hide();
        }

        private void cmb_id_rpt_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = "",strn = "";
            if (Rept == 0)
            {
                cmd.CommandText = "select * from Customer_Loan where Id = '" + cmb_id_rpt.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());

                        //amount_pig = double.Parse(sd[7].ToString());
                        name = sd[1].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                        strn = sd[4].ToString();
                    }
                }
                conn.Close();
            }
            else
            {
                cmd.CommandText = "select * from Customer_Piggy where Id = '" + cmb_id_rpt.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());

                        //amount_pig = double.Parse(sd[7].ToString());
                        name = sd[1].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                        strn = sd[4].ToString();
                    }
                }
                conn.Close();
            }
            cmb_rpt_name.Text = name;
            cmb_trade_rpt.Text = strn;
            chim = cmb_id_rpt.Text;
        }

        private void cmb_rpt_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id = "",strn="";
            if (Rept == 0)
            {
                cmd.CommandText = "select * from Customer_Loan where Customer = '" + cmb_rpt_name.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());
                        //amount_pig = double.Parse(sd[7].ToString());
                        id = sd[0].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                        strn = sd[4].ToString();
                    }
                }
                conn.Close();
            }
            else
            {
                cmd.CommandText = "select * from Customer_Piggy where Customer = '" + cmb_rpt_name.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());
                        strn = sd[4].ToString();
                        //amount_pig = double.Parse(sd[7].ToString());
                        id = sd[0].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                    }
                }
                 conn.Close();
            }
            cmb_id_rpt.Text = id;
            chim = cmb_id_rpt.Text;
            cmb_trade_rpt.Text = strn;
        }

        
        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            groupBox12.Show();
            groupBox11.Hide();
            chim = cmb_area_rpt.Text;
        }

        private void cmb_area_rpt_SelectedIndexChanged(object sender, EventArgs e)
        {
            chim = cmb_area_rpt.Text;
        }

        private void groupBox11_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_all_name.Items.Clear();
            cmb_id_all.Items.Clear();
            cmb_trade_rep.Items.Clear();
            while (sd.Read())
            {
                cmb_all_name.Items.Add(sd[1].ToString());
                cmb_id_all.Items.Add(sd[0].ToString());
                cmb_trade_rep.Items.Add(sd[4].ToString());

            }
            //groupBox9.Show();
            conn.Close();
            all = 0;
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_Piggy";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_all_name.Items.Clear();
            cmb_id_all.Items.Clear();
            cmb_trade_rep.Items.Clear();
            while (sd.Read())
            {
                cmb_all_name.Items.Add(sd[1].ToString());
                cmb_id_all.Items.Add(sd[0].ToString());
                cmb_trade_rep.Items.Add(sd[4].ToString());
            }
            conn.Close();
            all = 1;
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            groupBox17.Hide();
            arl = "";
            groupBox16.Hide();
        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            groupBox17.Show();
            arl = cmb_id_all.Text;
            groupBox16.Hide();
        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
            groupBox16.Show();
            groupBox17.Hide();
            arl = cmb_area_all.Text;
        }

        private void cmb_all_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id = "",trnd ="";
            if (all == 0)
            {
                cmd.CommandText = "select * from Customer_Loan where Customer = '" + cmb_all_name.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());
                        //amount_pig = double.Parse(sd[7].ToString());
                        id = sd[0].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                        trnd = sd[4].ToString();
                    }
                }
                conn.Close();
            }
            else
            {
                cmd.CommandText = "select * from Customer_Piggy where Customer = '" +  cmb_all_name.Text.Trim()  + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());

                        //amount_pig = double.Parse(sd[7].ToString());
                        id = sd[0].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                        trnd = sd[4].ToString();
                    }
                }
                conn.Close();
            }
            cmb_id_all.Text = id;
            arl = cmb_id_all.Text;
            cmb_trade_rep.Text = trnd;
        }

        private void cmb_id_all_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = "" ,trnd=""; 
            if (Rept == 0)
            {
                cmd.CommandText = "select * from Customer_Loan where Id = '" + cmb_id_all.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());

                        //amount_pig = double.Parse(sd[7].ToString());
                        name = sd[1].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                        trnd = sd[4].ToString();
                    }
                }
                conn.Close();
            }
            else
            {
                cmd.CommandText = "select * from Customer_Piggy where Id = '" + cmb_id_all.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());

                        //amount_pig = double.Parse(sd[7].ToString());
                        name = sd[1].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                        trnd = sd[4].ToString();
                    }
                }
                conn.Close();
            }
            cmb_all_name.Text = name;
            arl = cmb_id_all.Text;
            cmb_trade_rep.Text = trnd;
        }

        private void cmb_area_all_SelectedIndexChanged(object sender, EventArgs e)
        {
            arl = cmb_area_all.Text;
        }

        private void totalCollectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_all_name.Items.Clear();
            cmb_id_all.Items.Clear();
            cmb_trade_rep.Items.Clear();
            dateTimePicker5.Value = Convert.ToDateTime(DateTime.Now.Date.ToString("01/01/yyyy"));
            while (sd.Read())
            {
                cmb_all_name.Items.Add(sd[1].ToString());
                cmb_id_all.Items.Add(sd[0].ToString());
                cmb_trade_rep.Items.Add(sd[4].ToString());

            }
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox14.Hide();
            groupBox14.Hide();
            groupBox14.Show();
            conn.Close();

            cmd.CommandText = "select * from Area";
            conn.Open();
            cmd.Connection = conn;
            cmb_area_pig.Items.Clear();
            sd = cmd.ExecuteReader();
            cmb_area_all.Items.Clear();
            while (sd.Read())
            {

               cmb_area_all.Items.Add(sd[0].ToString());

            }
            conn.Close();
        }

        private void button51_Click(object sender, EventArgs e)
        {
            Form3 all1 = new Form3();
            all1.txt_d1.Text = dateTimePicker5.Value.ToString("MM/dd/yyyy");
            all1.txt_d2.Text = dateTimePicker4.Value.ToString("MM/dd/yyyy");
            all1.txt_id.Text = arl;
            all1.Show();
            if (all == 0)
            {
                all1.reportViewer1.Visible = true;
                all1.reportViewer2.Visible = false;
                if (hide == 1)
                {
                    all1.reportViewer1.Visible = false;
                    all1.reportViewer2.Visible = false;
                    all1.reportViewer3.Visible = true;
                    // rep.reportViewer3.Visible = false ;
                }
            }
            if (all == 1)
            {
                all1.reportViewer2.Visible = true;
                all1.reportViewer1.Visible = false;
                //rep.reportViewer1.Visible = false;
            }

        }

        private void pigmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.Show();
            //rep.reportViewer1.Hide();
            rep.reportViewer2.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer1.Show();
        }

        private void button50_Click(object sender, EventArgs e)
        {
            groupBox14.Hide();
        }

        private void button53_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Insert into Agent values('" + txt_Agent.Text + "','"+ txt_agenrt_name.Text +"')";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Agent");
            txt_agenrt_name.Text = "";
            txt_Agent.Text = "";
            conn.Close();
        }

        private void enterAgentIdToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            panel14.Show();
        }

        private void button52_Click(object sender, EventArgs e)
        {
            panel14.Hide();
        }

        private void cmb_trade_Pig_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_piggy where Trade_Name = '" + cmb_trade_Pig.Text  + "'";
            string name = "",id="";
              int amount_pig = 0,cl=0 ;
            string stn = "";
            conn.Open();
            //button14.Enabled = false;
            sd = cmd.ExecuteReader();
            if (sd.HasRows)
            {
                while (sd.Read())
                {
                    area_pig = sd[10].ToString();
                    stn = sd[4].ToString();
                    //MessageBox.Show(sd[6].ToString());
                    id= sd[0].ToString();
                    //amount_pig = double.Parse(sd[7].ToString());
                    name = sd[1].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                    cl = int.Parse(sd[13].ToString());
                }
            

            }
            else
            {
                MessageBox.Show("New Customer Please enter details");
            }
            txt_amount_pig.Enabled = true;
            if (cl > 0)
            {
                MessageBox.Show("Account Closed");
                txt_amount_pig.Enabled = false;
            }
            conn.Close();
            cmb_name_pig.Text = name;
            Cmb_id_pigme.Text = id;
       }

        private void txt_cmb_trade_loan_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan where Trade_Name = '" + txt_cmb_trade_loan.Text.Trim() + "'";
            conn.Open();
            string name="",id="";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                area_loan = sd[8].ToString();    
                name = sd["Customer"].ToString();
                id = sd[0].ToString();
                
            }
            conn.Close();
            cmb_name.Text = name;
            cmb_id.Text = id;
           
                    
        }

        private void panel15_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel15_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id = "",stn = "";
            if (pay_check == 0)
            {
                cmd.CommandText = "select * from Customer_Loan where Customer = '" + cmb_Name_pay.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());
                        //amount_pig = double.Parse(sd[7].ToString());
                        id = sd[0].ToString();
                        stn = sd[4].ToString();
                         time = DateTime.Parse(sd[5].ToString());
                    }
                }
                conn.Close();
            }
            else
            {
                cmd.CommandText = "select * from Customer_Piggy where Customer = '" + cmb_Name_pay.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {   
                        //MessageBox.Show(sd[6].ToString());
                        //amount_pig = double.Parse(sd[7].ToString());
                        id = sd[0].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                        stn = sd[4].ToString();
                    }
                }
                conn.Close();
            }
            cmb_id_pay.Text = id;
            cmb_trade_pay.Text = stn;
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = "", id = "", trdn = "";
            if (pay_check == 1)
            {
            cmd.CommandText = "select * from Customer_piggy where Trade_Name = '" + cmb_trade_pay.Text.Trim()  + "'";
            conn.Open();
            //button14.Enabled = false;
            sd = cmd.ExecuteReader();
             while (sd.Read())
                {
                    
                    
                    //MessageBox.Show(sd[6].ToString());
                    id= sd[0].ToString();
                    //amount_pig = double.Parse(sd[7].ToString());
                    name = sd[1].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                }
            
                conn.Close();
            }
            else
            {
                cmd.CommandText = "select * from Customer_loan where Trade_Name = '" + cmb_trade_pay.Text.Trim() + "'";
                conn.Open();
                cmd.Connection = conn;
                sd = cmd.ExecuteReader();
                while (sd.Read())
                {
                    
                    id = sd[0].ToString();
                    //amount_pig = double.Parse(sd[7].ToString());
                    name = sd[1].ToString();
            

                }
                conn.Close();
            }
            
            cmb_Name_pay.Text = name;
            cmb_id_pay.Text = id;
        }

        private void button54_Click(object sender, EventArgs e)
        {
            if (pay_check == 0)
            {
                cmd.CommandText = "select * from Loan_Customer where Id = '" + cmb_id_pay.Text.Trim() + "' and Date_Paid = '" + dateTimePicker6.Value.ToString("MM/dd/yyyy") + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    MessageBox.Show("Payment made");
                }
                else
                {
                    MessageBox.Show("Payment Not made");
                }
                conn.Close();

            }
            else
            {
                cmd.CommandText = "select * from Piggy_Customer where Id = '" + cmb_id_pay.Text.Trim() + "' and Date_Paid = '" + dateTimePicker6.Value.ToString("MM/dd/yyyy") + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    MessageBox.Show("Payment made");
                }
                else
                {
                    MessageBox.Show("Payment Not made");
                }
                conn.Close();
            }



        }

        private void cmb_id_pay_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = "",stn="";
            if (pay_check == 0)
            {
                cmd.CommandText = "select * from Customer_Loan where Id = '" + cmb_id_pay.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());
                        stn = sd[4].ToString();
                        //amount_pig = double.Parse(sd[7].ToString());
                        name = sd[1].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                    }
                }
                conn.Close();
            }
            else
            {
                cmd.CommandText = "select * from Customer_Piggy where Id = '" + cmb_id_pay.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());
                        stn = sd[4].ToString();
                            //amount_pig = double.Parse(sd[7].ToString());
                         name = sd[1].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                    }
                }
                conn.Close();
            }
            cmb_Name_pay.Text = name;
            cmb_trade_pay.Text = stn;
                   
        }
        int pay_check = 0;
        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_loan";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_Name_pay.Items.Clear();
            cmb_id_pay.Items.Clear();
            cmb_trade_pay.Items.Clear();
            while (sd.Read())
            {
                cmb_Name_pay.Items.Add(sd[1].ToString());
                cmb_id_pay.Items.Add(sd[0].ToString());
                cmb_trade_pay.Items.Add(sd[4].ToString());
            }
            //groupBox9.Show();
            conn.Close();
            pay_check = 0;
        }

        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_Piggy";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_Name_pay.Items.Clear();
            cmb_trade_pay.Items.Clear();
            cmb_id_pay.Items.Clear();
            while (sd.Read())
            {
                cmb_Name_pay.Items.Add(sd[1].ToString());
                cmb_id_pay.Items.Add(sd[0].ToString());
                cmb_trade_pay.Items.Add(sd[4].ToString());
             }
            conn.Close();
            pay_check = 1;
        }

        private void button55_Click(object sender, EventArgs e)
        {
            panel15.Hide();
        }

        private void checkPaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            panel15.Show();
            cmd.CommandText = "select * from Customer_loan";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_Name_pay.Items.Clear();
            cmb_id_pay.Items.Clear();
            cmb_trade_pay.Items.Clear();
            while (sd.Read())
            {
                cmb_Name_pay.Items.Add(sd[1].ToString());
                cmb_id_pay.Items.Add(sd[0].ToString());
                cmb_trade_pay.Items.Add(sd[4].ToString());
            }
            //groupBox9.Show();
            conn.Close();
            pay_check = 0;
        }

        private void cmb_trade_rep_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmb_trade_rpt_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name="",id="";
            if (Rept == 1)
            {
                cmd.CommandText = "select * from Customer_piggy where Trade_Name = '" + cmb_trade_rpt.Text.Trim() + "'";
                conn.Open();
                //button14.Enabled = false;
                sd = cmd.ExecuteReader();
                while (sd.Read())
                {


                    //MessageBox.Show(sd[6].ToString());
                    id = sd[0].ToString();
                    //amount_pig = double.Parse(sd[7].ToString());
                    name = sd[1].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                }

                conn.Close();
            }
            else
            {
                cmd.CommandText = "select * from Customer_loan where Trade_Name = '" + cmb_trade_rpt.Text.Trim() + "'";
                conn.Open();
                cmd.Connection = conn;
                sd = cmd.ExecuteReader();
                while (sd.Read())
                {

                    id = sd[0].ToString();
                    //amount_pig = double.Parse(sd[7].ToString());
                    name = sd[1].ToString();


                }
                conn.Close();
            }

            cmb_id_rpt.Text = id;
            cmb_rpt_name.Text = name;
            chim = cmb_id_rpt.Text;

            

        }
        string name_m = "", trade_m = "", date_m = "", id_m = "",phone_m="",address_m="",app_mj="",area_m="",agent_m="";
        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_nam_main.Text = dataGridView3.SelectedRows[0].Cells[1].Value.ToString();
            txt_id_Main.Text = dataGridView3.SelectedRows[0].Cells[0].Value.ToString();
            txt_trade_main.Text = dataGridView3.SelectedRows[0].Cells[4].Value.ToString();
            txt_address_up.Text = dataGridView3.SelectedRows[0].Cells[2].Value.ToString();
            txt_phone_up.Text = dataGridView3.SelectedRows[0].Cells[3].Value.ToString();
            if (check == 0)
            {
                txt_app_up.Text = dataGridView3.SelectedRows[0].Cells[10].Value.ToString();
                cmb_agent_up.Text = dataGridView3.SelectedRows[0].Cells[9].Value.ToString();
                cmb_area_up.Text = dataGridView3.SelectedRows[0].Cells[8].Value.ToString();
            }
            else
            {
                txt_app_up.Text = dataGridView3.SelectedRows[0].Cells[12].Value.ToString();
                cmb_agent_up.Text = dataGridView3.SelectedRows[0].Cells[11].Value.ToString();
                cmb_area_up.Text = dataGridView3.SelectedRows[0].Cells[10].Value.ToString();
            }
            phone_m = txt_phone_up.Text;
            id_m = txt_id_Main.Text;
            name_m = txt_nam_main.Text;
            trade_m = txt_trade_main.Text;
            address_m = txt_address_up.Text;
            app_mj = txt_app_up.Text;
            area_m = cmb_area_up.Text;
            agent_m = cmb_agent_up.Text;
        }
        int check=0;
        private void button56_Click(object sender, EventArgs e)
        {
            if (check == 0)
            {
                //this.customer_loanTableAdapter.Fill(this.sDM_GroupDataSet8.Customer_loan);r
                SqlDataAdapter da = new SqlDataAdapter("Select * from Customer_Loan where Started_Date between '" + dateTimePicker8.Value.ToString("MM/dd/yyyy") + "' and '" + dateTimePicker7.Value.ToString("MM/dd/yyyy") + "'", conn);
                System.Data.DataTable dt = new System.Data.DataTable();
                dataGridView3.Columns.Clear();
                dataGridView3.AutoGenerateColumns = true;
                da.Fill(dt);
                dataGridView3.DataSource = dt;
                dataGridView3.Refresh();
            }
            else
            {
                //this.customer_PiggyTableAdapter.Fill(this.sDM_GroupDataSet8.Customer_Piggy);
                SqlDataAdapter da = new SqlDataAdapter("Select * from Customer_Piggy where Start_Date  between '" + dateTimePicker8.Value.ToString("MM/dd/yyyy") + "' and '" + dateTimePicker7.Value.ToString("MM/dd/yyyy") + "'", conn);
                System.Data.DataTable dt = new System.Data.DataTable();
                // dataGridView3.Columns[5].HeaderCell.Value = "Start_Date";
                dataGridView3.Columns.Clear();
                dataGridView3.AutoGenerateColumns = true;
                da.Fill(dt);
                dataGridView3.DataSource = dt;
                dataGridView3.Refresh();
            }
            

        }

        private void button58_Click(object sender, EventArgs e)
        {
            if (check == 0)
            {
                conn.Open();
                cmd.Connection = conn;
                //total_u = total_u + double.Parse(txt_amount_pd_up.Text);
                cmd.CommandText = "UPDATE Customer_Loan SET Customer ='" + txt_nam_main.Text + "' ,Phone='" + txt_phone_up.Text + "' ,Trade_Name = '" + txt_trade_main.Text + "' ,Address='" + txt_address_up.Text + "' ,Application_Number = '" + txt_app_up.Text + "' ,Agent='" + cmb_agent_up.Text + "' ,Area = '" + cmb_area_up.Text + "'  where Id = '" + id_m.ToString() + "' and Customer = '" + name_m.ToString() + "'and Trade_Name='" + trade_m.ToString() + "'and Phone ='" + phone_m.ToString() + "'and Address ='" + address_m.ToString() + "'and Application_Number ='" + app_mj.ToString() + "'and Area ='" + area_m.ToString() + "'and Agent ='" + agent_m.ToString() + "'";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Customer Details");
                conn.Close();
            }
            else
            {
                conn.Open();
                cmd.Connection = conn;
                //total_u = total_u + double.Parse(txt_amount_pd_up.Text);
                cmd.CommandText = "UPDATE Customer_Piggy SET Customer ='" + txt_nam_main.Text + "' ,Phone='" + txt_phone_up.Text + "' ,Trade_Name = '" + txt_trade_main.Text + "' ,Address='" + txt_address_up.Text + "' ,Application_Number = '" + txt_app_up.Text + "' ,Agent='" + cmb_agent_up.Text + "' ,Area = '" + cmb_area_up.Text + "'  where Id = '" + id_m.ToString() + "' and Customer = '" + name_m.ToString() + "'and Trade_Name='" + trade_m.ToString() + "'and Phone ='" + phone_m.ToString() + "'and Address ='" + address_m.ToString() + "'and Application_Number ='" + app_mj.ToString() + "'and Area ='" + area_m.ToString() + "'and Agent ='" + agent_m.ToString() + "'";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Customer Details");
                conn.Close();
            }
            
            
        }

        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            check = 0;
        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
            check = 1;
        }

        private void updateCuisrtomerDetailsLoanPiggyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmb_agend_id_loan.Items.Clear();
            cmd.CommandText = "select * from Area";
            conn.Open();
            cmd.Connection = conn;
            cmb_area_up.Items.Clear();
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {

                cmb_area_up.Items.Add(sd[0].ToString());
            }
            conn.Close();
            cmd.CommandText = "select * from Agent";
            conn.Open();
            cmd.Connection = conn;
            cmb_agent_up.Items.Clear();
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                cmb_agent_up.Items.Add(sd[1].ToString());
            }
            conn.Close();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            panel16.Show();
        }

        private void button57_Click(object sender, EventArgs e)
        {
            panel16.Hide();
        }

        private void txt_Agent_TextChanged(object sender, EventArgs e)
        {
            int a;   
            if (int.TryParse(txt_Agent.Text,out a))
            {
            }
            else
            {
                MessageBox.Show("Enter Number only");
                txt_Agent.Text = "";
                return;
            }
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void date_now_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txt_phone_up_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_trade_main_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void panel16_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dateTimePicker6_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Cmb_name_pig_cl_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id="", stn="";
            cmd.CommandText = "select * from Customer_Piggy where Customer = '" + Cmb_name_pig_cl.Text.Trim() + "'";
            conn.Open();
            sd = cmd.ExecuteReader();
            if (sd.HasRows)
            {
                while (sd.Read())
                {
                    //MessageBox.Show(sd[6].ToString());
                    //amount_pig = double.Parse(sd[7].ToString());
                    id = sd[0].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                    stn = sd[4].ToString();
                }
            }
            conn.Close();
            cmb_id_cl.Text = id;
            cmb_trade_Cl.Text = stn;
            
        }

        private void cmb_trade_Cl_SelectedIndexChanged(object sender, EventArgs e)
        {
               string name = "", id = "";
                cmd.CommandText = "select * from Customer_piggy where Trade_Name = '" + cmb_trade_Cl.Text.Trim()+ "'";
                conn.Open();
                //button14.Enabled = false;
                sd = cmd.ExecuteReader();
                while (sd.Read())
                {


                    //MessageBox.Show(sd[6].ToString());
                    id = sd[0].ToString();
                    //amount_pig = double.Parse(sd[7].ToString());
                    name = sd[1].ToString();
                    time = DateTime.Parse(sd[5].ToString());
                }
                conn.Close();
                cmb_id_cl.Text = id;
                Cmb_name_pig_cl.Text = name;
                
            
        }

        private void cmb_id_cl_SelectedIndexChanged(object sender, EventArgs e)
        {
            
                string stn="",name="";
                cmd.CommandText = "select * from Customer_Piggy where Id = '" +cmb_id_cl.Text.Trim() + "'";
                conn.Open();
                sd = cmd.ExecuteReader();
                if (sd.HasRows)
                {
                    while (sd.Read())
                    {

                        //MessageBox.Show(sd[6].ToString());
                        stn = sd[4].ToString();
                            //amount_pig = double.Parse(sd[7].ToString());
                         name = sd[1].ToString();
                        time = DateTime.Parse(sd[5].ToString());
                    }
                    //conn.Close();
                }
                conn.Close();
            Cmb_name_pig_cl.Text= name;
            cmb_trade_Cl.Text = stn;
            
           
        }

        private void button60_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.CommandText = "UPDATE Customer_piggy SET acc_close ='1' where id = '" + cmb_id_cl.Text + "'";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Customer Account Has been Closed");
            //    txt_amount_pig.Enabled = false;
            panel6.Hide();
            conn.Close();
        }

        private void panel17_Paint(object sender, PaintEventArgs e)
        {

        }

        private void closePigmyAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_Piggy";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            Cmb_name_pig_cl.Items.Clear();
            cmb_trade_Cl.Items.Clear();
            cmb_id_cl.Items.Clear();
            while (sd.Read())
            {
                Cmb_name_pig_cl.Items.Add(sd[1].ToString());
                cmb_id_cl.Items.Add(sd[0].ToString());
                cmb_trade_Cl.Items.Add(sd[4].ToString());
            }
            conn.Close();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            panel17.Show();
        }

        private void button59_Click(object sender, EventArgs e)
        {
            panel17.Hide();
        }

        private void panel14_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label51_Click(object sender, EventArgs e)
        {

        }

        private void groupBox14_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox10_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void button60_Click_1(object sender, EventArgs e)
        {
            conn.Open();
            cmd.CommandText = "UPDATE Customer_piggy SET acc_close ='0' where id = '" + cmb_id_cl.Text + "'";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Customer Account Has been Opened");
            //    txt_amount_pig.Enabled = false;
            panel6.Hide();
            conn.Close();
       
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void totalCollectionPigmyLoanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel18.Show();
        }
        int pay = 0;
        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {
            pay = 0;
        }
        
        private void button62_Click(object sender, EventArgs e)
        {
            double balance_p = 0, total_p = 0, amt = 0;
            double tot = 0, balance_p1 = 0;
            if (pay == 0)
            {
                cmd.CommandText = "select * from Customer_loan where Address != 'Renewal'";
                cmd.Connection = conn;
                conn.Open();
                sd = cmd.ExecuteReader();
                cmb_id.Items.Clear();

                while (sd.Read())
                {
                    cmb_id.Items.Add(sd[0].ToString());
                    amt += double.Parse(sd[7].ToString());
                }
                conn.Close();
                for (int l = 0; l <= cmb_id.Items.Count - 1; l++)
                {
                    cmd.CommandText = "select * from Loan_Customer where Id= '" + cmb_id.Items[l].ToString() + "'";
                    cmd.Connection = conn;
                    conn.Open();
                    sd = cmd.ExecuteReader();
                    //Total_Paid.Text = "0";
                    while (sd.Read())
                    {
                        if (sd[2].ToString() == "")
                        {
                        }
                        else
                        {
                            total_p = total_p + double.Parse(sd[2].ToString());
                        }

                    }

                    balance_p = amt - total_p;
                    if (balance_p == 0)
                    {
                        balance_p1 = balance_p1 + balance_p;
                    }
                    conn.Close();
                }
                MessageBox.Show("The Total Payment balance is : " + balance_p);
                MessageBox.Show("The Total Payment is : " + total_p);
                label120.Text = "The Total Amount Balance : " + balance_p;
                label121.Text = "The Total Amount Collected : " + total_p;

            }
            else
            {
            cmd.CommandText = "select * from Customer_piggy where Acc_close ='0'";
            cmd.Connection = conn;
            conn.Open();
            sd = cmd.ExecuteReader();
            cmb_id.Items.Clear();
            if (sd.HasRows)
            {
                while (sd.Read())
                {
                    cmb_id.Items.Add(sd[0].ToString());
                }
              
            }
            conn.Close();
                for(int m =0;m<=cmb_id.Items.Count-1;m++)
                {
            cmd.CommandText = "select * from piggy_Customer where Id= '" + cmb_id.Items[m].ToString() + "'";
            cmd.Connection = conn;
            conn.Open();
            sd = cmd.ExecuteReader();
            //Total_Paid.Text = "0";
            while (sd.Read())
            {
                if (sd[4].ToString() == "")
                {
                }
                else
                {
                tot = tot + double.Parse(sd[2].ToString());
                }
            }
            conn.Close();
                }
                MessageBox.Show("The Total Payment is : " + tot);
                label120.Text = "";
                label121.Text = "The Total Amount Collected : " + tot;
           
            }


        }

        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {
            pay = 1;
        }

        private void button63_Click(object sender, EventArgs e)
        {
            panel18.Hide();
        }

        private void nearCompletionOfLoanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 arun = new Form4();
            arun.reportViewer1.Hide();
            //arun.reportViewer1.Hide();
            //arun.reportViewer2.Hide();
            arun.reportViewer4.Hide();
            arun.reportViewer3.Hide();
            arun.reportViewer2.Show();
            arun.Show();

        }

        private void button64_Click(object sender, EventArgs e)
        {
            lm = 0;
            if (cmb_agent.Text == "All")
            {
                cmd.CommandText = "select * from Customer_loan";
                
            }
            else
            {
                cmd.CommandText = "select * from Customer_loan where Agent = '" + cmb_agent.Text + "'";
            }
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_id.Items.Clear();
            cmb_name_msg.Items.Clear();
            while (sd.Read())
            {
                if (sd[2].ToString() != "Renewal")
                {
                         cmb_id_msg.Items.Add(sd[0].ToString());
                         cmb_name_msg.Items.Add(sd[1].ToString());
                        //txt_cmb_trade_loan.Items.Add(sd[3].ToString());                    
                    
                }
            }
            conn.Close();
           button70.Enabled = true;
            
        }

        private void button65_Click(object sender, EventArgs e)
        {
            groupBox18.Hide();
        }

        private void sendMessageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox18.Show();
             conn.Open();
             cmd.CommandText = "select * from Agent";
            cmb_agent.Items.Clear();
             sd = cmd.ExecuteReader();
            while(sd.Read())
            {
                cmb_agent.Items.Add(sd[1].ToString());
            }
           cmb_agent.Items.Add("All");
           conn.Close();  
         }

        private void button66_Click(object sender, EventArgs e)
        {
            lm = 1;
            double total=0,bal=0,amt=0;
            long phone = 0;
            string name = "";
            if (cmb_agent.Text == "All")
            {
                cmd.CommandText = "select * from Customer_Piggy";
            }
            else
            {
                cmd.CommandText = "select * from Customer_Piggy where Agent = '" + cmb_agent.Text + "'";
            }
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            cmb_name_msg.Items.Clear();
            cmb_id_msg.Items.Clear();
            while (sd.Read())
            {
                if (sd[13].ToString() != "1")
                {
                         cmb_id_msg.Items.Add(sd[0].ToString());
                         cmb_name_msg.Items.Add(sd[1].ToString());
                         //txt_cmb_trade_loan.Items.Add(sd[3].ToString());                    
                    
                }
            }
            conn.Close();
            button70.Enabled = true;
            
        }

        private void contactInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Contact Number: Arun-8892964412", "About Us");
        }

        private void button67_Click(object sender, EventArgs e)
        {
            if (check == 0)
            {
                conn.Open();
                cmd.Connection = conn;
                //total_u = total_u + double.Parse(txt_amount_pd_up.Text);
                cmd.CommandText = "DELETE FROM Customer_Loan WHERE  Id = '" + id_m.ToString() + "' and Customer = '" + name_m.ToString() + "'and Trade_Name='" + trade_m.ToString() + "'and Phone ='" + phone_m.ToString() + "'and Address ='" + address_m.ToString() + "'and Application_Number ='" + app_mj.ToString() + "'and Area ='" + area_m.ToString() + "'and Agent ='" + agent_m.ToString() + "'";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Customer Details");
                conn.Close();
            }
            else
            {
                conn.Open();
                cmd.Connection = conn;
                //total_u = total_u + double.Parse(txt_amount_pd_up.Text);
                cmd.CommandText = "DELETE FROM Customer_Piggy WHERE  Id = '" + id_m.ToString() + "' and Customer = '" + name_m.ToString() + "'and Trade_Name='" + trade_m.ToString() + "'and Phone ='" + phone_m.ToString() + "'and Address ='" + address_m.ToString() + "'and Application_Number ='" + app_mj.ToString() + "'and Area ='" + area_m.ToString() + "'and Agent ='" + agent_m.ToString() + "'";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Customer Details");
                conn.Close();
            }
        }

        private void button68_Click(object sender, EventArgs e)
        {
            
            conn.Open();
            cmd.Connection = conn;
            //total_u = total_u + double.Parse(txt_amount_pd_up.Text);
            cmd.CommandText = "DELETE FROM Loan_Customer where Id = '" + id_up.ToString() + "' and Name = '" + name_up.ToString() + "'and Amount='" + amt_up.ToString() + "'and Date_Paid='" + date_up.ToString() + "'";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted Customer");
            conn.Close();
        }

        private void button69_Click(object sender, EventArgs e)
        {
            
            conn.Open();
            cmd.Connection = conn;
            //total_u = total_u + double.Parse(txt_amount_pd_up.Text);
            cmd.CommandText = "DELETE FROM Piggy_Customer  where Id = '" + id_upp.ToString() + "' and Name = '" + name_upp.ToString() + "'and Amount_paid='" + amt_upp.ToString() + "'and Date_Paid='" + date_upp.ToString() + "'";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted Customer");
            conn.Close();
        }

        private void pigmyReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            
        }

        private void loanReportToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button70_Click(object sender, EventArgs e)
        {
            
        }

        private void radioButton21_CheckedChanged(object sender, EventArgs e)
        {
            age = 0;
        }
        int age;
        private void radioButton22_CheckedChanged(object sender, EventArgs e)
        {
            age = 1;
        }

        private void button71_Click(object sender, EventArgs e)
        {
           
            

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.customer_loanTableAdapter1.FillBy(this.sDM_GroupDataSet9.Customer_loan);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
        
        private void fillByToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button72_Click(object sender, EventArgs e)
        {
            //panel20.Visible = true;
            double amout = 0,bal=0;
            SqlDataAdapter da = new SqlDataAdapter();
            System.Data.DataTable  dt = new System.Data.DataTable();
            System.Data.DataTable dt2 = new System.Data.DataTable();
            if (chk_all.Checked == false)
            {
            cmd.CommandText = "Select * from Customer_loan Where Agent = '" + cmb_agent_name.Text + "' and Address != 'Renewal'";
            }
            else
            {
            cmd.CommandText = "Select * from Customer_loan Where Address != 'Renewal'";
            }
            da.SelectCommand = cmd;
            int l=1;
            dt.Clear();
            da.Fill(dt);
            //dataGridView4.DataSource = dt;
            Microsoft.Office.Interop.Excel.Application xla = new Microsoft.Office.Interop.Excel.Application();
            Workbook xlb = xla.Workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
            Worksheet ws = (Microsoft.Office.Interop.Excel.Worksheet)xlb.Worksheets[1];
            ws.Cells.Range["A1:G1"].Font.Bold = true;
            //ws.Cells.Range["A1:F1"].HorizontalAlignment = XlHAlign.xlHAlignCenterAcrossSelection;
            ws.Cells.Range["A1:G1"].Font.Size = 20;
            ws.Cells[1,2] = "SDM Finance Collection Sheet";
            ws.Cells[3,1] = "Date : " +  col_Day.Value;
            ws.Cells[3,5] = "Agent : " + cmb_agent_name.Text;
            ws.Cells[5,1] = "SI No.";
            ws.Cells[5,2] = "Id";
            ws.Cells[5,3] = "Customer";
            ws.Cells[5,4] = "Days";
            ws.Cells[5,5] = "Trade Name";
            ws.Cells[5,6] = "Scheme";
            ws.Cells[5,7] = "Amount";
            l = 6;
            int h=0;
            for (int j = 1; j <= dt.Rows.Count; j++)
            {
                conn.Open();
                cmd.CommandText = "Select * from loan_Customer Where id = " + dt.Rows[j - 1][0].ToString();
                sd = cmd.ExecuteReader();
                amout = 0;
                bal = 0;
                while (sd.Read())
                {
                   amout = amout + double.Parse(sd[2].ToString());
                }
               
                bal = double.Parse(dt.Rows[j - 1][7].ToString()) - amout;
                if(bal == 0)
                {
                    conn.Close();
                    l++;
                    continue;
                    
                }
                conn.Close();
                h++;
                ws.Cells[j+6,1] = h;
               // MessageBox.Show(dt.Rows[j - 1][1].ToString());
                ws.Cells[j + 6, 2] = dt.Rows[j - 1][0];
                ws.Cells[j + 6, 3] = dt.Rows[j - 1][1];
                ws.Cells[j + 6, 5] = dt.Rows[j - 1][4];
                ws.Cells[j + 6,4] = DateTime.Now.Subtract(Convert.ToDateTime(dt.Rows[j-1][5])).Days;
                ws.Cells[j + 6,6] = "Loan";
                ws.Cells.Range["A" + (j+6) + ":G" + (j+6)].BorderAround(BorderStyle.FixedSingle);
                ws.Columns.ColumnWidth = 7;
                ws.Columns["E:E"].ColumnWidth = 25;
                ws.Columns["C:C"].ColumnWidth = 25;
                l++;
            }
            if (chk_all.Checked == false)
            {
                cmd.CommandText = "Select * from Customer_Piggy Where Agent = '" + cmb_agent_name.Text + "' and Acc_Close ='0'";
            }
            else
            {
                cmd.CommandText = "Select * from Customer_Piggy Where Acc_Close ='0'";
            }
            da.SelectCommand = cmd;
            dt2.Clear();
            l++;
            da.Fill(dt2);
            //dataGridView4.DataSource = dt;
            for(int s = 1; s <= (dt2.Rows.Count); s++)
            {
                h++;
                ws.Cells[l, 1] = h;
                ws.Cells[l, 2] = dt2.Rows[s - 1][0];
                ws.Cells[l, 3] = dt2.Rows[s - 1][1];
                ws.Cells[l, 5] = dt2.Rows[s - 1][4];
                ws.Cells[l, 4] = DateTime.Now.Subtract(Convert.ToDateTime(dt2.Rows[s - 1][5])).Days;
                ws.Cells[l,6] = "Pigmy";
                ws.Cells.Range["A" + l + ":G" + l].BorderAround(BorderStyle.FixedSingle);
                l++;
            }
            ws.Cells[l, 5] = "Total";
            ws.Cells[l + 6, 1] = " Signature of Proprieter: ";
            ws.Cells[l + 6, 5] = " Signature of Agent: ";
            ws.Range["A5:A"+l].BorderAround(BorderStyle.FixedSingle);
            ws.Range["A5:G5"].BorderAround(BorderStyle.FixedSingle);
            ws.Range["B5:A" + l].BorderAround(BorderStyle.FixedSingle);
            ws.Range["C5:A" + l].BorderAround(BorderStyle.FixedSingle);
            ws.Range["D5:A" + l].BorderAround(BorderStyle.FixedSingle);
            ws.Range["E5:A" + l].BorderAround(BorderStyle.FixedSingle);
            ws.Range["F5:A" + l].BorderAround(BorderStyle.FixedSingle);
            ws.Range["G5:A" + l].BorderAround(BorderStyle.FixedSingle);
            ws.Range["B7:G" + l].Columns.Sort(ws.Range["B7:G" + l].Columns[2], XlSortOrder.xlAscending);          //    cmd.CommandText = "select * from Agent";
        //    conn.Open();
        //    cmd.Connection = conn;
        //    cmb_agent_name.Items.Clear();
        //    sd = cmd.ExecuteReader();
        //    while (sd.Read())
        //    {
        //        cmb_agent_name.Items.Add(sd[1].ToString().Trim());
        //    }
        //    conn.Close();
        //    for (int i = 0; i < dataGridView4.Rows.Count - 1; i++)
        //    {
        //        //lbl_date.Text = "Date : " + DateTime.Now.Date;
                //lbl_Agent.Text = "Agent : " + cmb_agent_name.Text;
               // dataGridView4.Rows[i].Cells[4].Value = "Loan";
              //  dataGridView4.Rows[i].Cells[3].Value = DateTime.Now.Subtract(Convert.ToDateTime(dataGridView4.Rows[i].Cells[5].Value)).Days;


            //}
            xla.Dialogs[Microsoft.Office.Interop.Excel.XlBuiltInDialog.xlDialogPrint].Show();
            xla.Visible = true;
            //xla.Dialogs[Microsoft.Office.Interop.Excel.XlBuiltInDialog.xlDialogPrint].Show();
            //xlb.Close();
            xla.Quit();
            
        }

        private void loanReportToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            panel21.Show();
        }

        private void button73_Click(object sender, EventArgs e)
        {
            //panel20.Hide();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            
            
            

        }

        private void button74_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void fillByToolStripButton_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.loan_CustomerTableAdapter2.FillBy(this.sDM_GroupDataSet3.Loan_Customer);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button75_Click(object sender, EventArgs e)
        {
            panel21.Hide();
        }
        int chc=0,lm =0;
        private void radioButton21_CheckedChanged_1(object sender, EventArgs e)
        {
            chc = 0;
            groupBox19.Hide();
        }

        private void radioButton22_CheckedChanged_1(object sender, EventArgs e)
        {
            chc = 1;
            
            groupBox19.Show();
        }

        private void button70_Click_1(object sender, EventArgs e)
        {
                    double total = 0, bal = 0, amt = 0;
                    int no_day_l = 0, no_day_p = 0;
            long phone = 0;
            string name = "";
            if (lm == 0)
            {
                for (int l = 0; l <= cmb_id_msg.Items.Count - 1; l++)
                {
                    total = 0;
                    if (chc == 0)
                    {
                        cmd.CommandText = "select * from Loan_Customer where Id = '" + cmb_id_msg.Items[l].ToString() + "'";
                    }
                    else
                    {
                        cmd.CommandText = "select * from Loan_Customer where Id = '" + cmb_id_msg.Text + "'";
                    }
                    conn.Open();
                    sd = cmd.ExecuteReader();
                    if (sd.HasRows)
                    {
                        while (sd.Read())
                        {
                            total = total + double.Parse(sd[2].ToString());
                        }

                    }
                    conn.Close();
                    if (chc == 0)
                    {
                        cmd.CommandText = "select * from Customer_loan where Id = '" + cmb_id_msg.Items[l].ToString() + "'";
                    }
                    else
                    {
                        cmd.CommandText = "select * from Customer_loan where Id = '" + cmb_id_msg.Text + "'";
                    }
                    conn.Open();
                    cmd.Connection = conn;
                    sd = cmd.ExecuteReader();

                    while (sd.Read())
                    {
                        phone = long.Parse(sd[3].ToString());
                        amt = double.Parse(sd[7].ToString());
                        name = sd[1].ToString();
                        no_day_l = (DateTime.Now).Subtract(Convert.ToDateTime(sd[5].ToString())).Days;
                    }
                    bal = amt - total;
                    if (bal == 0)
                    {
                        if(chc == 0)
                        conn.Close();
                        continue;
                    }
                    conn.Close();
                    if (chc == 1)
                    {
                        string send = "http://sms2.microtreesolutions.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY=5c87f7517cc0d2989f1394a89dd16948&message=" + "SDM Finance " + System.Environment.NewLine + " Dear " + name + ", The bal amt Acc No " + cmb_id_msg.Text + " is " + bal + " Ttl amt pd is " + total + " The no of days is "+ no_day_l.ToString()+ System.Environment.NewLine + "Thanks-Contact 08214191755" + " &senderId=SDMFIN&routeId=1&mobileNos=" + phone + "&smsContentType=english";
                       // MessageBox.Show(send);
                    System.Net.HttpWebRequest req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(send);
                    System.Net.HttpWebResponse res = (System.Net.HttpWebResponse)req.GetResponse();
                    StreamReader sr = new StreamReader(res.GetResponseStream());
                    String file = sr.ReadToEnd();
                    sr.Close();
                    textBox4.Text = file;
                    break;
                    }
                    else
                    {
                        string send = "http://sms2.microtreesolutions.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY=5c87f7517cc0d2989f1394a89dd16948&message=" + "SDM Finance " + System.Environment.NewLine + " Dear " + name + ", The bal amt Acc No " + cmb_id_msg.Items[l].ToString() + " is " + bal + " Ttl amt pd is " + total + " The no of days is " + no_day_l.ToString() + System.Environment.NewLine + "Thanks-Contact 08214191755" + " &senderId=SDMFIN&routeId=1&mobileNos=" + phone + "&smsContentType=english";
                        //MessageBox.Show(send);
                    System.Net.HttpWebRequest req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(send);
                    System.Net.HttpWebResponse res = (System.Net.HttpWebResponse)req.GetResponse();
                    StreamReader sr = new StreamReader(res.GetResponseStream());
                    String file = sr.ReadToEnd();
                    sr.Close();
                    textBox4.Text = file;
                    }
                }
                MessageBox.Show("Message Sent to Customers", "SDM message");
            }
            else
            {
                for (int l = 0; l <= cmb_id_msg.Items.Count - 1; l++)
                {
                    total = 0;
                    if (chc == 0)
                    {
                        cmd.CommandText = "Select * from Piggy_Customer where Id = '" + cmb_id_msg.Items[l].ToString() + "'";
                    }
                    else
                    {
                        cmd.CommandText = "Select * from Piggy_Customer where Id = '" + cmb_id_msg.Text + "'";
                    }
                    conn.Open();
                    sd = cmd.ExecuteReader();
                    if (sd.HasRows)
                    {
                        while (sd.Read())
                        {
                            total = total + double.Parse(sd[2].ToString());
                        }

                    }
                    conn.Close();
                    if (chc == 0)
                    {
                        cmd.CommandText = "Select * from Customer_Piggy where Id = '" + cmb_id_msg.Items[l].ToString() + "'";
                    }
                    else
                    {
                        cmd.CommandText = "Select * from Customer_Piggy where Id = '" + cmb_id_msg.Text + "'";
                    }
                    conn.Open();
                    cmd.Connection = conn;
                    sd = cmd.ExecuteReader();

                    while (sd.Read())
                    {
                        phone = long.Parse(sd[3].ToString());
                        name = sd[1].ToString();
                        no_day_p = (DateTime.Now).Subtract(Convert.ToDateTime(sd[5].ToString())).Days;
                    }
                    conn.Close();
                    if(chc ==1)
                    {
                        string send = "http://sms2.microtreesolutions.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY=5c87f7517cc0d2989f1394a89dd16948&message=" + "SDM Finance " + System.Environment.NewLine + " Dear " + name + ", The Total Amt for Acc No " + cmb_id_msg.Text.ToString() + " is " + total + " No of days is " + no_day_p + " for your Pigmy acct for mnth "+ DateTime.Now.ToString("MMMM")+ System.Environment.NewLine + "Thanks-Contact 08214191755" + "&senderId=SDMFIN&routeId=1&mobileNos=" + phone + "&smsContentType=english";
                    //MessageBox.Show(send);
                    System.Net.HttpWebRequest req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(send);
                    System.Net.HttpWebResponse res = (System.Net.HttpWebResponse)req.GetResponse();
                    StreamReader sr = new StreamReader(res.GetResponseStream());
                    String file = sr.ReadToEnd();
                    sr.Close();
                    textBox4.Text = file;
                    break;
                    }
                    else
                    {
                        string send = "http://sms2.microtreesolutions.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY=5c87f7517cc0d2989f1394a89dd16948&message=" + "SDM Finance " + System.Environment.NewLine + " Dear " + name + ", The Total Amt for Acc No " + cmb_id_msg.Items[l].ToString() + " is " + total + " No of days is " + no_day_p + " for your Pigmy acct for mnth " + DateTime.Now.ToString("MMMM") + System.Environment.NewLine + "Thanks-Contact 08214191755" + "&senderId=SDMFIN&routeId=1&mobileNos=" + phone + "&smsContentType=english";
                    //MessageBox.Show(send);
                    System.Net.HttpWebRequest req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(send);
                    System.Net.HttpWebResponse res = (System.Net.HttpWebResponse)req.GetResponse();
                    StreamReader sr = new StreamReader(res.GetResponseStream());
                    String file = sr.ReadToEnd();
                    sr.Close();
                    textBox4.Text = file;
                    }
                }
                MessageBox.Show("Message Sent to Customers", "SDM message");
            }
        }
        

        

     
       
     
        
       
         
         
   

        private void cmb_id_msg_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lm ==0)
            {
            cmd.CommandText = "select * from Customer_loan where Id = '" + cmb_id_msg.Text.Trim() + "'";
            conn.Open();
            string name="",trdn="";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                name = sd["Customer"].ToString();
                trdn = sd[4].ToString();
                
            }
            conn.Close();
            cmb_name_msg.Text = name;
            }
            else
            {
            cmd.CommandText = "select * from Customer_Piggy where Id = '" + cmb_id_msg.Text.Trim() + "'";
            conn.Open();
            string name="",trdn="";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                name = sd["Customer"].ToString();
                             
            }
            conn.Close();
            cmb_name_msg.Text = name;
            }
                
        }

        private void cmb_name_msg_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lm == 0)
            {
                cmd.CommandText = "select * from Customer_loan where Customer = '" + cmb_name_msg.Text + "'";
                conn.Open();
                string id = "";
                cmd.Connection = conn;
                sd = cmd.ExecuteReader();
                while (sd.Read())
                {

                    id = sd[0].ToString();

                }
                conn.Close();
                cmb_id_msg.Text = id;
            }
            else
                {
                    cmd.CommandText = "select * from Customer_Piggy where Customer = '" + cmb_name_msg.Text + "'";
                    conn.Open();
                    string id = "";
                    cmd.Connection = conn;
                    sd = cmd.ExecuteReader();
                    while (sd.Read())
                    {

                        id = sd[0].ToString();

                    }
                    conn.Close();
                    cmb_id_msg.Text = id;
                }
        
        }

        private void panel19_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel21_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button71_Click_1(object sender, EventArgs e)
        {

        }

        private void button71_Click_2(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Insert into Expenses values('" + txt_exp.Text + "')";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Expenses");
            txt_exp.Text = "";
            conn.Close();
        }

        private void button73_Click_1(object sender, EventArgs e)
        {
            panel19.Hide();
        }

        private void addExpensesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel19.Show();
        }

        private void dateTimePicker9_ValueChanged(object sender, EventArgs e)
        {
            label123.Text = "Expenses For Month of " + dateTimePicker9.Value.ToString("MMMM");
        }

        private void button76_Click(object sender, EventArgs e)
        {
            panel20.Hide();
        }

        private void button74_Click_1(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Insert into Profit_Loss values('Profit_Loan'," + lbl_intrest.Text +  ",0,'" + dateTimePicker9.Value.ToString("MMMM yyyy") + "')";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "Insert into Profit_Loss values('Profit_Pigmy'," + lbl_pig_int.Text + ",0,'" + dateTimePicker9.Value.ToString("MMMM yyyy") + "')";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "Insert into Profit_Loss values('Loss_Pigmy',0," + lbl_loss.Text + ",'" + dateTimePicker9.Value.ToString("MMMM yyyy") + "')";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Account Expenses");
            lbl_intrest.Text = "";
            lbl_pig_int.Text = "";
            lbl_loss.Text = "";
            conn.Close();
        }

        private void profitLossAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 arun = new Form5();
            arun.Visible = true;
        }

        private void button77_Click(object sender, EventArgs e)
        {
            int intrest = 0,profit=0,loss=0;
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Select * from Customer_loan where Started_Date BETWEEN '" + dateTimePicker9.Value.ToString("MM/01/yyyy hh:mm:ss") + "' AND '" + dateTimePicker9.Value.ToString("MM/dd/yyyy hh:mm:ss") + "'";
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                intrest = intrest + int.Parse(sd[6].ToString());
            }
            lbl_intrest.Text = intrest.ToString();
            //            MessageBox.Show("Updated Expenses");
            conn.Close();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Select * from Renewal where Date BETWEEN '" + dateTimePicker9.Value.ToString("01/dd/yyyy hh:mm:ss") + "' AND '" + dateTimePicker9.Value.ToString("MM/dd/yyyy hh:mm:ss") + "'";
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                intrest = intrest + int.Parse(sd[3].ToString());
            }
            lbl_intrest.Text = intrest.ToString();
            //            MessageBox.Show("Updated Expenses");
            //lbl_intrest.Text = "";
            conn.Close();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Select * from Withdrawal where Date BETWEEN '" + dateTimePicker9.Value.ToString("01/dd/yyyy hh:mm:ss") + "' AND '" + dateTimePicker9.Value.ToString("MM/dd/yyyy hh:mm:ss") + "'";
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                profit = profit + int.Parse(sd[4].ToString());
                loss = loss + int.Parse(sd[1].ToString());          
            }
            lbl_pig_int.Text = profit.ToString();
            lbl_loss.Text = loss.ToString();
            //            MessageBox.Show("Updated Expenses");
            //lbl_intrest.Text = "";
            conn.Close();

        }

        private void groupBox20_Enter(object sender, EventArgs e)
        {

        }

        private void profitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Select * from Expenses";
            sd = cmd.ExecuteReader();
            cmb_exp.Items.Clear();
            while (sd.Read())
            {
                cmb_exp.Items.Add(sd[0]);
            }
            //            MessageBox.Show("Updated Expenses");
            //lbl_intrest.Text = "";
            panel20.Show();
            conn.Close();
        }

        private void label130_Click(object sender, EventArgs e)
        {

        }

        private void button78_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Insert into Profit_Loss values('" + cmb_exp.Text + "',0,'"+ txt_exp_amt.Text +"','"+ dateTimePicker9.Value.ToString("MMMM yyyy")  +"')";
            cmd.ExecuteNonQuery();
             MessageBox.Show("Updated Expenses");
            cmb_exp.Text = "";
            txt_exp_amt.Text = "";
            conn.Close();
        }

        private void addExpensesToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            panel19.Show();
        }

        private void profitLossAccountToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "Select * from Expenses";
            sd = cmd.ExecuteReader();
            cmb_exp.Items.Clear();
            while (sd.Read())
            {
                cmb_exp.Items.Add(sd[0]);
            }
            //            MessageBox.Show("Updated Expenses");
            //lbl_intrest.Text = "";
            panel20.Show();
            conn.Close();
        }

        private void reOpenClosePigmyAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from Customer_Piggy";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            Cmb_name_pig_cl.Items.Clear();
            cmb_trade_Cl.Items.Clear();
            cmb_id_cl.Items.Clear();
            while (sd.Read())
            {
                Cmb_name_pig_cl.Items.Add(sd[1].ToString());
                cmb_id_cl.Items.Add(sd[0].ToString());
                cmb_trade_Cl.Items.Add(sd[4].ToString());
            }
            conn.Close();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            panel17.Show();
        }

        private void enterAreaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            panel13.Show();
        }

        private void enterAgentIdToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();
            panel11.Hide();
            panel12.Hide();
            panel13.Hide();
            panel14.Hide();
            panel15.Hide();
            panel16.Hide();
            groupBox9.Hide();
            groupBox14.Hide();
            panel14.Show();
        }

        private void Date_Started_ValueChanged(object sender, EventArgs e)
        {
            date_end.Value = Date_Started.Value.AddDays(100);
        }

        private void button80_Click(object sender, EventArgs e)
        {

        }

        
        
        
    }
}
