﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'DataSet1.vg' table. You can move, or remove it, as needed.
            this.vgTableAdapter.Fill(this.DataSet1.vg);
            // TODO: This line of code loads data into the 'DataSet1.Svg' table. You can move, or remove it, as needed.
            this.SvgTableAdapter.Fill(this.DataSet1.Svg);
            // TODO: This line of code loads data into the 'chit_fundDataSet3.Group_Amount' table. You can move, or remove it, as needed.
            this.group_AmountTableAdapter1.Fill(this.chit_fundDataSet3.Group_Amount);
            // TODO: This line of code loads data into the 'DataSet2.Group_Amount' table. You can move, or remove it, as needed.
            this.Group_AmountTableAdapter.Fill(this.DataSet2.Group_Amount, txt_name.Text, Convert.ToDateTime(txt_date1.Text), Convert.ToDateTime(txt_Date2.Text));
            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
