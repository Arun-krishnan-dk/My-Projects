﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication6
{
    
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection();
        int Total_rg = 0;
        SqlCommand cmd = new SqlCommand();
        SqlDataReader sd = null;
        int counter=100,count;
        public Form1()
        {
            InitializeComponent();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (txt_userid.Text == "" || txt_emailid.Text == "")
            {
                MessageBox.Show("Please enter email id and user name");
            }
            else
            {
                if (txt_paswd.Text == txt_cpaswd.Text)
                {
                    conn.Open();
                    cmd.CommandText = "Insert into login values('" + txt_userid.Text + "','" + txt_emailid.Text + "','" + txt_paswd.Text + "')";
                    cmd.Connection = conn;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Login Registered");
                    panel7.Hide();
                    conn.Close();
                }
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            panel7.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (txt_emaill.Text == "Admin@gmail.com" && txt_pswdl.Text == "Admin123")
            {
                MessageBox.Show("Authentication Successfull");
                panel6.Hide();
                panel5.Show();
                label15.Text = "Welcome " + txt_emaill.Text;
            }
            conn.Open();
            cmd.CommandText = "Select * from login";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                //MessageBox.Show(sd[1].ToString() + " " + sd[2].ToString().Trim());
                if (txt_emaill.Text == sd[1].ToString().Trim() && txt_pswdl.Text == sd[2].ToString().Trim())
                {
                    MessageBox.Show("Authentication Successfull");
                    panel6.Hide();
                    panel5.Show();
                    label15.Text = "Welcome " + txt_emaill.Text;
                }

                else
                {
                    MessageBox.Show("Invalid Logins");
                }

            }
            conn.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel6.Show();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            pnl_NG.Hide();
            panel5.Hide();
            //panel6.Hide(); 
            panel7.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'chit_fundDataSet12.NG' table. You can move, or remove it, as needed.
            this.nGTableAdapter.Fill(this.chit_fundDataSet12.NG);
            // TODO: This line of code loads data into the 'chit_fundDataSet11.RG' table. You can move, or remove it, as needed.
            this.rGTableAdapter.Fill(this.chit_fundDataSet11.RG);
            // TODO: This line of code loads data into the 'chit_fundDataSet10.tg' table. You can move, or remove it, as needed.
            this.tgTableAdapter.Fill(this.chit_fundDataSet10.tg);
            // TODO: This line of code loads data into the 'chit_fundDataSet9.sg' table. You can move, or remove it, as needed.
            this.sgTableAdapter.Fill(this.chit_fundDataSet9.sg);
            // TODO: This line of code loads data into the 'chit_fundDataSet8.ag' table. You can move, or remove it, as needed.
            this.agTableAdapter.Fill(this.chit_fundDataSet8.ag);
            // TODO: This line of code loads data into the 'chit_fundDataSet7.smg' table. You can move, or remove it, as needed.
            this.smgTableAdapter.Fill(this.chit_fundDataSet7.smg);
            // TODO: This line of code loads data into the 'chit_fundDataSet6.vg' table. You can move, or remove it, as needed.
            this.vgTableAdapter.Fill(this.chit_fundDataSet6.vg);
            // TODO: This line of code loads data into the 'chit_fundDataSet5.skbg' table. You can move, or remove it, as needed.
            this.skbgTableAdapter.Fill(this.chit_fundDataSet5.skbg);
            // TODO: This line of code loads data into the 'chit_fundDataSet4.svg' table. You can move, or remove it, as needed.
            this.svgTableAdapter.Fill(this.chit_fundDataSet4.svg);
            // TODO: This line of code loads data into the 'chit_fundDataSet3.smruthi' table. You can move, or remove it, as needed.
            this.smruthiTableAdapter.Fill(this.chit_fundDataSet3.smruthi);
            // TODO: This line of code loads data into the 'chit_fundDataSet2.sag' table. You can move, or remove it, as needed.
            this.sagTableAdapter.Fill(this.chit_fundDataSet2.sag);
            // TODO: This line of code loads data into the 'chit_fundDataSet1.cg' table. You can move, or remove it, as needed.
            this.cgTableAdapter.Fill(this.chit_fundDataSet1.cg);
            // TODO: This line of code loads data into the 'chit_fundDataSet.pg' table. You can move, or remove it, as needed.
            this.pgTableAdapter.Fill(this.chit_fundDataSet.pg);
            // TODO: This line of code loads data into the 'dataSet1.pg' table. You can move, or remove it, as needed.
           // this.pgTableAdapter.Fill(this.dataSet1.pg);
            conn.ConnectionString = @"Data Source=ABI-PC\SQLEXPRESS;Initial Catalog=Chit_fund;Integrated Security=true";
            panel6.Hide();
            panel5.Show();
            label15.Text = "Welcome " + txt_emaill.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel1.Show();
            panel2.Hide();
            panel3.Hide();
            pnl_NG.Hide();
            panel5.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.CommandText = "Insert into Add_group values('" + txt_add_name.Text + "',0,0,0,0,0,0,0,0,0,0,0,0,0)";
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Groups Created");
            groupBox1.Show();
            conn.Close();
            conn.Open();
            cmd.CommandText = "Insert into Registration values('" + txt_name.Text + "','" + txt_phone.Text + "','" + txt_address.Text + "','" + date.Value.ToString("MM/dd/yyyy") + "')";
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            MessageBox.Show("customer Registered");
            panel1.Hide();
            button7.Enabled = true;
            panel5.Show();
            conn.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            panel5.Show();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            pnl_NG.Hide();
            //panel5.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "update add_group set " + cmb_grp.Text + " = " + txt_no_Chits.Text;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Registry Updated");
            txt_no_Chits.Text = "";
            conn.Close();
            button8.Enabled = true;

        }

        private void button15_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                cmd.CommandText = "Insert into Add_group values('" + txt_add_name.Text + "',0,0,0,0,0,0,0,0,0,0,0,0,0)";
                cmd.Connection = conn;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Groups Created");
                groupBox1.Show();
                conn.Close();
            }
            catch (Exception ex)
            {
                if (ex.Message == "Cannot insert duplicate key row in object 'dbo.Add_group' with unique index 'IX_Add_group'.\r\nThe statement has been terminated.") 
                {
                    MessageBox.Show("Customer Already Exists.Please Enter details to update for same Customer");
                    groupBox1.Show();
                    conn.Close();
                }
            }


        }

        private void button14_Click(object sender, EventArgs e)
        {
            panel5.Show();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            pnl_NG.Hide();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel2.Show();
            panel1.Hide();
            panel5.Hide();
            panel3.Hide();
            pnl_NG.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox5.Text +"'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
                while (sd.Read())
                {

                    groupBox2.Show();

                    //MessageBox.Show(sd[1].ToString() + " " + sd[2].ToString().Trim());
                    lbl_RG.Text = "RG/" + sd[1].ToString().Trim();
                    lbl_TG.Text = "TG/" + sd[2].ToString().Trim();
                    lbl_SG.Text = "SG/" + sd[3].ToString().Trim();
                    lbl_NG.Text = "NG/" + sd[4].ToString().Trim();
                    lbl_AG.Text = "AG/" + sd[5].ToString().Trim();
                    lbl_SMG.Text = "SMG/" + sd[6].ToString().Trim();
                    lbl_Smruthi.Text = "Smruthi/" + sd[7].ToString().Trim();
                    lbl_SAG.Text = "SAG/" + sd[8].ToString().Trim();
                    lbl_CG.Text = "CG/" + sd[9].ToString().Trim();
                    lbl_SVG.Text = "SVG/" + sd[10].ToString().Trim();
                    lbl_PG.Text = "PG/" + sd[11].ToString().Trim();
                    lbl_VG.Text = "VG/" + sd[12].ToString().Trim();
                    lbl_SKBG.Text = "SKBG/" + sd[13].ToString().Trim();
                    if (int.Parse(sd[1].ToString()) > 0)
                        {
                         textBox8.Enabled = true;
                        lbl_RG.Visible = true;
                    }
                    else
                    {
                       lbl_RG.Visible  = false;
                       textBox8.Enabled = false;
                    }
                    if (int.Parse(sd[2].ToString()) > 0)
                    {
                        textBox10.Enabled = true;
                        lbl_TG.Visible = true;
                    }
                    else
                    {
                        textBox10.Enabled = false;
                        lbl_TG.Visible = false;
                    }
                    if (int.Parse(sd[3].ToString()) > 0)
                    {
                        textBox11.Enabled = true;
                        lbl_SG.Visible = true;
                    }
                    else
                    {
                        textBox11.Enabled = false;
                        lbl_SG.Visible = false;
                    }
                    if (int.Parse(sd[4].ToString()) > 0)
                    {
                        textBox12.Enabled = true;
                        lbl_NG.Visible= true;
                    }
                    else
                    {
                        lbl_NG.Visible = false;
                        textBox12.Enabled = false;
                    }
                    if (int.Parse(sd[5].ToString()) > 0)
                    {
                        textBox13.Enabled = true;
                        lbl_AG.Visible  = true;
                    }
                    else
                    {
                    lbl_AG.Visible = false;
                    textBox13.Enabled = false;
                    }
                    if (int.Parse(sd[6].ToString()) > 0)
                    {
                        textBox14.Enabled = true;
                        lbl_SMG.Visible = true;
                    }
                    else
                    {
                    lbl_SMG.Visible = false;
                    textBox14.Enabled = false;
                    }
                    if (int.Parse(sd[7].ToString()) > 0)
                    {
                        textBox15.Enabled = true;
                        lbl_Smruthi.Visible = true;
                    }
                    else
                    {
                        textBox15.Enabled = false;
                    lbl_Smruthi.Visible = false ;
                    }
                    if (int.Parse(sd[8].ToString()) > 0)
                    {
                        textBox16.Enabled = true;
                        lbl_SAG.Visible = true;
                    }
                    else
                    {
                        textBox16.Enabled = false;
                    lbl_SAG.Visible=false ;
                    }
                    if (int.Parse(sd[9].ToString()) > 0)
                    {
                        textBox17.Enabled = true;
                        lbl_CG.Visible = true ; 
                    }
                    else
                    {
                        textBox17.Enabled = false;
                        lbl_CG.Visible =false ; 
                    }
                    if (int.Parse(sd[10].ToString()) > 0)
                    {
                        textBox18.Enabled = true;
                        lbl_SVG.Visible = true ;
                    }
                    else
                    {
                        textBox18.Enabled  = false;
                        lbl_SVG.Visible = false ;
                    }
                    if (int.Parse(sd[11].ToString()) > 0)
                    {
                        textBox19.Enabled = true;
                        lbl_PG.Visible = true ;
                    }
                    else
                    {
                        lbl_PG.Visible = false;
                        textBox19.Enabled  = false;
                    }
                    if (int.Parse(sd[12].ToString()) > 0)
                    {
                        textBox20.Enabled = true;
                        lbl_VG.Visible = true;
                    }
                    else
                    {
                        textBox20.Enabled = false;
                        lbl_VG.Visible = false;
                    }
                    if (int.Parse(sd[13].ToString()) > 0)
                    {
                        textBox9.Enabled = true;
                        lbl_SKBG.Visible = true;
                    }
                    else
                    {
                        textBox9.Enabled = false;
                        lbl_SKBG.Visible = false;
                    }
                }
                lbl_Name.Text = textBox5.Text ;
                MessageBox.Show("Information for " + lbl_Name.Text + ".Please Enter the amount");
                


            }
            else
            {

                MessageBox.Show("No Records found");
            }
           conn.Close();

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn.Open();
            int total = 0;
            if (textBox7.Text == "") textBox7.Text = "0";
            if (textBox8.Text == "") textBox8.Text = "0";
            if (textBox9.Text == "") textBox9.Text = "0";
            if (textBox10.Text == "") textBox10.Text = "0";
            if (textBox20.Text == "") textBox20.Text = "0";
            if (textBox12.Text == "") textBox12.Text = "0";
            if (textBox13.Text == "") textBox13.Text = "0";
            if (textBox14.Text == "") textBox14.Text = "0";
            if (textBox15.Text == "") textBox15.Text = "0";
            if (textBox16.Text == "") textBox16.Text = "0";
            if (textBox17.Text == "") textBox17.Text = "0";
            if (textBox18.Text == "") textBox18.Text = "0";
            if (textBox19.Text == "") textBox19.Text = "0";
            total = int.Parse(textBox7.Text) + int.Parse(textBox17.Text) + int.Parse(textBox16.Text) + int.Parse(textBox20.Text) + int.Parse(textBox19.Text) + int.Parse(textBox18.Text) + int.Parse(textBox14.Text) + int.Parse(textBox10.Text) + int.Parse(textBox9.Text) + int.Parse(textBox8.Text) + int.Parse(textBox13.Text) + int.Parse(textBox12.Text);//+ int.Parse(textBox7.Text) ;
            cmd.Connection = conn;
            cmd.CommandText = "Insert into Group_Amount values('" + lbl_Name.Text + "','" + textBox8.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','" + textBox12.Text + "','" + textBox13.Text + "','" + textBox14.Text + "','" + textBox15.Text + "','" + textBox16.Text + "','" + textBox17.Text + "','" + textBox18.Text + "','" + textBox19.Text + "','" + textBox20.Text + "','" + textBox9.Text + "'," + total + ",'" + date.Value.ToString("MM/dd/yyyy") + "')";
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Amount Created");
            textBox7.Text = total.ToString();
            groupBox1.Show();
            conn.Close();
            
        }

        private void button16_Click(object sender, EventArgs e)
        {
            panel5.Show();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            pnl_NG.Hide();

       
        }

        private void button6_Click(object sender, EventArgs e)
        {
            conn.Open();
           int balance=int.Parse(textBox34.Text) - int.Parse(textBox30.Text);
           int total = int.Parse(textBox30.Text) + balance;
           textBox32.Text = balance.ToString();
           textBox31.Text = total.ToString();
            cmd.Connection = conn;
            cmd.CommandText = "Insert into divident values('" + textBox28.Text + "','" + dateTimePicker3.Value.ToString("MM/dd/yyyy") + "','" + textBox33.Text + "','" +textBox34.Text  + "','" + textBox30.Text + "','" + textBox32.Text + "','" + textBox31.Text + "')";
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Amount Stored");
            groupBox1.Show();
            conn.Close();
            
        }

        private void button17_Click(object sender, EventArgs e)
        {
            panel5.Show();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            pnl_NG.Hide();

        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel3.Show();
            panel1.Hide();
            panel2.Hide();
            panel5.Hide();
            pnl_NG.Hide();

        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel5.Hide();
            groupBox17.Show();
           }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {
           
            panel8.Show(); 
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void button16_Click_1(object sender, EventArgs e)
        {
            pnl_NG.Hide();
//            panel4.Show();
            
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            float first;
            // float second;
            float output;
            first = 100000 - (Convert.ToInt32(textBox34.Text)) - Convert.ToInt32(textBox30.Text);
            output = first;
            textBox32.Text = (output.ToString());
            textBox31.Text = (output.ToString());
            counter = counter - 1;
            conn.Open();
            int couter_bidder = 0;
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox28.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[4].ToString());
                }
            }
            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            if (counter < 0|| count <= couter_bidder)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker3.Text);
                

                Name = textBox28.Text;

                Instal_No = int.Parse(textBox33.Text);
                Bid_Amount = int.Parse(textBox34.Text);
                Commssion = int.Parse(textBox30.Text);
                Balance = int.Parse(textBox32.Text);
                Total_rg = Total_rg + int.Parse(textBox31.Text);

                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into NG (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);

                SqlDataReader objr = con1.ExecuteReader();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "NG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
            }
           
            
            
          
        }

        private void button57_Click(object sender, EventArgs e)
        {
            pnl_RG.Show();
        }

        private void button58_Click(object sender, EventArgs e)
        {
            pnl_TG.Show();
        }

        private void button59_Click(object sender, EventArgs e)
        {
            pnl_SG.Show();
        }

        private void button60_Click(object sender, EventArgs e)
        {
            pnl_NG.Show();
        }

        private void button65_Click(object sender, EventArgs e)
        {
            pnl_AG.Show();
        }

        private void button66_Click(object sender, EventArgs e)
        {
            pnl_SMG.Show();
        }

        private void button69_Click(object sender, EventArgs e)
        {
            pnl_SMRUTHI.Show();
        }

        private void button67_Click(object sender, EventArgs e)
        {
            pnl_SAG.Show();
        }

        private void button68_Click(object sender, EventArgs e)
        {
            pnl_CG.Show();
        }

        private void button61_Click(object sender, EventArgs e)
        {
            pnl_SVG.Show();
        }

        private void button62_Click(object sender, EventArgs e)
        {
            pnl_PG.Show();
        }

        private void button63_Click(object sender, EventArgs e)
        {
            pnl_VG.Show();
        }

        private void button64_Click(object sender, EventArgs e)
        {
            pnl_SKBG.Show();
        }

        private void button22_Click(object sender, EventArgs e)
        {

        }

        private void button24_Click(object sender, EventArgs e)
        {

        }

        private void button34_Click(object sender, EventArgs e)
        {
            float first;
           // float second;
            float output;
            first = 100000-(Convert.ToInt32(textBox6.Text))-Convert.ToInt32(textBox4.Text);
            output = first ;
            textBox3.Text = (output.ToString());
            textBox2.Text = (output.ToString());
            counter = counter - 1;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox1.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[1].ToString());
                }

            }
            conn.Close();
            conn.Open();
            int couter_bidder = 0; 
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox1.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            if (counter < 0 || couter_bidder >= count)
            {
            }
            else
            {

                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker1.Text);
                

                Name = textBox1.Text;

                Instal_No = int.Parse(textBox21.Text);
                Bid_Amount = int.Parse(textBox6.Text);
                Commssion = int.Parse(textBox4.Text);
                Balance = int.Parse(textBox3.Text);
                Total_rg = Total_rg + int.Parse(textBox2.Text);

                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into RG (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);

                SqlDataReader objr = con1.ExecuteReader();

                count = count - 1;
                con1.CommandText = "update Add_group set RG = @p1 where Name = @n1";
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "RG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
            

            }
            conn.Close();
           
            }

        private void button56_Click(object sender, EventArgs e)
        {
            float first;
            // float second;
            float output;
            int couter_bidder=0;
            first = (Convert.ToInt32(textBox92.Text)) - Convert.ToInt32(textBox91.Text);
            output = first;
            textBox90.Text = (output.ToString());
            textBox89.Text = (output.ToString());
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if( sd.HasRows == true)
            {
              while(sd.Read())
              {
                  count = int.Parse(sd[13].ToString());
              }
            }
            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            if (counter < 0 || couter_bidder >= count)
            {
                MessageBox.Show("Cannot bid");
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = dateTimePicker16.Value;
                Name = textBox88.Text;
                Instal_No = int.Parse(textBox93.Text);
                Bid_Amount = int.Parse(textBox92.Text);
                Commssion = int.Parse(textBox91.Text);
                Balance = int.Parse(textBox90.Text);
                Total_rg = Total_rg + int.Parse(textBox89.Text);
                //count = count - 1;
                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into skbg(Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);
                con1.ExecuteNonQuery();
                //con1.CommandText = "update Add_group set SKBG = @p1 where Name = @n1";
                con.Close();
                con.Open();
                couter_bidder++; 
                int total_left = count - couter_bidder;
                con1.CommandText= "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "SKBG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
                                
            }
            conn.Close();
        }

        private void button54_Click(object sender, EventArgs e)
        {
            float first = 0;
            // float second;
            float output;
            if (checkBox1.Checked == true)
            first = 100000 - ((Convert.ToInt32(textBox86.Text)) - Convert.ToInt32(textBox85.Text));
            output = first;
            int couter_bidder = 0;
            textBox84.Text = (output.ToString());
            textBox83.Text = (output.ToString());
            counter = counter - 1;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox82.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[12].ToString());
                }
            }
            conn.Close();
            if (counter < 0 || couter_bidder >= count)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker15.Text);
                Name = textBox82.Text;
                Instal_No = int.Parse(textBox87.Text);
                Bid_Amount = int.Parse(textBox86.Text);
                Commssion = int.Parse(textBox85.Text);
                Balance = int.Parse(textBox84.Text);
                Total_rg = Total_rg + int.Parse(textBox83.Text);
                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into vg(Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);
                SqlDataReader objr = con1.ExecuteReader();
                con.Close();
                con.Open();
                count = count - 1;
                con1.CommandText = "update Add_group set VG = @p1 where Name = @n1";
                con1.Parameters.AddWithValue("@n1", Name);
                con1.Parameters.AddWithValue("@p1", count);
                con1.ExecuteNonQuery();
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "VG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
                }
            conn.Close();
        }

        private void button40_Click(object sender, EventArgs e)
        {
            int totaL =0;
            int first=0;
            int second;
            int output;
            int couter_bidder = 0;
            output = first;
           // first = 100000 - (Convert.ToInt32(textBox74.Text)) - Convert.ToInt32(textBox73.Text);
        
            counter = counter - 1;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox40.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader(); 
            if (sd.HasRows == true)
            {
               while (sd.Read())
                {
                   count = int.Parse(sd[11].ToString());
               }
           }
           conn.Close();
           conn.Open();
           counter = counter - 1;
           cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
           cmd.Connection = conn;
           sd = cmd.ExecuteReader();
           if (sd.HasRows == true)
           {
               while (sd.Read())
               {
                   couter_bidder = int.Parse(sd[3].ToString());
               }
           }
           conn.Close();
           conn.Open();
           counter = counter - 1;
           cmd.CommandText = "Select * from pg";
           cmd.Connection = conn;
           sd = cmd.ExecuteReader();
           if (sd.HasRows == true)
           {
               while (sd.Read())
               {
                   totaL = totaL + int.Parse(sd[5].ToString());
               }
           }
           MessageBox.Show(totaL.ToString());
           if (checkBox1.Checked == false)
           {
           first =Convert.ToInt32(textBox44.Text) - Convert.ToInt32(textBox42.Text) ;
           }
           else
           {
           first = totaL - (100000 - (Convert.ToInt32(textBox44.Text)) + Convert.ToInt32(textBox42.Text));
           }
           conn.Close();
           textBox43.Text = first.ToString();
           textBox41.Text = totaL.ToString();
           if (counter < 0 || couter_bidder >= count)
           {
               string Name;
               int Instal_No, Bid_Amount, Commssion, Balance;
               DateTime Date_of_bid = DateTime.Parse(dateTimePicker8.Text);
               Name = textBox40.Text;
               Instal_No = int.Parse(textBox45.Text);
               Bid_Amount = int.Parse(textBox44.Text);
               Commssion = int.Parse(textBox42.Text);
               Balance = int.Parse(textBox43.Text);
               Total_rg = totaL;
               SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_fund;Integrated Security=True");
               con.Open();
               SqlCommand con1 = new SqlCommand("Insert into pg (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
               con1.Parameters.AddWithValue("@v1", Name);
               con1.Parameters.AddWithValue("@v2", Date_of_bid);
               con1.Parameters.AddWithValue("@v3", Instal_No);
               con1.Parameters.AddWithValue("@v4", Bid_Amount);
               con1.Parameters.AddWithValue("@v5", Commssion);
               con1.Parameters.AddWithValue("@v6", Balance);
               con1.Parameters.AddWithValue("@v7", Total_rg);
               count = count - 1;
               SqlDataReader objr = con1.ExecuteReader();
               con.Close();
               con.Open();
               couter_bidder++;
               int total_left = count - couter_bidder;
               con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
               con1.Parameters.AddWithValue("@v11", Name);
               con1.Parameters.AddWithValue("@v12", "PG");
               con1.Parameters.AddWithValue("@v13", count);
               con1.Parameters.AddWithValue("@v14", couter_bidder);
               con1.Parameters.AddWithValue("@v15", total_left);
               con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
               con1.Parameters.AddWithValue("@v17", Bid_Amount);
               con1.Parameters.AddWithValue("@v18", Instal_No);
               con1.ExecuteNonQuery();
               con.Close();
               MessageBox.Show("Done");
             }
            conn.Close();
        }

        private void button52_Click(object sender, EventArgs e)
        {
            float first;
            // float second;
            float output;
            first = 100000 - (Convert.ToInt32(textBox80.Text)) - Convert.ToInt32(textBox79.Text);
            output = first;
            textBox78.Text = (output.ToString());
            textBox77.Text = (output.ToString());
            counter = counter - 1;
            int couter_bidder = 0;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox76.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[10].ToString());
                }
            }
            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            if (counter < 0|| count <= couter_bidder)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker14.Text);
                Name = textBox76.Text;
                Instal_No = int.Parse(textBox81.Text);
                Bid_Amount = int.Parse(textBox80.Text);
                Commssion = int.Parse(textBox79.Text);
                Balance = int.Parse(textBox78.Text);
                Total_rg = Total_rg + int.Parse(textBox77.Text);
                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into svg (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);
                SqlDataReader objr = con1.ExecuteReader();
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "SVG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");

            }
            conn.Close();
        }

        private void button50_Click(object sender, EventArgs e)
        {
            float first;
            // float second;
            float output;
            first = 100000 - (Convert.ToInt32(textBox74.Text)) - Convert.ToInt32(textBox73.Text);
            output = first;
            int couter_bidder = 0;
            textBox72.Text = (output.ToString());
            textBox71.Text = (output.ToString());
            counter = counter - 1;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox70.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[9].ToString());
                }
            }
            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            if (counter < 0|| count <= couter_bidder)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker13.Text);
                Name = textBox70.Text;
                Instal_No = int.Parse(textBox75.Text);
                Bid_Amount = int.Parse(textBox74.Text);
                Commssion = int.Parse(textBox73.Text);
                Balance = int.Parse(textBox72.Text);
                Total_rg = Total_rg + int.Parse(textBox71.Text);

                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into cg (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);

                SqlDataReader objr = con1.ExecuteReader();
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "CG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
            }
            conn.Close();
        }

        private void button48_Click(object sender, EventArgs e)
        {
            float first;
            // float second;
            float output;
            first = 100000 - (Convert.ToInt32(textBox68.Text)) - Convert.ToInt32(textBox67.Text);
            int couter_bidder = 0;
            output = first;
            textBox66.Text = (output.ToString());
            textBox65.Text = (output.ToString());
            counter = counter - 1;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox64.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[8].ToString());
                }
            }
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            if (counter < 0|| count <= couter_bidder)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker12.Text);

            
                Name = textBox64.Text;

                Instal_No = int.Parse(textBox69.Text);
                Bid_Amount = int.Parse(textBox68.Text);
                Commssion = int.Parse(textBox67.Text);
                Balance = int.Parse(textBox66.Text);
                Total_rg = Total_rg + int.Parse(textBox65.Text);

                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into sag (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);

                SqlDataReader objr = con1.ExecuteReader();
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "SAG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
            }
            conn.Close();
        }

        private void button46_Click(object sender, EventArgs e)
        {
            int totaL=0;
            float first;
            // float second;
            float output;
            first = 100000 - (Convert.ToInt32(textBox62.Text)) - Convert.ToInt32(textBox63.Text);
            output = first;
            int couter_bidder = 0;
            textBox60.Text = (output.ToString());
            textBox59.Text = (output.ToString());
            counter = counter - 1;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox58.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[7].ToString());
                }
            }
            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from smruthi";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    totaL=totaL+ int.Parse(sd[5].ToString());
                }
            }

            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from smruthi";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    totaL = totaL + int.Parse(sd[5].ToString());
                }
            }

            conn.Close();
            textBox59.Text = totaL.ToString();
            if (counter < 0|| count <= couter_bidder)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker11.Text);

            
                Name = textBox58.Text;

                Instal_No = int.Parse(textBox63.Text);
                Bid_Amount = int.Parse(textBox62.Text);
                Commssion = int.Parse(textBox61.Text);
                Balance = int.Parse(textBox60.Text);
                
                Total_rg = int.Parse(textBox59.Text);
                
                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into smruthi (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);

                SqlDataReader objr = con1.ExecuteReader();
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "SMRUTHI");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
            }
            conn.Close();
        }

        private void button44_Click(object sender, EventArgs e)
        {
            float first;
            // float second;
            float output;
            first = 100000 - (Convert.ToInt32(textBox56.Text)) - Convert.ToInt32(textBox55.Text);
            output = first;
            conn.Open();
            int couter_bidder = 0;
            textBox54.Text = (output.ToString());
            textBox53.Text = (output.ToString());
            counter = counter - 1;
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox52.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                     couter_bidder = int.Parse(sd[6].ToString());
                }
            }
            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            if (counter < 0 || couter_bidder >= count)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker10.Text);
                


                Name = textBox52.Text;

                Instal_No = int.Parse(textBox57.Text);
                Bid_Amount = int.Parse(textBox56.Text);
                Commssion = int.Parse(textBox55.Text);
                Balance = int.Parse(textBox54.Text);
                Total_rg = Total_rg + int.Parse(textBox53.Text);

                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into smg (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);
                SqlDataReader objr = con1.ExecuteReader();
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "SMG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
            }
            conn.Close();

        }

        private void button42_Click(object sender, EventArgs e)
        {
            float first;
            // float second;
            float output;
            first = 100000 - (Convert.ToInt32(textBox50.Text)) - Convert.ToInt32(textBox49.Text);
            output = first;
            textBox48.Text = (output.ToString());
            textBox47.Text = (output.ToString());
            int couter_bidder = 0;
            counter = counter - 1;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox46.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[5].ToString());
                }
            }
            conn.Close();
            cmd.CommandText = "Select * from Bid where Name = '" + textBox52.Text + "'";
            conn.Open();
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[6].ToString());
                }
            }
            conn.Close();
            if (counter < 0 || count <= couter_bidder)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker9.Text);
                
                Name = textBox46.Text;

                Instal_No = int.Parse(textBox51.Text);
                Bid_Amount = int.Parse(textBox50.Text);
                Commssion = int.Parse(textBox49.Text);
                Balance = int.Parse(textBox48.Text);
                Total_rg = Total_rg + int.Parse(textBox47.Text);

                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into ag (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);
                SqlDataReader objr = con1.ExecuteReader();
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "AG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
            }
            conn.Close();
        }

        private void button38_Click(object sender, EventArgs e)
        {
            float first;
            // float second;
            float output;
            first = 100000 - (Convert.ToInt32(textBox38.Text)) - Convert.ToInt32(textBox37.Text);
            output = first;
            textBox36.Text = (output.ToString());
            textBox35.Text = (output.ToString());
            counter = counter - 1;
            int couter_bidder = 0;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox29.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            if (counter < 0 || count <= couter_bidder)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker7.Text);

               
                Name = textBox29.Text;

                Instal_No = int.Parse(textBox39.Text);
                Bid_Amount = int.Parse(textBox38.Text);
                Commssion = int.Parse(textBox37.Text);
                Balance = int.Parse(textBox36.Text);
                Total_rg = Total_rg + int.Parse(textBox35.Text);

                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into sg (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);

                SqlDataReader objr = con1.ExecuteReader();
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "SG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
            
                

            }
            conn.Close();
        }

        private void button36_Click(object sender, EventArgs e)
        {
            float first;
            // float second;
            float output;
            first = 100000 - (Convert.ToInt32(textBox26.Text)) - Convert.ToInt32(textBox25.Text);
            output = first;
            textBox24.Text = (output.ToString());
            textBox23.Text = (output.ToString());
            counter = counter - 1;
            conn.Open();
            cmd.CommandText = "Select * from Add_group where Name = '" + textBox22.Text + "'";
            cmd.Connection = conn;
            int couter_bidder = 0;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    count = int.Parse(sd[2].ToString());
                }
            }
            conn.Close();
            conn.Open();
            counter = counter - 1;
            cmd.CommandText = "Select * from Bid where Name = '" + textBox88.Text + "'";
            cmd.Connection = conn;
            sd = cmd.ExecuteReader();
            if (sd.HasRows == true)
            {
                while (sd.Read())
                {
                    couter_bidder = int.Parse(sd[3].ToString());
                }
            }
            conn.Close();
            if (counter < 0|| couter_bidder>= count)
            {
            }
            else
            {
                string Name;
                int Instal_No, Bid_Amount, Commssion, Balance;
                DateTime Date_of_bid = DateTime.Parse(dateTimePicker4.Text);

            
                Name = textBox22.Text;

                Instal_No = int.Parse(textBox27.Text);
                Bid_Amount = int.Parse(textBox26.Text);
                Commssion = int.Parse(textBox25.Text);
                Balance = int.Parse(textBox24.Text);
                Total_rg = Total_rg + int.Parse(textBox23.Text);

                SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
                con.Open();
                SqlCommand con1 = new SqlCommand("Insert into tg (Name,Date_of_bid,Instal_No,Bid_Amount,Commssion,Balance,Total)values(@v1,@v2,@v3,@v4,@v5,@v6,@v7)", con);
                con1.Parameters.AddWithValue("@v1", Name);
                con1.Parameters.AddWithValue("@v2", Date_of_bid);
                con1.Parameters.AddWithValue("@v3", Instal_No);
                con1.Parameters.AddWithValue("@v4", Bid_Amount);
                con1.Parameters.AddWithValue("@v5", Commssion);
                con1.Parameters.AddWithValue("@v6", Balance);
                con1.Parameters.AddWithValue("@v7", Total_rg);
                SqlDataReader objr = con1.ExecuteReader();
                con.Close();
                con.Open();
                couter_bidder++;
                int total_left = count - couter_bidder;
                con1.CommandText = "Insert into Bid(Name,Chit,Available,Bidded,Total,Date,Amount,Installment_no)values(@v11,@v12,@v13,@v14,@v15,@v16,@v17,@v18)";
                con1.Parameters.AddWithValue("@v11", Name);
                con1.Parameters.AddWithValue("@v12", "TG");
                con1.Parameters.AddWithValue("@v13", count);
                con1.Parameters.AddWithValue("@v14", couter_bidder);
                con1.Parameters.AddWithValue("@v15", total_left);
                con1.Parameters.AddWithValue("@v16", Date_of_bid.ToString("MM/dd/yyyy"));
                con1.Parameters.AddWithValue("@v17", Bid_Amount);
                con1.Parameters.AddWithValue("@v18", Instal_No);
                con1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Done");
            }
            conn.Close();
        }

        private void button55_Click(object sender, EventArgs e)
        {
            pnl_SKBG.Hide();
        }

        private void button53_Click(object sender, EventArgs e)
        {
            pnl_VG.Hide();
        }

        private void button43_Click(object sender, EventArgs e)
        {
            pnl_SMG.Hide();
        }

        private void button41_Click(object sender, EventArgs e)
        {
            pnl_AG.Hide();
        }

        private void button37_Click(object sender, EventArgs e)
        {
            pnl_SG.Hide();
        }

        private void button35_Click(object sender, EventArgs e)
        {
            pnl_TG.Hide();
        }

        private void button31_Click(object sender, EventArgs e)
        {
            pnl_RG.Hide();
        }

        private void button39_Click(object sender, EventArgs e)
        {
            pnl_PG.Hide();
        }

        private void button49_Click(object sender, EventArgs e)
        {
            pnl_CG.Hide();
        }

        private void button47_Click(object sender, EventArgs e)
        {
            pnl_SAG.Hide();
        }

        private void button45_Click(object sender, EventArgs e)
        {
            pnl_SMRUTHI.Hide();
        }

        private void button51_Click(object sender, EventArgs e)
        {
            pnl_SVG.Hide();
        }

        private void button70_Click(object sender, EventArgs e)
        {
            panel6.Show();

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            groupBox4.Show();
            groupBox18.Hide();   
        }

        private void button19_Click(object sender, EventArgs e)
        {

            if (sts == 0)
            {
                Form3 arun = new Form3();
                arun.txt_name.Text = txt_name_rep.Text;
                arun.txt_date1.Text = date_From.Value.ToString("MM/dd/yyyy");
                arun.txt_Date2.Text = date_To.Value.ToString("MM/dd/yyyy");
                arun.Show();
            }
            else
            {
                Form4 arun1 = new Form4();
                arun1.txt_d1.Text = date_From.Value.ToString("MM/dd/yyyy");
                arun1.txt_d2.Text  = date_To.Value.ToString("MM/dd/yyyy");
                arun1.txt_name.Text = txt_name_rep.Text;
                arun1.Show();
                arun1.reportViewer14.Show();
            }



        }

        private void button23_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer1.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button21_Click(object sender, EventArgs e)
        {

            Form4 rep = new Form4();
            rep.reportViewer2.Show();
            rep.reportViewer1.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button22_Click_1(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer1.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
        }

        private void button22_Click_2(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer3.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button24_Click_1(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer4.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer5.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer6.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button32_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer7.Hide();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.reportViewer14.Show();
            rep.Show();
        }

        private void button28_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer8.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button30_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer9.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button29_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer10.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer11.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button27_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer12.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer6.Hide();
            rep.reportViewer13.Hide();
            rep.Show();
        }

        private void button33_Click(object sender, EventArgs e)
        {
            Form4 rep = new Form4();
            rep.reportViewer13.Show();
            rep.reportViewer2.Hide();
            rep.reportViewer3.Hide();
            rep.reportViewer4.Hide();
            rep.reportViewer5.Hide();
            rep.reportViewer1.Hide();
            rep.reportViewer7.Hide();
            rep.reportViewer8.Hide();
            rep.reportViewer9.Hide();
            rep.reportViewer10.Hide();
            rep.reportViewer11.Hide();
            rep.reportViewer12.Hide();
            rep.reportViewer6.Hide();
            rep.Show();
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
            groupBox4.Show();
            groupBox18.Hide();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            groupBox18.Show();
            groupBox4.Hide();
        
        }

        private void button71_Click(object sender, EventArgs e)
        {
            panel5.Show();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel8.Hide();
            pnl_NG.Hide();

        }

        private void button72_Click(object sender, EventArgs e)
        {
            panel5.Show();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
            panel8.Hide();
            groupBox17.Hide();
            pnl_NG.Hide();
        }

        private void cmb_grp_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void load_details_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from pg;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }



        }

        private void button84_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from cg;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button73_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from sag;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button74_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from smruthi;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button75_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from svg;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button76_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from skbg;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button77_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from vg;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button78_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from smg;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button79_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from ag;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button80_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from sg;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button81_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from tg;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button82_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from RG;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void button83_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("select * from NG;", con);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = con1;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);

                BindingSource bsource = new BindingSource();
                bsource.DataSource = dbdataset;
                dataGridView1.DataSource = bsource;
                sda.Update(dbdataset);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);




            }
        }

        private void groupBox17_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox15_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            sts = 0;
        }
        int sts = 1;
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            sts = 1;
        }

        private void button85_Click(object sender, EventArgs e)
        {

            string Group_Name;
            int Chit_Amount, Total_Instlament, Type_of_Chit, Installments_Amount;

            Group_Name = txt_Group_Name.Text;

            Chit_Amount = int.Parse(txt_chit_Amount.Text);
            Total_Instlament = int.Parse(txt_total_installment.Text);
            Type_of_Chit = int.Parse(txt_type_chit.Text);
            Installments_Amount = int.Parse(txt_installment_amount.Text);

            SqlConnection con = new SqlConnection(@"server=ABI-PC\SQLEXPRESS;Database=Chit_Fund;Integrated Security=True");
            con.Open();
            SqlCommand con1 = new SqlCommand("Insert into Chit_Group(Group_Name,Chit_Amount,Total_Instlament,Type_of_Chit,Installments_Amount)values(@v1,@v2,@v3,@v4,@v5)", con);
            con1.Parameters.AddWithValue("@v1", Group_Name);
            con1.Parameters.AddWithValue("@v2", Chit_Amount);
            con1.Parameters.AddWithValue("@v3", Total_Instlament);
            con1.Parameters.AddWithValue("@v4", Type_of_Chit);
            con1.Parameters.AddWithValue("@v5", Installments_Amount);
       

            SqlDataReader objr = con1.ExecuteReader();
            MessageBox.Show("Saved and updated");
            con.Close();
        }

        

        

        


        

       

      
       
       
        

       
       
       

      

        

       
   
      
      

     

      

        
    }
}
