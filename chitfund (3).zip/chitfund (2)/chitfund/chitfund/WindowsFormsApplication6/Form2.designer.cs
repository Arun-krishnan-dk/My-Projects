﻿namespace WindowsFormsApplication6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource3 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource4 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource5 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource6 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource7 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource8 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource9 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource10 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource11 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource12 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource13 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource14 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource15 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource16 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Group_AmountBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DataSet1 = new WindowsFormsApplication6.DataSet1();
            this.agBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.cgBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ngBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.agBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sAgBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.sgBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.skbgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smruthiBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.smruthiBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.svgBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.chit_fundDataSet = new WindowsFormsApplication6.Chit_fundDataSet();
            this.vgBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.vgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smgBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.svgBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer2 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer3 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer4 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer5 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer6 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer7 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer8 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer9 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer10 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer11 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer12 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer13 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer14 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.svgTableAdapter = new WindowsFormsApplication6.Chit_fundDataSetTableAdapters.SvgTableAdapter();
            this.smgTableAdapter = new WindowsFormsApplication6.Chit_fundDataSetTableAdapters.SmgTableAdapter();
            this.smgBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.chitfundDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smgBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer15 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.skbgBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.svgBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smruthiTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.SmruthiTableAdapter();
            this.skbgTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.SkbgTableAdapter();
            this.sgTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.SgTableAdapter();
            this.sAgBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sAgTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.SAgTableAdapter();
            this.sAgBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.agTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.AgTableAdapter();
            this.ngBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ngTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.NgTableAdapter();
            this.cgTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.CgTableAdapter();
            this.rgBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.rgTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.RgTableAdapter();
            this.svgBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.svgTableAdapter1 = new WindowsFormsApplication6.DataSet1TableAdapters.SvgTableAdapter();
            this.vgTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.vgTableAdapter();
            this.vgBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tgBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tgTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.tgTableAdapter();
            this.dataSet1BindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.smgBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.smgTableAdapter1 = new WindowsFormsApplication6.DataSet1TableAdapters.SmgTableAdapter();
            this.groupAmountBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.agBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sagBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.svgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smruthiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupAmountBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.addgroupBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.add_groupTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.Add_groupTableAdapter();
            this.dataSet2 = new WindowsFormsApplication6.DataSet2();
            this.groupAmountBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.group_AmountTableAdapter = new WindowsFormsApplication6.DataSet2TableAdapters.Group_AmountTableAdapter();
            this.groupAmountBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.groupAmountBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer16 = new Microsoft.Reporting.WinForms.ReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.Group_AmountBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cgBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAgBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sgBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skbgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smruthiBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smruthiBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chitfundDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skbgBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAgBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAgBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rGBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nGBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sagBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smruthiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addgroupBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource4)).BeginInit();
            this.SuspendLayout();
            // 
            // Group_AmountBindingSource
            // 
            this.Group_AmountBindingSource.DataMember = "Group_Amount";
            this.Group_AmountBindingSource.DataSource = this.DataSet1;
            // 
            // DataSet1
            // 
            this.DataSet1.DataSetName = "DataSet1";
            this.DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // agBindingSource2
            // 
            this.agBindingSource2.DataMember = "Ag";
            this.agBindingSource2.DataSource = this.DataSet1;
            // 
            // cgBindingSource1
            // 
            this.cgBindingSource1.DataMember = "Cg";
            this.cgBindingSource1.DataSource = this.DataSet1;
            // 
            // ngBindingSource2
            // 
            this.ngBindingSource2.DataMember = "Ng";
            this.ngBindingSource2.DataSource = this.DataSet1;
            // 
            // agBindingSource1
            // 
            this.agBindingSource1.DataMember = "Ag";
            this.agBindingSource1.DataSource = this.DataSet1;
            // 
            // sAgBindingSource3
            // 
            this.sAgBindingSource3.DataMember = "SAg";
            this.sAgBindingSource3.DataSource = this.DataSet1;
            // 
            // sgBindingSource1
            // 
            this.sgBindingSource1.DataMember = "Sg";
            this.sgBindingSource1.DataSource = this.DataSet1;
            // 
            // skbgBindingSource
            // 
            this.skbgBindingSource.DataMember = "skbg";
            // 
            // smgBindingSource
            // 
            this.smgBindingSource.DataMember = "smg";
            // 
            // smruthiBindingSource1
            // 
            this.smruthiBindingSource1.DataMember = "Smruthi";
            this.smruthiBindingSource1.DataSource = this.dataSet1BindingSource1;
            // 
            // dataSet1BindingSource1
            // 
            this.dataSet1BindingSource1.DataSource = this.DataSet1;
            this.dataSet1BindingSource1.Position = 0;
            // 
            // smruthiBindingSource2
            // 
            this.smruthiBindingSource2.DataMember = "Smruthi";
            this.smruthiBindingSource2.DataSource = this.DataSet1;
            // 
            // svgBindingSource4
            // 
            this.svgBindingSource4.DataMember = "Svg";
            this.svgBindingSource4.DataSource = this.chit_fundDataSet;
            // 
            // chit_fundDataSet
            // 
            this.chit_fundDataSet.DataSetName = "Chit_fundDataSet";
            this.chit_fundDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vgBindingSource1
            // 
            this.vgBindingSource1.DataMember = "vg";
            this.vgBindingSource1.DataSource = this.DataSet1;
            // 
            // vgBindingSource
            // 
            this.vgBindingSource.DataMember = "vg";
            // 
            // smgBindingSource1
            // 
            this.smgBindingSource1.DataMember = "Smg";
            this.smgBindingSource1.DataSource = this.chit_fundDataSet;
            // 
            // svgBindingSource1
            // 
            this.svgBindingSource1.DataMember = "Svg";
            this.svgBindingSource1.DataSource = this.chit_fundDataSet;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.Group_AmountBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(753, 470);
            this.reportViewer1.TabIndex = 0;
            // 
            // reportViewer2
            // 
            reportDataSource2.Name = "DataSet1";
            reportDataSource2.Value = this.agBindingSource2;
            this.reportViewer2.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer2.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report2.rdlc";
            this.reportViewer2.Location = new System.Drawing.Point(0, 0);
            this.reportViewer2.Name = "reportViewer2";
            this.reportViewer2.Size = new System.Drawing.Size(753, 471);
            this.reportViewer2.TabIndex = 1;
            // 
            // reportViewer3
            // 
            reportDataSource3.Name = "DataSet1";
            reportDataSource3.Value = this.cgBindingSource1;
            this.reportViewer3.LocalReport.DataSources.Add(reportDataSource3);
            this.reportViewer3.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report3.rdlc";
            this.reportViewer3.Location = new System.Drawing.Point(8, 0);
            this.reportViewer3.Name = "reportViewer3";
            this.reportViewer3.Size = new System.Drawing.Size(712, 470);
            this.reportViewer3.TabIndex = 2;
            // 
            // reportViewer4
            // 
            reportDataSource4.Name = "DataSet1";
            reportDataSource4.Value = this.ngBindingSource2;
            this.reportViewer4.LocalReport.DataSources.Add(reportDataSource4);
            this.reportViewer4.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report4.rdlc";
            this.reportViewer4.Location = new System.Drawing.Point(8, 0);
            this.reportViewer4.Name = "reportViewer4";
            this.reportViewer4.Size = new System.Drawing.Size(735, 470);
            this.reportViewer4.TabIndex = 3;
            // 
            // reportViewer5
            // 
            reportDataSource5.Name = "DataSet1";
            reportDataSource5.Value = this.agBindingSource1;
            this.reportViewer5.LocalReport.DataSources.Add(reportDataSource5);
            this.reportViewer5.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report5.rdlc";
            this.reportViewer5.Location = new System.Drawing.Point(0, 0);
            this.reportViewer5.Name = "reportViewer5";
            this.reportViewer5.Size = new System.Drawing.Size(743, 458);
            this.reportViewer5.TabIndex = 4;
            // 
            // reportViewer6
            // 
            reportDataSource6.Name = "DataSet1";
            reportDataSource6.Value = this.sAgBindingSource3;
            this.reportViewer6.LocalReport.DataSources.Add(reportDataSource6);
            this.reportViewer6.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report6.rdlc";
            this.reportViewer6.Location = new System.Drawing.Point(8, 8);
            this.reportViewer6.Name = "reportViewer6";
            this.reportViewer6.Size = new System.Drawing.Size(735, 450);
            this.reportViewer6.TabIndex = 5;
            // 
            // reportViewer7
            // 
            reportDataSource7.Name = "DataSet1";
            reportDataSource7.Value = this.sgBindingSource1;
            this.reportViewer7.LocalReport.DataSources.Add(reportDataSource7);
            this.reportViewer7.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report7.rdlc";
            this.reportViewer7.Location = new System.Drawing.Point(0, 0);
            this.reportViewer7.Name = "reportViewer7";
            this.reportViewer7.Size = new System.Drawing.Size(753, 462);
            this.reportViewer7.TabIndex = 6;
            // 
            // reportViewer8
            // 
            reportDataSource8.Name = "DataSet1";
            reportDataSource8.Value = this.skbgBindingSource;
            this.reportViewer8.LocalReport.DataSources.Add(reportDataSource8);
            this.reportViewer8.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report8.rdlc";
            this.reportViewer8.Location = new System.Drawing.Point(0, 0);
            this.reportViewer8.Name = "reportViewer8";
            this.reportViewer8.Size = new System.Drawing.Size(753, 470);
            this.reportViewer8.TabIndex = 7;
            // 
            // reportViewer9
            // 
            reportDataSource9.Name = "DataSet1";
            reportDataSource9.Value = this.smgBindingSource;
            this.reportViewer9.LocalReport.DataSources.Add(reportDataSource9);
            this.reportViewer9.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report9.rdlc";
            this.reportViewer9.Location = new System.Drawing.Point(0, 0);
            this.reportViewer9.Name = "reportViewer9";
            this.reportViewer9.Size = new System.Drawing.Size(753, 470);
            this.reportViewer9.TabIndex = 8;
            // 
            // reportViewer10
            // 
            reportDataSource10.Name = "DataSet1";
            reportDataSource10.Value = this.smruthiBindingSource1;
            this.reportViewer10.LocalReport.DataSources.Add(reportDataSource10);
            this.reportViewer10.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report10.rdlc";
            this.reportViewer10.Location = new System.Drawing.Point(8, 0);
            this.reportViewer10.Name = "reportViewer10";
            this.reportViewer10.Size = new System.Drawing.Size(745, 470);
            this.reportViewer10.TabIndex = 9;
            // 
            // reportViewer11
            // 
            reportDataSource11.Name = "DataSet1";
            reportDataSource11.Value = this.smruthiBindingSource2;
            this.reportViewer11.LocalReport.DataSources.Add(reportDataSource11);
            this.reportViewer11.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report11.rdlc";
            this.reportViewer11.Location = new System.Drawing.Point(0, 0);
            this.reportViewer11.Name = "reportViewer11";
            this.reportViewer11.Size = new System.Drawing.Size(753, 471);
            this.reportViewer11.TabIndex = 10;
            // 
            // reportViewer12
            // 
            reportDataSource12.Name = "DataSet1";
            reportDataSource12.Value = this.svgBindingSource4;
            this.reportViewer12.LocalReport.DataSources.Add(reportDataSource12);
            this.reportViewer12.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report12.rdlc";
            this.reportViewer12.Location = new System.Drawing.Point(0, 0);
            this.reportViewer12.Name = "reportViewer12";
            this.reportViewer12.Size = new System.Drawing.Size(753, 471);
            this.reportViewer12.TabIndex = 11;
            // 
            // reportViewer13
            // 
            reportDataSource13.Name = "DataSet1";
            reportDataSource13.Value = this.vgBindingSource1;
            this.reportViewer13.LocalReport.DataSources.Add(reportDataSource13);
            this.reportViewer13.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report13.rdlc";
            this.reportViewer13.Location = new System.Drawing.Point(0, 0);
            this.reportViewer13.Name = "reportViewer13";
            this.reportViewer13.Size = new System.Drawing.Size(753, 471);
            this.reportViewer13.TabIndex = 12;
            // 
            // reportViewer14
            // 
            reportDataSource14.Name = "DataSet1";
            reportDataSource14.Value = this.vgBindingSource;
            this.reportViewer14.LocalReport.DataSources.Add(reportDataSource14);
            this.reportViewer14.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report13.rdlc";
            this.reportViewer14.Location = new System.Drawing.Point(0, 0);
            this.reportViewer14.Name = "reportViewer14";
            this.reportViewer14.Size = new System.Drawing.Size(753, 470);
            this.reportViewer14.TabIndex = 13;
            this.reportViewer14.Visible = false;
            // 
            // svgTableAdapter
            // 
            this.svgTableAdapter.ClearBeforeFill = true;
            // 
            // smgTableAdapter
            // 
            this.smgTableAdapter.ClearBeforeFill = true;
            // 
            // smgBindingSource2
            // 
            this.smgBindingSource2.DataMember = "Smg";
            this.smgBindingSource2.DataSource = this.chit_fundDataSet;
            // 
            // chitfundDataSetBindingSource
            // 
            this.chitfundDataSetBindingSource.DataSource = this.chit_fundDataSet;
            this.chitfundDataSetBindingSource.Position = 0;
            // 
            // smgBindingSource3
            // 
            this.smgBindingSource3.DataMember = "Smg";
            this.smgBindingSource3.DataSource = this.chitfundDataSetBindingSource;
            // 
            // reportViewer15
            // 
            reportDataSource15.Name = "DataSet1";
            reportDataSource15.Value = this.Group_AmountBindingSource;
            this.reportViewer15.LocalReport.DataSources.Add(reportDataSource15);
            this.reportViewer15.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report12.rdlc";
            this.reportViewer15.Location = new System.Drawing.Point(0, 0);
            this.reportViewer15.Name = "reportViewer15";
            this.reportViewer15.Size = new System.Drawing.Size(731, 485);
            this.reportViewer15.TabIndex = 15;
            // 
            // skbgBindingSource1
            // 
            this.skbgBindingSource1.DataMember = "Skbg";
            this.skbgBindingSource1.DataSource = this.DataSet1;
            // 
            // svgBindingSource3
            // 
            this.svgBindingSource3.DataMember = "Svg";
            this.svgBindingSource3.DataSource = this.DataSet1;
            // 
            // dataSet1BindingSource
            // 
            this.dataSet1BindingSource.DataSource = this.DataSet1;
            this.dataSet1BindingSource.Position = 0;
            // 
            // smruthiTableAdapter
            // 
            this.smruthiTableAdapter.ClearBeforeFill = true;
            // 
            // skbgTableAdapter
            // 
            this.skbgTableAdapter.ClearBeforeFill = true;
            // 
            // sgTableAdapter
            // 
            this.sgTableAdapter.ClearBeforeFill = true;
            // 
            // sAgBindingSource1
            // 
            this.sAgBindingSource1.DataMember = "SAg";
            this.sAgBindingSource1.DataSource = this.DataSet1;
            // 
            // sAgTableAdapter
            // 
            this.sAgTableAdapter.ClearBeforeFill = true;
            // 
            // sAgBindingSource2
            // 
            this.sAgBindingSource2.DataMember = "SAg";
            this.sAgBindingSource2.DataSource = this.DataSet1;
            // 
            // agTableAdapter
            // 
            this.agTableAdapter.ClearBeforeFill = true;
            // 
            // ngBindingSource1
            // 
            this.ngBindingSource1.DataMember = "Ng";
            this.ngBindingSource1.DataSource = this.DataSet1;
            // 
            // ngTableAdapter
            // 
            this.ngTableAdapter.ClearBeforeFill = true;
            // 
            // cgTableAdapter
            // 
            this.cgTableAdapter.ClearBeforeFill = true;
            // 
            // rgBindingSource1
            // 
            this.rgBindingSource1.DataMember = "Rg";
            this.rgBindingSource1.DataSource = this.DataSet1;
            // 
            // rgTableAdapter
            // 
            this.rgTableAdapter.ClearBeforeFill = true;
            // 
            // svgBindingSource2
            // 
            this.svgBindingSource2.DataMember = "Svg";
            this.svgBindingSource2.DataSource = this.DataSet1;
            // 
            // svgTableAdapter1
            // 
            this.svgTableAdapter1.ClearBeforeFill = true;
            // 
            // vgTableAdapter
            // 
            this.vgTableAdapter.ClearBeforeFill = true;
            // 
            // vgBindingSource2
            // 
            this.vgBindingSource2.DataMember = "vg";
            this.vgBindingSource2.DataSource = this.DataSet1;
            // 
            // tgBindingSource1
            // 
            this.tgBindingSource1.DataMember = "tg";
            this.tgBindingSource1.DataSource = this.DataSet1;
            // 
            // tgTableAdapter
            // 
            this.tgTableAdapter.ClearBeforeFill = true;
            // 
            // dataSet1BindingSource2
            // 
            this.dataSet1BindingSource2.DataSource = this.DataSet1;
            this.dataSet1BindingSource2.Position = 0;
            // 
            // dataSet1BindingSource3
            // 
            this.dataSet1BindingSource3.DataSource = this.DataSet1;
            this.dataSet1BindingSource3.Position = 0;
            // 
            // smgBindingSource4
            // 
            this.smgBindingSource4.DataMember = "Smg";
            this.smgBindingSource4.DataSource = this.DataSet1;
            // 
            // smgTableAdapter1
            // 
            this.smgTableAdapter1.ClearBeforeFill = true;
            // 
            // groupAmountBindingSource
            // 
            this.groupAmountBindingSource.DataMember = "Group_Amount";
            this.groupAmountBindingSource.DataSource = this.DataSet1;
            // 
            // rGBindingSource
            // 
            this.rGBindingSource.DataMember = "RG";
            // 
            // tgBindingSource
            // 
            this.tgBindingSource.DataMember = "tg";
            // 
            // agBindingSource
            // 
            this.agBindingSource.DataMember = "ag";
            // 
            // cgBindingSource
            // 
            this.cgBindingSource.DataMember = "cg";
            // 
            // nGBindingSource
            // 
            this.nGBindingSource.DataMember = "NG";
            // 
            // sagBindingSource
            // 
            this.sagBindingSource.DataMember = "sag";
            // 
            // sgBindingSource
            // 
            this.sgBindingSource.DataMember = "sg";
            // 
            // svgBindingSource
            // 
            this.svgBindingSource.DataMember = "svg";
            // 
            // smruthiBindingSource
            // 
            this.smruthiBindingSource.DataMember = "smruthi";
            // 
            // pgBindingSource
            // 
            this.pgBindingSource.DataMember = "pg";
            // 
            // groupAmountBindingSource1
            // 
            this.groupAmountBindingSource1.DataMember = "Group_Amount";
            this.groupAmountBindingSource1.DataSource = this.DataSet1;
            // 
            // addgroupBindingSource
            // 
            this.addgroupBindingSource.DataMember = "Add_group";
            this.addgroupBindingSource.DataSource = this.DataSet1;
            // 
            // add_groupTableAdapter
            // 
            this.add_groupTableAdapter.ClearBeforeFill = true;
            // 
            // dataSet2
            // 
            this.dataSet2.DataSetName = "DataSet2";
            this.dataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupAmountBindingSource2
            // 
            this.groupAmountBindingSource2.DataMember = "Group_Amount";
            this.groupAmountBindingSource2.DataSource = this.dataSet2;
            // 
            // group_AmountTableAdapter
            // 
            this.group_AmountTableAdapter.ClearBeforeFill = true;
            // 
            // groupAmountBindingSource3
            // 
            this.groupAmountBindingSource3.DataMember = "Group_Amount";
            this.groupAmountBindingSource3.DataSource = this.dataSet2;
            // 
            // groupAmountBindingSource4
            // 
            this.groupAmountBindingSource4.DataMember = "Group_Amount";
            this.groupAmountBindingSource4.DataSource = this.dataSet2;
            // 
            // reportViewer16
            // 
            reportDataSource16.Name = "DataSet1";
            reportDataSource16.Value = this.Group_AmountBindingSource;
            this.reportViewer16.LocalReport.DataSources.Add(reportDataSource16);
            this.reportViewer16.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report12.rdlc";
            this.reportViewer16.Location = new System.Drawing.Point(0, 0);
            this.reportViewer16.Name = "reportViewer16";
            this.reportViewer16.Size = new System.Drawing.Size(753, 485);
            this.reportViewer16.TabIndex = 16;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 485);
            this.Controls.Add(this.reportViewer16);
            this.Controls.Add(this.reportViewer15);
            this.Controls.Add(this.reportViewer9);
            this.Controls.Add(this.reportViewer8);
            this.Controls.Add(this.reportViewer7);
            this.Controls.Add(this.reportViewer6);
            this.Controls.Add(this.reportViewer5);
            this.Controls.Add(this.reportViewer4);
            this.Controls.Add(this.reportViewer3);
            this.Controls.Add(this.reportViewer2);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.reportViewer14);
            this.Controls.Add(this.reportViewer13);
            this.Controls.Add(this.reportViewer12);
            this.Controls.Add(this.reportViewer11);
            this.Controls.Add(this.reportViewer10);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Group_AmountBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cgBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAgBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sgBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skbgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smruthiBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smruthiBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chitfundDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skbgBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAgBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAgBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rGBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nGBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sagBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smruthiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addgroupBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource Group_AmountBindingSource;
        private DataSet1 DataSet1;
      //  private DataSet1TableAdapters.Group_AmountTableAdapter Group_AmountTableAdapter;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer2;
        private System.Windows.Forms.BindingSource agBindingSource;
       
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer3;
        
        private System.Windows.Forms.BindingSource cgBindingSource;
        
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer4;
        
        private System.Windows.Forms.BindingSource nGBindingSource;
        
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer5;
        
        private System.Windows.Forms.BindingSource pgBindingSource;
        
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer6;
        
        private System.Windows.Forms.BindingSource rGBindingSource;
        
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer7;
        
        private System.Windows.Forms.BindingSource sagBindingSource;
        
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer8;
        
        private System.Windows.Forms.BindingSource sgBindingSource;
        
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer9;
        
        private System.Windows.Forms.BindingSource skbgBindingSource;
        
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer10;
        
        private System.Windows.Forms.BindingSource smgBindingSource;
       
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer11;
       
        private System.Windows.Forms.BindingSource smruthiBindingSource;
       
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer12;
       
        private System.Windows.Forms.BindingSource svgBindingSource;
       
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer13;
       
        private System.Windows.Forms.BindingSource tgBindingSource;
       
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer14;
       
        private System.Windows.Forms.BindingSource vgBindingSource;
        private System.Windows.Forms.BindingSource dataSet1BindingSource;
        private System.Windows.Forms.BindingSource dataSet1BindingSource1;
        private Chit_fundDataSet chit_fundDataSet;
        private System.Windows.Forms.BindingSource svgBindingSource1;
        private Chit_fundDataSetTableAdapters.SvgTableAdapter svgTableAdapter;
        private System.Windows.Forms.BindingSource smruthiBindingSource1;
        private DataSet1TableAdapters.SmruthiTableAdapter smruthiTableAdapter;
        private System.Windows.Forms.BindingSource smgBindingSource1;
        private Chit_fundDataSetTableAdapters.SmgTableAdapter smgTableAdapter;
        private System.Windows.Forms.BindingSource skbgBindingSource1;
        private DataSet1TableAdapters.SkbgTableAdapter skbgTableAdapter;
        private System.Windows.Forms.BindingSource sgBindingSource1;
        private DataSet1TableAdapters.SgTableAdapter sgTableAdapter;
        private System.Windows.Forms.BindingSource sAgBindingSource1;
        private DataSet1TableAdapters.SAgTableAdapter sAgTableAdapter;
        private System.Windows.Forms.BindingSource sAgBindingSource2;
        private System.Windows.Forms.BindingSource agBindingSource1;
        private DataSet1TableAdapters.AgTableAdapter agTableAdapter;
        private System.Windows.Forms.BindingSource ngBindingSource1;
        private DataSet1TableAdapters.NgTableAdapter ngTableAdapter;
        private System.Windows.Forms.BindingSource ngBindingSource2;
        private System.Windows.Forms.BindingSource cgBindingSource1;
        private DataSet1TableAdapters.CgTableAdapter cgTableAdapter;
        private System.Windows.Forms.BindingSource rgBindingSource1;
        private DataSet1TableAdapters.RgTableAdapter rgTableAdapter;
        private System.Windows.Forms.BindingSource agBindingSource2;
        private System.Windows.Forms.BindingSource svgBindingSource2;
        private DataSet1TableAdapters.SvgTableAdapter svgTableAdapter1;
        private System.Windows.Forms.BindingSource svgBindingSource3;
        private System.Windows.Forms.BindingSource vgBindingSource1;
        private DataSet1TableAdapters.vgTableAdapter vgTableAdapter;
        private System.Windows.Forms.BindingSource sAgBindingSource3;
        private System.Windows.Forms.BindingSource smruthiBindingSource2;
        private System.Windows.Forms.BindingSource vgBindingSource2;
        private System.Windows.Forms.BindingSource tgBindingSource1;
        private DataSet1TableAdapters.tgTableAdapter tgTableAdapter;
        private System.Windows.Forms.BindingSource svgBindingSource4;
        private System.Windows.Forms.BindingSource smgBindingSource2;
        private System.Windows.Forms.BindingSource smgBindingSource3;
        private System.Windows.Forms.BindingSource chitfundDataSetBindingSource;
        private System.Windows.Forms.BindingSource dataSet1BindingSource2;
        private System.Windows.Forms.BindingSource dataSet1BindingSource3;
        private System.Windows.Forms.BindingSource smgBindingSource4;
        private DataSet1TableAdapters.SmgTableAdapter smgTableAdapter1;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer15;
        private System.Windows.Forms.BindingSource groupAmountBindingSource;
        private System.Windows.Forms.BindingSource groupAmountBindingSource1;
        private System.Windows.Forms.BindingSource addgroupBindingSource;
        private DataSet1TableAdapters.Add_groupTableAdapter add_groupTableAdapter;
        private DataSet2 dataSet2;
        private System.Windows.Forms.BindingSource groupAmountBindingSource2;
        private DataSet2TableAdapters.Group_AmountTableAdapter group_AmountTableAdapter;
        private System.Windows.Forms.BindingSource groupAmountBindingSource3;
        private System.Windows.Forms.BindingSource groupAmountBindingSource4;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer16;
       
    }
}