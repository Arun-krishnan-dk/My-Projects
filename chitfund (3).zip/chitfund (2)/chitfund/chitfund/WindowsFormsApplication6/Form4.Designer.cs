﻿namespace WindowsFormsApplication6
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource31 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource32 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource33 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource34 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource35 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource36 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource37 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource38 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource39 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource40 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource41 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource42 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource43 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource44 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource45 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Group_AmountBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DataSet1 = new WindowsFormsApplication6.DataSet1();
            this.BidBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Chit_fundDataSet13 = new WindowsFormsApplication6.Chit_fundDataSet13();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer2 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer3 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.Group_AmountTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.Group_AmountTableAdapter();
            this.reportViewer4 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer5 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer6 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DataSet2 = new WindowsFormsApplication6.DataSet2();
            this.reportViewer7 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer8 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer9 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer10 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer11 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer12 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer13 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.reportViewer14 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.chit_fundDataSet4 = new WindowsFormsApplication6.Chit_fundDataSet4();
            this.bidBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bidTableAdapter1 = new WindowsFormsApplication6.Chit_fundDataSet4TableAdapters.BidTableAdapter();
            this.txt_d1 = new System.Windows.Forms.TextBox();
            this.txt_d2 = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.BidTableAdapter = new WindowsFormsApplication6.Chit_fundDataSet13TableAdapters.BidTableAdapter();
            this.reportViewer15 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.Chit_fundDataSet2 = new WindowsFormsApplication6.Chit_fundDataSet2();
            ((System.ComponentModel.ISupportInitialize)(this.Group_AmountBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BidBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chit_fundDataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bidBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chit_fundDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // Group_AmountBindingSource
            // 
            this.Group_AmountBindingSource.DataMember = "Group_Amount";
            this.Group_AmountBindingSource.DataSource = this.DataSet1;
            // 
            // DataSet1
            // 
            this.DataSet1.DataSetName = "DataSet1";
            this.DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // BidBindingSource
            // 
            this.BidBindingSource.DataMember = "Bid";
            this.BidBindingSource.DataSource = this.Chit_fundDataSet13;
            // 
            // Chit_fundDataSet13
            // 
            this.Chit_fundDataSet13.DataSetName = "Chit_fundDataSet13";
            this.Chit_fundDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource31.Name = "DataSet1";
            reportDataSource31.Value = this.Group_AmountBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource31);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report19.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(4, 2);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(642, 496);
            this.reportViewer1.TabIndex = 0;
            // 
            // reportViewer2
            // 
            reportDataSource32.Name = "DataSet1";
            reportDataSource32.Value = this.Group_AmountBindingSource;
            this.reportViewer2.LocalReport.DataSources.Add(reportDataSource32);
            this.reportViewer2.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report20.rdlc";
            this.reportViewer2.Location = new System.Drawing.Point(5, 1);
            this.reportViewer2.Name = "reportViewer2";
            this.reportViewer2.Size = new System.Drawing.Size(642, 496);
            this.reportViewer2.TabIndex = 1;
            // 
            // reportViewer3
            // 
            reportDataSource33.Name = "DataSet1";
            reportDataSource33.Value = this.Group_AmountBindingSource;
            this.reportViewer3.LocalReport.DataSources.Add(reportDataSource33);
            this.reportViewer3.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report21.rdlc";
            this.reportViewer3.Location = new System.Drawing.Point(5, 1);
            this.reportViewer3.Name = "reportViewer3";
            this.reportViewer3.Size = new System.Drawing.Size(642, 496);
            this.reportViewer3.TabIndex = 2;
            // 
            // Group_AmountTableAdapter
            // 
            this.Group_AmountTableAdapter.ClearBeforeFill = true;
            // 
            // reportViewer4
            // 
            reportDataSource34.Name = "DataSet1";
            reportDataSource34.Value = this.Group_AmountBindingSource;
            this.reportViewer4.LocalReport.DataSources.Add(reportDataSource34);
            this.reportViewer4.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report22.rdlc";
            this.reportViewer4.Location = new System.Drawing.Point(5, 1);
            this.reportViewer4.Name = "reportViewer4";
            this.reportViewer4.Size = new System.Drawing.Size(642, 496);
            this.reportViewer4.TabIndex = 3;
            // 
            // reportViewer5
            // 
            reportDataSource35.Name = "DataSet1";
            reportDataSource35.Value = this.Group_AmountBindingSource;
            this.reportViewer5.LocalReport.DataSources.Add(reportDataSource35);
            this.reportViewer5.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report23.rdlc";
            this.reportViewer5.Location = new System.Drawing.Point(6, 1);
            this.reportViewer5.Name = "reportViewer5";
            this.reportViewer5.Size = new System.Drawing.Size(642, 496);
            this.reportViewer5.TabIndex = 4;
            // 
            // reportViewer6
            // 
            reportDataSource36.Name = "DataSet1";
            reportDataSource36.Value = this.Group_AmountBindingSource;
            this.reportViewer6.LocalReport.DataSources.Add(reportDataSource36);
            this.reportViewer6.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report24.rdlc";
            this.reportViewer6.Location = new System.Drawing.Point(7, 1);
            this.reportViewer6.Name = "reportViewer6";
            this.reportViewer6.Size = new System.Drawing.Size(642, 496);
            this.reportViewer6.TabIndex = 6;
            // 
            // DataSet2
            // 
            this.DataSet2.DataSetName = "DataSet2";
            this.DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer7
            // 
            reportDataSource37.Name = "DataSet1";
            reportDataSource37.Value = this.Group_AmountBindingSource;
            this.reportViewer7.LocalReport.DataSources.Add(reportDataSource37);
            this.reportViewer7.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report25.rdlc";
            this.reportViewer7.Location = new System.Drawing.Point(5, 0);
            this.reportViewer7.Name = "reportViewer7";
            this.reportViewer7.Size = new System.Drawing.Size(642, 496);
            this.reportViewer7.TabIndex = 7;
            // 
            // reportViewer8
            // 
            reportDataSource38.Name = "DataSet1";
            reportDataSource38.Value = this.Group_AmountBindingSource;
            this.reportViewer8.LocalReport.DataSources.Add(reportDataSource38);
            this.reportViewer8.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report26.rdlc";
            this.reportViewer8.Location = new System.Drawing.Point(6, 1);
            this.reportViewer8.Name = "reportViewer8";
            this.reportViewer8.Size = new System.Drawing.Size(642, 496);
            this.reportViewer8.TabIndex = 8;
            // 
            // reportViewer9
            // 
            reportDataSource39.Name = "DataSet1";
            reportDataSource39.Value = this.Group_AmountBindingSource;
            this.reportViewer9.LocalReport.DataSources.Add(reportDataSource39);
            this.reportViewer9.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report27.rdlc";
            this.reportViewer9.Location = new System.Drawing.Point(5, 1);
            this.reportViewer9.Name = "reportViewer9";
            this.reportViewer9.Size = new System.Drawing.Size(642, 496);
            this.reportViewer9.TabIndex = 9;
            // 
            // reportViewer10
            // 
            reportDataSource40.Name = "DataSet1";
            reportDataSource40.Value = this.Group_AmountBindingSource;
            this.reportViewer10.LocalReport.DataSources.Add(reportDataSource40);
            this.reportViewer10.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report28.rdlc";
            this.reportViewer10.Location = new System.Drawing.Point(5, 1);
            this.reportViewer10.Name = "reportViewer10";
            this.reportViewer10.Size = new System.Drawing.Size(642, 496);
            this.reportViewer10.TabIndex = 10;
            // 
            // reportViewer11
            // 
            reportDataSource41.Name = "DataSet1";
            reportDataSource41.Value = this.Group_AmountBindingSource;
            this.reportViewer11.LocalReport.DataSources.Add(reportDataSource41);
            this.reportViewer11.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report30.rdlc";
            this.reportViewer11.Location = new System.Drawing.Point(6, 1);
            this.reportViewer11.Name = "reportViewer11";
            this.reportViewer11.Size = new System.Drawing.Size(642, 496);
            this.reportViewer11.TabIndex = 11;
            // 
            // reportViewer12
            // 
            reportDataSource42.Name = "DataSet1";
            reportDataSource42.Value = this.Group_AmountBindingSource;
            this.reportViewer12.LocalReport.DataSources.Add(reportDataSource42);
            this.reportViewer12.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report31.rdlc";
            this.reportViewer12.Location = new System.Drawing.Point(7, 1);
            this.reportViewer12.Name = "reportViewer12";
            this.reportViewer12.Size = new System.Drawing.Size(642, 496);
            this.reportViewer12.TabIndex = 12;
            this.reportViewer12.Load += new System.EventHandler(this.reportViewer12_Load);
            // 
            // reportViewer13
            // 
            reportDataSource43.Name = "DataSet1";
            reportDataSource43.Value = this.Group_AmountBindingSource;
            this.reportViewer13.LocalReport.DataSources.Add(reportDataSource43);
            this.reportViewer13.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report29.rdlc";
            this.reportViewer13.Location = new System.Drawing.Point(6, 1);
            this.reportViewer13.Name = "reportViewer13";
            this.reportViewer13.Size = new System.Drawing.Size(642, 496);
            this.reportViewer13.TabIndex = 13;
            // 
            // reportViewer14
            // 
            reportDataSource44.Name = "DataSet1";
            reportDataSource44.Value = this.BidBindingSource;
            this.reportViewer14.LocalReport.DataSources.Add(reportDataSource44);
            this.reportViewer14.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report32.rdlc";
            this.reportViewer14.Location = new System.Drawing.Point(0, 0);
            this.reportViewer14.Name = "reportViewer14";
            this.reportViewer14.Size = new System.Drawing.Size(649, 499);
            this.reportViewer14.TabIndex = 14;
            this.reportViewer14.Visible = false;
            // 
            // chit_fundDataSet4
            // 
            this.chit_fundDataSet4.DataSetName = "Chit_fundDataSet4";
            this.chit_fundDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bidBindingSource1
            // 
            this.bidBindingSource1.DataMember = "Bid";
            this.bidBindingSource1.DataSource = this.chit_fundDataSet4;
            // 
            // bidTableAdapter1
            // 
            this.bidTableAdapter1.ClearBeforeFill = true;
            // 
            // txt_d1
            // 
            this.txt_d1.Location = new System.Drawing.Point(591, 245);
            this.txt_d1.Name = "txt_d1";
            this.txt_d1.Size = new System.Drawing.Size(100, 20);
            this.txt_d1.TabIndex = 15;
            this.txt_d1.Visible = false;
            // 
            // txt_d2
            // 
            this.txt_d2.Location = new System.Drawing.Point(590, 287);
            this.txt_d2.Name = "txt_d2";
            this.txt_d2.Size = new System.Drawing.Size(100, 20);
            this.txt_d2.TabIndex = 16;
            this.txt_d2.Visible = false;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(591, 338);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 17;
            this.txt_name.Visible = false;
            // 
            // BidTableAdapter
            // 
            this.BidTableAdapter.ClearBeforeFill = true;
            // 
            // reportViewer15
            // 
            reportDataSource45.Name = "DataSet1";
            reportDataSource45.Value = this.Group_AmountBindingSource;
            this.reportViewer15.LocalReport.DataSources.Add(reportDataSource45);
            this.reportViewer15.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report34.rdlc";
            this.reportViewer15.Location = new System.Drawing.Point(0, 2);
            this.reportViewer15.Name = "reportViewer15";
            this.reportViewer15.Size = new System.Drawing.Size(652, 496);
            this.reportViewer15.TabIndex = 18;
            // 
            // Chit_fundDataSet2
            // 
            this.Chit_fundDataSet2.DataSetName = "Chit_fundDataSet2";
            this.Chit_fundDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 498);
            this.Controls.Add(this.reportViewer15);
            this.Controls.Add(this.reportViewer14);
            this.Controls.Add(this.reportViewer13);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.txt_d2);
            this.Controls.Add(this.txt_d1);
            this.Controls.Add(this.reportViewer11);
            this.Controls.Add(this.reportViewer10);
            this.Controls.Add(this.reportViewer9);
            this.Controls.Add(this.reportViewer8);
            this.Controls.Add(this.reportViewer7);
            this.Controls.Add(this.reportViewer6);
            this.Controls.Add(this.reportViewer5);
            this.Controls.Add(this.reportViewer4);
            this.Controls.Add(this.reportViewer3);
            this.Controls.Add(this.reportViewer2);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.reportViewer12);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Group_AmountBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BidBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chit_fundDataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bidBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chit_fundDataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource Group_AmountBindingSource;
        private DataSet1 DataSet1;
        private DataSet1TableAdapters.Group_AmountTableAdapter Group_AmountTableAdapter;
        private DataSet2 DataSet2;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer2;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer3;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer4;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer5;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer6;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer7;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer8;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer9;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer10;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer11;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer12;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer13;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer14;
        private System.Windows.Forms.BindingSource BidBindingSource;
        private Chit_fundDataSet13 Chit_fundDataSet13;
        private Chit_fundDataSet13TableAdapters.BidTableAdapter BidTableAdapter;
        private Chit_fundDataSet4 chit_fundDataSet4;
        private System.Windows.Forms.BindingSource bidBindingSource1;
        private Chit_fundDataSet4TableAdapters.BidTableAdapter bidTableAdapter1;
        public System.Windows.Forms.TextBox txt_d1;
        public System.Windows.Forms.TextBox txt_d2;
        public System.Windows.Forms.TextBox txt_name;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer15;
        private Chit_fundDataSet2 Chit_fundDataSet2;
    }
}