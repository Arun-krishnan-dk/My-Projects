﻿namespace WindowsFormsApplication6
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Group_AmountBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DataSet2 = new WindowsFormsApplication6.DataSet2();
            this.Group_AmountTableAdapter = new WindowsFormsApplication6.DataSet2TableAdapters.Group_AmountTableAdapter();
            this.chit_fundDataSet3 = new WindowsFormsApplication6.Chit_fundDataSet3();
            this.groupAmountBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.group_AmountTableAdapter1 = new WindowsFormsApplication6.Chit_fundDataSet3TableAdapters.Group_AmountTableAdapter();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DataSet1 = new WindowsFormsApplication6.DataSet1();
            this.SvgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SvgTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.SvgTableAdapter();
            this.txt_date1 = new System.Windows.Forms.TextBox();
            this.txt_Date2 = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.groupAmountBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.vgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vgTableAdapter = new WindowsFormsApplication6.DataSet1TableAdapters.vgTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Group_AmountBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SvgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Group_AmountBindingSource
            // 
            this.Group_AmountBindingSource.DataMember = "Group_Amount";
            this.Group_AmountBindingSource.DataSource = this.DataSet2;
            // 
            // DataSet2
            // 
            this.DataSet2.DataSetName = "DataSet2";
            this.DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Group_AmountTableAdapter
            // 
            this.Group_AmountTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet3
            // 
            this.chit_fundDataSet3.DataSetName = "Chit_fundDataSet3";
            this.chit_fundDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupAmountBindingSource
            // 
            this.groupAmountBindingSource.DataMember = "Group_Amount";
            this.groupAmountBindingSource.DataSource = this.chit_fundDataSet3;
            // 
            // group_AmountTableAdapter1
            // 
            this.group_AmountTableAdapter1.ClearBeforeFill = true;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.Group_AmountBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication6.Report12.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(825, 482);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // DataSet1
            // 
            this.DataSet1.DataSetName = "DataSet1";
            this.DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // SvgBindingSource
            // 
            this.SvgBindingSource.DataMember = "Svg";
            this.SvgBindingSource.DataSource = this.DataSet1;
            // 
            // SvgTableAdapter
            // 
            this.SvgTableAdapter.ClearBeforeFill = true;
            // 
            // txt_date1
            // 
            this.txt_date1.Location = new System.Drawing.Point(748, 24);
            this.txt_date1.Name = "txt_date1";
            this.txt_date1.Size = new System.Drawing.Size(77, 20);
            this.txt_date1.TabIndex = 1;
            // 
            // txt_Date2
            // 
            this.txt_Date2.Location = new System.Drawing.Point(748, 50);
            this.txt_Date2.Name = "txt_Date2";
            this.txt_Date2.Size = new System.Drawing.Size(77, 20);
            this.txt_Date2.TabIndex = 1;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(748, 76);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(77, 20);
            this.txt_name.TabIndex = 1;
            this.txt_name.Text = "Apoorva";
            // 
            // groupAmountBindingSource1
            // 
            this.groupAmountBindingSource1.DataMember = "Group_Amount";
            this.groupAmountBindingSource1.DataSource = this.DataSet2;
            // 
            // vgBindingSource
            // 
            this.vgBindingSource.DataMember = "vg";
            this.vgBindingSource.DataSource = this.DataSet1;
            // 
            // vgTableAdapter
            // 
            this.vgTableAdapter.ClearBeforeFill = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 482);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.txt_Date2);
            this.Controls.Add(this.txt_date1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Group_AmountBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SvgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupAmountBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource Group_AmountBindingSource;
        private DataSet2 DataSet2;
        private DataSet2TableAdapters.Group_AmountTableAdapter Group_AmountTableAdapter;
        private Chit_fundDataSet3 chit_fundDataSet3;
        private System.Windows.Forms.BindingSource groupAmountBindingSource;
        private Chit_fundDataSet3TableAdapters.Group_AmountTableAdapter group_AmountTableAdapter1;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private DataSet1 DataSet1;
        private System.Windows.Forms.BindingSource SvgBindingSource;
        private DataSet1TableAdapters.SvgTableAdapter SvgTableAdapter;
        private System.Windows.Forms.BindingSource groupAmountBindingSource1;
        public System.Windows.Forms.TextBox txt_date1;
        public System.Windows.Forms.TextBox txt_Date2;
        public System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.BindingSource vgBindingSource;
        private DataSet1TableAdapters.vgTableAdapter vgTableAdapter;
    }
}