﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet2.Group_Amount' table. You can move, or remove it, as needed.

            // TODO: This line of code loads data into the 'DataSet1.Add_group' table. You can move, or remove it, as needed.
            //this.add_groupTableAdapter.Fill(this.DataSet1.Add_group);
            // TODO: This line of code loads data into the 'DataSet1.Smg' table. You can move, or remove it, as needed.
            //this.smgTableAdapter1.Fill(this.DataSet1.Smg);
            // TODO: This line of code loads data into the 'DataSet1.Group_Amount' table. You can move, or remove it, as needed.
          //  this.Group_AmountTableAdapter.Fill(this.DataSet1.Group_Amount);
            // TODO: This line of code loads data into the 'DataSet1.tg' table. You can move, or remove it, as needed.
            //this.tgTableAdapter.Fill(this.DataSet1.tg);
            // TODO: This line of code loads data into the 'DataSet1.vg' table. You can move, or remove it, as needed.
           // this.vgTableAdapter.Fill(this.DataSet1.vg);
            // TODO: This line of code loads data into the 'DataSet1.Svg' table. You can move, or remove it, as needed.
           // this.svgTableAdapter1.Fill(this.DataSet1.Svg);
            // TODO: This line of code loads data into the 'DataSet1.Rg' table. You can move, or remove it, as needed.
            //this.rgTableAdapter.Fill(this.DataSet1.Rg);
            // TODO: This line of code loads data into the 'DataSet1.Cg' table. You can move, or remove it, as needed.
           // this.cgTableAdapter.Fill(this.DataSet1.Cg);
            // TODO: This line of code loads data into the 'DataSet1.Ng' table. You can move, or remove it, as needed.
           // this.ngTableAdapter.Fill(this.DataSet1.Ng);
            // TODO: This line of code loads data into the 'DataSet1.Ag' table. You can move, or remove it, as needed.
            //this.agTableAdapter.Fill(this.DataSet1.Ag);
            // TODO: This line of code loads data into the 'DataSet1.SAg' table. You can move, or remove it, as needed.
           // this.sAgTableAdapter.Fill(this.DataSet1.SAg);
            // TODO: This line of code loads data into the 'DataSet1.Sg' table. You can move, or remove it, as needed.
            //this.sgTableAdapter.Fill(this.DataSet1.Sg);
            // TODO: This line of code loads data into the 'DataSet1.Skbg' table. You can move, or remove it, as needed.
           // this.skbgTableAdapter.Fill(this.DataSet1.Skbg);
            // TODO: This line of code loads data into the 'chit_fundDataSet.Smg' table. You can move, or remove it, as needed.
           // this.smgTableAdapter.Fill(this.chit_fundDataSet.Smg);
            // TODO: This line of code loads data into the 'DataSet1.Smruthi' table. You can move, or remove it, as needed.
           // this.smruthiTableAdapter.Fill(this.DataSet1.Smruthi);
            // TODO: This line of code loads data into the 'chit_fundDataSet.Svg' table. You can move, or remove it, as needed.
            //this.svgTableAdapter.Fill(this.chit_fundDataSet.Svg);
            //this.reportViewer3.RefreshReport();
            //this.reportViewer4.RefreshReport();
            //this.reportViewer5.RefreshReport();
            //this.reportViewer6.RefreshReport();
            //this.reportViewer7.RefreshReport();
            //this.reportViewer8.RefreshReport();
            //this.reportViewer9.RefreshReport();
            //this.reportViewer10.RefreshReport();
            //this.reportViewer11.RefreshReport();
            //this.reportViewer12.RefreshReport();
            //this.reportViewer13.RefreshReport();
            //this.reportViewer14.RefreshReport();

            this.reportViewer15.RefreshReport();
            this.reportViewer16.RefreshReport();
        }
    }
}
