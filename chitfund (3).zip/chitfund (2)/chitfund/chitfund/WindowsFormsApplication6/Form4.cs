﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'chit_fundDataSet4.Bid' table. You can move, or remove it, as needed.
            this.bidTableAdapter1.Fill(this.chit_fundDataSet4.Bid);
            // TODO: This line of code loads data into the 'Chit_fundDataSet13.Bid' table. You can move, or remove it, as needed.
            this.BidTableAdapter.Fill(this.Chit_fundDataSet13.Bid, txt_name.Text,txt_d1.Text,txt_d2.Text);
            // TODO: This line of code loads data into the 'DataSet1.Group_Amount' table. You can move, or remove it, as needed.
            this.Group_AmountTableAdapter.Fill(this.DataSet1.Group_Amount);

            this.reportViewer1.RefreshReport();
            this.reportViewer2.RefreshReport();
            this.reportViewer3.RefreshReport();
            this.reportViewer4.RefreshReport();
            this.reportViewer5.RefreshReport();
            this.reportViewer6.RefreshReport();
            this.reportViewer7.RefreshReport();
            this.reportViewer8.RefreshReport();
            this.reportViewer9.RefreshReport();
            this.reportViewer10.RefreshReport();
            this.reportViewer11.RefreshReport();
            this.reportViewer12.RefreshReport();
            this.reportViewer13.RefreshReport();
            this.reportViewer14.RefreshReport();
            this.reportViewer15.RefreshReport();
        }

        private void reportViewer12_Load(object sender, EventArgs e)
        {

        }
    }
}
