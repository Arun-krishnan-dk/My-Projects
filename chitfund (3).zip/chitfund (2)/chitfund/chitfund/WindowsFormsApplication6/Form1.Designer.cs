﻿namespace WindowsFormsApplication6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button18 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label142 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.button13 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.cmb_grp = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_no_Chits = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_add_name = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.pnl_NG = new System.Windows.Forms.Panel();
            this.button83 = new System.Windows.Forms.Button();
            this.dataGridView13 = new System.Windows.Forms.DataGridView();
            this.pnl_RG = new System.Windows.Forms.Panel();
            this.button82 = new System.Windows.Forms.Button();
            this.dataGridView12 = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button31 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.pnl_TG = new System.Windows.Forms.Panel();
            this.button81 = new System.Windows.Forms.Button();
            this.dataGridView11 = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.pnl_SG = new System.Windows.Forms.Panel();
            this.button80 = new System.Windows.Forms.Button();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.pnl_AG = new System.Windows.Forms.Panel();
            this.button79 = new System.Windows.Forms.Button();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.label70 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.dateTimePicker9 = new System.Windows.Forms.DateTimePicker();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.pnl_SMG = new System.Windows.Forms.Panel();
            this.button78 = new System.Windows.Forms.Button();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.label79 = new System.Windows.Forms.Label();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.dateTimePicker10 = new System.Windows.Forms.DateTimePicker();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.pnl_SMRUTHI = new System.Windows.Forms.Panel();
            this.button74 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.label88 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.dateTimePicker11 = new System.Windows.Forms.DateTimePicker();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.pnl_SAG = new System.Windows.Forms.Panel();
            this.button73 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label105 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.label97 = new System.Windows.Forms.Label();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.dateTimePicker12 = new System.Windows.Forms.DateTimePicker();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.pnl_CG = new System.Windows.Forms.Panel();
            this.button84 = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.label106 = new System.Windows.Forms.Label();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.dateTimePicker13 = new System.Windows.Forms.DateTimePicker();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.label114 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.pnl_PG = new System.Windows.Forms.Panel();
            this.load_details = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.label61 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.dateTimePicker8 = new System.Windows.Forms.DateTimePicker();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.chit_fundDataSet = new WindowsFormsApplication6.chit_fundDataSet();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.button72 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.pnl_VG = new System.Windows.Forms.Panel();
            this.button77 = new System.Windows.Forms.Button();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.label124 = new System.Windows.Forms.Label();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.dateTimePicker15 = new System.Windows.Forms.DateTimePicker();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.label132 = new System.Windows.Forms.Label();
            this.pnl_SKBG = new System.Windows.Forms.Panel();
            this.button76 = new System.Windows.Forms.Button();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.label141 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.label133 = new System.Windows.Forms.Label();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.dateTimePicker16 = new System.Windows.Forms.DateTimePicker();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.button71 = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.txt_name_rep = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.date_To = new System.Windows.Forms.DateTimePicker();
            this.date_From = new System.Windows.Forms.DateTimePicker();
            this.button19 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button22 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.pnl_SVG = new System.Windows.Forms.Panel();
            this.button75 = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.label115 = new System.Windows.Forms.Label();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.dateTimePicker14 = new System.Windows.Forms.DateTimePicker();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.label123 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.lbl_TG = new System.Windows.Forms.Label();
            this.lbl_SG = new System.Windows.Forms.Label();
            this.lbl_NG = new System.Windows.Forms.Label();
            this.lbl_AG = new System.Windows.Forms.Label();
            this.lbl_SMG = new System.Windows.Forms.Label();
            this.lbl_Smruthi = new System.Windows.Forms.Label();
            this.lbl_SAG = new System.Windows.Forms.Label();
            this.lbl_CG = new System.Windows.Forms.Label();
            this.lbl_SVG = new System.Windows.Forms.Label();
            this.lbl_PG = new System.Windows.Forms.Label();
            this.lbl_VG = new System.Windows.Forms.Label();
            this.lbl_SKBG = new System.Windows.Forms.Label();
            this.Total = new System.Windows.Forms.Label();
            this.lbl_RG = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pgTableAdapter = new WindowsFormsApplication6.chit_fundDataSetTableAdapters.pgTableAdapter();
            this.chit_fundDataSet1 = new WindowsFormsApplication6.chit_fundDataSet1();
            this.cgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cgTableAdapter = new WindowsFormsApplication6.chit_fundDataSet1TableAdapters.cgTableAdapter();
            this.chit_fundDataSet2 = new WindowsFormsApplication6.chit_fundDataSet2();
            this.sagBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sagTableAdapter = new WindowsFormsApplication6.chit_fundDataSet2TableAdapters.sagTableAdapter();
            this.chit_fundDataSet3 = new WindowsFormsApplication6.chit_fundDataSet3();
            this.smruthiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smruthiTableAdapter = new WindowsFormsApplication6.chit_fundDataSet3TableAdapters.smruthiTableAdapter();
            this.chit_fundDataSet4 = new WindowsFormsApplication6.chit_fundDataSet4();
            this.svgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.svgTableAdapter = new WindowsFormsApplication6.chit_fundDataSet4TableAdapters.svgTableAdapter();
            this.chit_fundDataSet5 = new WindowsFormsApplication6.chit_fundDataSet5();
            this.skbgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.skbgTableAdapter = new WindowsFormsApplication6.chit_fundDataSet5TableAdapters.skbgTableAdapter();
            this.chit_fundDataSet6 = new WindowsFormsApplication6.chit_fundDataSet6();
            this.vgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vgTableAdapter = new WindowsFormsApplication6.chit_fundDataSet6TableAdapters.vgTableAdapter();
            this.chit_fundDataSet7 = new WindowsFormsApplication6.chit_fundDataSet7();
            this.smgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smgTableAdapter = new WindowsFormsApplication6.chit_fundDataSet7TableAdapters.smgTableAdapter();
            this.chit_fundDataSet8 = new WindowsFormsApplication6.chit_fundDataSet8();
            this.agBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.agTableAdapter = new WindowsFormsApplication6.chit_fundDataSet8TableAdapters.agTableAdapter();
            this.chit_fundDataSet9 = new WindowsFormsApplication6.chit_fundDataSet9();
            this.sgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sgTableAdapter = new WindowsFormsApplication6.chit_fundDataSet9TableAdapters.sgTableAdapter();
            this.chit_fundDataSet10 = new WindowsFormsApplication6.chit_fundDataSet10();
            this.tgBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tgTableAdapter = new WindowsFormsApplication6.chit_fundDataSet10TableAdapters.tgTableAdapter();
            this.chit_fundDataSet11 = new WindowsFormsApplication6.chit_fundDataSet11();
            this.rGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rGTableAdapter = new WindowsFormsApplication6.chit_fundDataSet11TableAdapters.RGTableAdapter();
            this.chit_fundDataSet12 = new WindowsFormsApplication6.chit_fundDataSet12();
            this.nGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nGTableAdapter = new WindowsFormsApplication6.chit_fundDataSet12TableAdapters.NGTableAdapter();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button85 = new System.Windows.Forms.Button();
            this.label148 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.txt_installment_amount = new System.Windows.Forms.TextBox();
            this.txt_type_chit = new System.Windows.Forms.TextBox();
            this.txt_total_installment = new System.Windows.Forms.TextBox();
            this.txt_chit_Amount = new System.Windows.Forms.TextBox();
            this.txt_Group_Name = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.txt_pswdl = new System.Windows.Forms.TextBox();
            this.txt_emaill = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button70 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.txt_userid = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txt_cpaswd = new System.Windows.Forms.TextBox();
            this.txt_paswd = new System.Windows.Forms.TextBox();
            this.txt_emailid = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.pnl_NG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).BeginInit();
            this.pnl_RG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.pnl_TG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.pnl_SG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.pnl_AG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.pnl_SMG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.pnl_SMRUTHI.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.pnl_SAG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox12.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.pnl_CG.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.pnl_PG.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet)).BeginInit();
            this.groupBox17.SuspendLayout();
            this.pnl_VG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.pnl_SKBG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.groupBox16.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.panel8.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.pnl_SVG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.groupBox14.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sagBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smruthiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skbgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rGBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nGBindingSource)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button18);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.button9);
            this.panel5.Controls.Add(this.linkLabel1);
            this.panel5.Controls.Add(this.button8);
            this.panel5.Controls.Add(this.button7);
            this.panel5.Controls.Add(this.button5);
            this.panel5.Controls.Add(this.label25);
            this.panel5.Location = new System.Drawing.Point(8, 10);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(823, 549);
            this.panel5.TabIndex = 22;
            this.panel5.Visible = false;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(274, 433);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(230, 44);
            this.button18.TabIndex = 8;
            this.button18.Text = "Reports";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(577, 7);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "Welcome Arun";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(480, 274);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(231, 44);
            this.button9.TabIndex = 1;
            this.button9.Text = "Divident";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(780, 7);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(40, 13);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Logout";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(480, 135);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(231, 44);
            this.button8.TabIndex = 1;
            this.button8.Text = "Add Amount";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(67, 274);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(230, 44);
            this.button7.TabIndex = 1;
            this.button7.Text = "Group For Cutomer";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(64, 139);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(231, 44);
            this.button5.TabIndex = 1;
            this.button5.Text = "Register";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Blue;
            this.label25.Location = new System.Drawing.Point(324, 7);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(145, 39);
            this.label25.TabIndex = 0;
            this.label25.Text = "Chit Fund";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label142);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.date);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txt_address);
            this.panel1.Controls.Add(this.txt_phone);
            this.panel1.Controls.Add(this.txt_name);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(10, 11);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(823, 549);
            this.panel1.TabIndex = 18;
            this.panel1.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "RG",
            "TG",
            "VG",
            "NG",
            "AG",
            "SVG",
            "SKBG",
            "Smruthi",
            "SG",
            "SAG",
            "CG",
            "SMG",
            "PG"});
            this.comboBox1.Location = new System.Drawing.Point(303, 341);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(259, 21);
            this.comboBox1.TabIndex = 11;
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(202, 349);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(36, 13);
            this.label142.TabIndex = 10;
            this.label142.Text = "Group";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(447, 381);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 30);
            this.button1.TabIndex = 8;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // date
            // 
            this.date.Location = new System.Drawing.Point(302, 300);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(259, 20);
            this.date.TabIndex = 7;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(301, 384);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(127, 27);
            this.button13.TabIndex = 6;
            this.button13.Text = "Save";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(197, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(197, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Phone";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(202, 306);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(197, 210);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Address";
            // 
            // txt_address
            // 
            this.txt_address.AcceptsReturn = true;
            this.txt_address.AcceptsTab = true;
            this.txt_address.Location = new System.Drawing.Point(299, 205);
            this.txt_address.Multiline = true;
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(263, 81);
            this.txt_address.TabIndex = 1;
            // 
            // txt_phone
            // 
            this.txt_phone.Location = new System.Drawing.Point(299, 167);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(263, 20);
            this.txt_phone.TabIndex = 1;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(299, 123);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(263, 20);
            this.txt_name.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(324, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(169, 39);
            this.label5.TabIndex = 0;
            this.label5.Text = "Registration";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button15);
            this.panel2.Controls.Add(this.button14);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txt_add_name);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Location = new System.Drawing.Point(11, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(812, 549);
            this.panel2.TabIndex = 19;
            this.panel2.Visible = false;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(568, 123);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(83, 23);
            this.button15.TabIndex = 10;
            this.button15.Text = "Add Group";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(359, 411);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(106, 27);
            this.button14.TabIndex = 9;
            this.button14.Text = "Exit";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.cmb_grp);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txt_no_Chits);
            this.groupBox1.Location = new System.Drawing.Point(179, 182);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(448, 175);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Group";
            this.groupBox1.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(171, 134);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 27);
            this.button3.TabIndex = 12;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // cmb_grp
            // 
            this.cmb_grp.FormattingEnabled = true;
            this.cmb_grp.Items.AddRange(new object[] {
            "RG",
            "TG",
            "VG",
            "NG",
            "AG",
            "SVG",
            "SKBG",
            "Smruthi",
            "SG",
            "SAG",
            "CG",
            "SMG",
            "PG"});
            this.cmb_grp.Location = new System.Drawing.Point(130, 93);
            this.cmb_grp.Name = "cmb_grp";
            this.cmb_grp.Size = new System.Drawing.Size(260, 21);
            this.cmb_grp.TabIndex = 11;
            this.cmb_grp.SelectedIndexChanged += new System.EventHandler(this.cmb_grp_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Group";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "No Of Chits";
            // 
            // txt_no_Chits
            // 
            this.txt_no_Chits.Location = new System.Drawing.Point(130, 44);
            this.txt_no_Chits.Name = "txt_no_Chits";
            this.txt_no_Chits.Size = new System.Drawing.Size(263, 20);
            this.txt_no_Chits.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Name";
            // 
            // txt_add_name
            // 
            this.txt_add_name.Location = new System.Drawing.Point(299, 123);
            this.txt_add_name.Name = "txt_add_name";
            this.txt_add_name.Size = new System.Drawing.Size(263, 20);
            this.txt_add_name.TabIndex = 1;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Blue;
            this.label31.Location = new System.Drawing.Point(324, 7);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(153, 39);
            this.label31.TabIndex = 0;
            this.label31.Text = "Add Group";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Blue;
            this.label32.Location = new System.Drawing.Point(324, 7);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(155, 39);
            this.label32.TabIndex = 0;
            this.label32.Text = "Group_NG";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button16);
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.tableLayoutPanel2);
            this.groupBox3.Location = new System.Drawing.Point(6, 279);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(809, 261);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Table";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(405, 212);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(107, 27);
            this.button16.TabIndex = 13;
            this.button16.Text = "Exit";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click_1);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(278, 212);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(116, 27);
            this.button6.TabIndex = 12;
            this.button6.Text = "Save";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(295, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(123, 19);
            this.label14.TabIndex = 2;
            this.label14.Text = "Enter the Details";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 7;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel2.Controls.Add(this.textBox28, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label17, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label18, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label19, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label20, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.label21, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label22, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.label30, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.textBox31, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.dateTimePicker3, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.textBox32, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.textBox30, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.textBox34, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.textBox33, 2, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(3, 55);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(73, 20);
            this.textBox28.TabIndex = 17;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(106, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 13);
            this.label17.TabIndex = 27;
            this.label17.Text = "Date";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(224, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 13);
            this.label18.TabIndex = 29;
            this.label18.Text = "Instal No";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(323, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 13);
            this.label19.TabIndex = 30;
            this.label19.Text = "Bid Amount";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(446, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 13);
            this.label20.TabIndex = 31;
            this.label20.Text = "Commssion";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(567, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 13);
            this.label21.TabIndex = 34;
            this.label21.Text = "Balance";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(688, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(31, 13);
            this.label22.TabIndex = 36;
            this.label22.Text = "Total";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(3, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(35, 13);
            this.label30.TabIndex = 28;
            this.label30.Text = "Name";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(688, 55);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(87, 20);
            this.textBox31.TabIndex = 14;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker3.TabIndex = 37;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(567, 55);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(77, 20);
            this.textBox32.TabIndex = 13;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(446, 55);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(74, 20);
            this.textBox30.TabIndex = 15;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(323, 55);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(91, 20);
            this.textBox34.TabIndex = 11;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(224, 55);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(74, 20);
            this.textBox33.TabIndex = 12;
            // 
            // pnl_NG
            // 
            this.pnl_NG.Controls.Add(this.button83);
            this.pnl_NG.Controls.Add(this.dataGridView13);
            this.pnl_NG.Controls.Add(this.groupBox3);
            this.pnl_NG.Controls.Add(this.label32);
            this.pnl_NG.Location = new System.Drawing.Point(15, 11);
            this.pnl_NG.Name = "pnl_NG";
            this.pnl_NG.Size = new System.Drawing.Size(822, 549);
            this.pnl_NG.TabIndex = 21;
            this.pnl_NG.Visible = false;
            this.pnl_NG.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(662, 244);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(75, 23);
            this.button83.TabIndex = 12;
            this.button83.Text = "Load Table";
            this.button83.UseVisualStyleBackColor = true;
            this.button83.Click += new System.EventHandler(this.button83_Click);
            // 
            // dataGridView13
            // 
            this.dataGridView13.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView13.Location = new System.Drawing.Point(30, 67);
            this.dataGridView13.Name = "dataGridView13";
            this.dataGridView13.Size = new System.Drawing.Size(757, 150);
            this.dataGridView13.TabIndex = 11;
            // 
            // pnl_RG
            // 
            this.pnl_RG.Controls.Add(this.button82);
            this.pnl_RG.Controls.Add(this.dataGridView12);
            this.pnl_RG.Controls.Add(this.groupBox5);
            this.pnl_RG.Controls.Add(this.label42);
            this.pnl_RG.Location = new System.Drawing.Point(13, 8);
            this.pnl_RG.Name = "pnl_RG";
            this.pnl_RG.Size = new System.Drawing.Size(822, 549);
            this.pnl_RG.TabIndex = 26;
            this.pnl_RG.Visible = false;
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(668, 245);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(75, 23);
            this.button82.TabIndex = 12;
            this.button82.Text = "Load Table";
            this.button82.UseVisualStyleBackColor = true;
            this.button82.Click += new System.EventHandler(this.button82_Click);
            // 
            // dataGridView12
            // 
            this.dataGridView12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView12.Location = new System.Drawing.Point(23, 71);
            this.dataGridView12.Name = "dataGridView12";
            this.dataGridView12.Size = new System.Drawing.Size(768, 150);
            this.dataGridView12.TabIndex = 11;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button31);
            this.groupBox5.Controls.Add(this.button34);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.tableLayoutPanel3);
            this.groupBox5.Location = new System.Drawing.Point(6, 277);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(809, 261);
            this.groupBox5.TabIndex = 10;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Table";
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(405, 212);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(107, 27);
            this.button31.TabIndex = 13;
            this.button31.Text = "Exit";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(278, 212);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(116, 27);
            this.button34.TabIndex = 12;
            this.button34.Text = "Save";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(295, 16);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(123, 19);
            this.label34.TabIndex = 2;
            this.label34.Text = "Enter the Details";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 7;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel3.Controls.Add(this.textBox1, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label35, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label36, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label37, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.label38, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.label39, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.label40, 6, 0);
            this.tableLayoutPanel3.Controls.Add(this.label41, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBox2, 6, 1);
            this.tableLayoutPanel3.Controls.Add(this.dateTimePicker1, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.textBox3, 5, 1);
            this.tableLayoutPanel3.Controls.Add(this.textBox4, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.textBox6, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.textBox21, 2, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(3, 55);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(73, 20);
            this.textBox1.TabIndex = 17;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(106, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(30, 13);
            this.label35.TabIndex = 27;
            this.label35.Text = "Date";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(224, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(49, 13);
            this.label36.TabIndex = 29;
            this.label36.Text = "Instal No";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(323, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(61, 13);
            this.label37.TabIndex = 30;
            this.label37.Text = "Bid Amount";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(446, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(60, 13);
            this.label38.TabIndex = 31;
            this.label38.Text = "Commssion";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(567, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(46, 13);
            this.label39.TabIndex = 34;
            this.label39.Text = "Balance";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(688, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(31, 13);
            this.label40.TabIndex = 36;
            this.label40.Text = "Total";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(3, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(35, 13);
            this.label41.TabIndex = 28;
            this.label41.Text = "Name";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(688, 55);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(87, 20);
            this.textBox2.TabIndex = 14;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker1.TabIndex = 37;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(567, 55);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(77, 20);
            this.textBox3.TabIndex = 13;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(446, 55);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(74, 20);
            this.textBox4.TabIndex = 15;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(323, 55);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(91, 20);
            this.textBox6.TabIndex = 11;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(224, 55);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(74, 20);
            this.textBox21.TabIndex = 12;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Blue;
            this.label42.Location = new System.Drawing.Point(324, 7);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(152, 39);
            this.label42.TabIndex = 0;
            this.label42.Text = "Group_RG";
            // 
            // pnl_TG
            // 
            this.pnl_TG.Controls.Add(this.button81);
            this.pnl_TG.Controls.Add(this.dataGridView11);
            this.pnl_TG.Controls.Add(this.groupBox6);
            this.pnl_TG.Controls.Add(this.label51);
            this.pnl_TG.Location = new System.Drawing.Point(17, 9);
            this.pnl_TG.Name = "pnl_TG";
            this.pnl_TG.Size = new System.Drawing.Size(822, 549);
            this.pnl_TG.TabIndex = 27;
            this.pnl_TG.Visible = false;
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(612, 250);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(75, 23);
            this.button81.TabIndex = 12;
            this.button81.Text = "Load Table";
            this.button81.UseVisualStyleBackColor = true;
            this.button81.Click += new System.EventHandler(this.button81_Click);
            // 
            // dataGridView11
            // 
            this.dataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView11.Location = new System.Drawing.Point(25, 79);
            this.dataGridView11.Name = "dataGridView11";
            this.dataGridView11.Size = new System.Drawing.Size(777, 150);
            this.dataGridView11.TabIndex = 11;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button35);
            this.groupBox6.Controls.Add(this.button36);
            this.groupBox6.Controls.Add(this.label43);
            this.groupBox6.Controls.Add(this.tableLayoutPanel4);
            this.groupBox6.Location = new System.Drawing.Point(6, 281);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(809, 261);
            this.groupBox6.TabIndex = 10;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Table";
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(405, 212);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(107, 27);
            this.button35.TabIndex = 13;
            this.button35.Text = "Exit";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(278, 212);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(116, 27);
            this.button36.TabIndex = 12;
            this.button36.Text = "Save";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(295, 16);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(123, 19);
            this.label43.TabIndex = 2;
            this.label43.Text = "Enter the Details";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 7;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel4.Controls.Add(this.textBox22, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label44, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label45, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label46, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label47, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.label48, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.label49, 6, 0);
            this.tableLayoutPanel4.Controls.Add(this.label50, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBox23, 6, 1);
            this.tableLayoutPanel4.Controls.Add(this.dateTimePicker4, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBox24, 5, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBox25, 4, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBox26, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBox27, 2, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(3, 55);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(73, 20);
            this.textBox22.TabIndex = 17;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(106, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(30, 13);
            this.label44.TabIndex = 27;
            this.label44.Text = "Date";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(224, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(49, 13);
            this.label45.TabIndex = 29;
            this.label45.Text = "Instal No";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(323, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(61, 13);
            this.label46.TabIndex = 30;
            this.label46.Text = "Bid Amount";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(446, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(60, 13);
            this.label47.TabIndex = 31;
            this.label47.Text = "Commssion";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(567, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(46, 13);
            this.label48.TabIndex = 34;
            this.label48.Text = "Balance";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(688, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(31, 13);
            this.label49.TabIndex = 36;
            this.label49.Text = "Total";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(3, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(35, 13);
            this.label50.TabIndex = 28;
            this.label50.Text = "Name";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(688, 55);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(87, 20);
            this.textBox23.TabIndex = 14;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker4.TabIndex = 37;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(567, 55);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(77, 20);
            this.textBox24.TabIndex = 13;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(446, 55);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(74, 20);
            this.textBox25.TabIndex = 15;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(323, 55);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(91, 20);
            this.textBox26.TabIndex = 11;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(224, 55);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(74, 20);
            this.textBox27.TabIndex = 12;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.Blue;
            this.label51.Location = new System.Drawing.Point(324, 7);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(149, 39);
            this.label51.TabIndex = 0;
            this.label51.Text = "Group_TG";
            // 
            // pnl_SG
            // 
            this.pnl_SG.Controls.Add(this.button80);
            this.pnl_SG.Controls.Add(this.dataGridView10);
            this.pnl_SG.Controls.Add(this.groupBox7);
            this.pnl_SG.Controls.Add(this.label60);
            this.pnl_SG.Location = new System.Drawing.Point(14, 11);
            this.pnl_SG.Name = "pnl_SG";
            this.pnl_SG.Size = new System.Drawing.Size(832, 549);
            this.pnl_SG.TabIndex = 28;
            this.pnl_SG.Visible = false;
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(681, 236);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(75, 23);
            this.button80.TabIndex = 12;
            this.button80.Text = "Load Table";
            this.button80.UseVisualStyleBackColor = true;
            this.button80.Click += new System.EventHandler(this.button80_Click);
            // 
            // dataGridView10
            // 
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Location = new System.Drawing.Point(28, 70);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.Size = new System.Drawing.Size(749, 150);
            this.dataGridView10.TabIndex = 11;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button37);
            this.groupBox7.Controls.Add(this.button38);
            this.groupBox7.Controls.Add(this.label52);
            this.groupBox7.Controls.Add(this.tableLayoutPanel5);
            this.groupBox7.Location = new System.Drawing.Point(12, 268);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(809, 261);
            this.groupBox7.TabIndex = 10;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Table";
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(405, 212);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(107, 27);
            this.button37.TabIndex = 13;
            this.button37.Text = "Exit";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(278, 212);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(116, 27);
            this.button38.TabIndex = 12;
            this.button38.Text = "Save";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(295, 16);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(123, 19);
            this.label52.TabIndex = 2;
            this.label52.Text = "Enter the Details";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 7;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel5.Controls.Add(this.textBox29, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label53, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label54, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.label55, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.label56, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this.label57, 5, 0);
            this.tableLayoutPanel5.Controls.Add(this.label58, 6, 0);
            this.tableLayoutPanel5.Controls.Add(this.label59, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.textBox35, 6, 1);
            this.tableLayoutPanel5.Controls.Add(this.dateTimePicker7, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.textBox36, 5, 1);
            this.tableLayoutPanel5.Controls.Add(this.textBox37, 4, 1);
            this.tableLayoutPanel5.Controls.Add(this.textBox38, 3, 1);
            this.tableLayoutPanel5.Controls.Add(this.textBox39, 2, 1);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(3, 55);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(73, 20);
            this.textBox29.TabIndex = 17;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(106, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(30, 13);
            this.label53.TabIndex = 27;
            this.label53.Text = "Date";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(224, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(49, 13);
            this.label54.TabIndex = 29;
            this.label54.Text = "Instal No";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(323, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(61, 13);
            this.label55.TabIndex = 30;
            this.label55.Text = "Bid Amount";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(446, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(60, 13);
            this.label56.TabIndex = 31;
            this.label56.Text = "Commssion";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(567, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(46, 13);
            this.label57.TabIndex = 34;
            this.label57.Text = "Balance";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(688, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(31, 13);
            this.label58.TabIndex = 36;
            this.label58.Text = "Total";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(3, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(35, 13);
            this.label59.TabIndex = 28;
            this.label59.Text = "Name";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(688, 55);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(87, 20);
            this.textBox35.TabIndex = 14;
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker7.TabIndex = 37;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(567, 55);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(77, 20);
            this.textBox36.TabIndex = 13;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(446, 55);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(74, 20);
            this.textBox37.TabIndex = 15;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(323, 55);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(91, 20);
            this.textBox38.TabIndex = 11;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(224, 55);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(74, 20);
            this.textBox39.TabIndex = 12;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Blue;
            this.label60.Location = new System.Drawing.Point(324, 7);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(148, 39);
            this.label60.TabIndex = 0;
            this.label60.Text = "Group_SG";
            // 
            // pnl_AG
            // 
            this.pnl_AG.Controls.Add(this.button79);
            this.pnl_AG.Controls.Add(this.dataGridView9);
            this.pnl_AG.Controls.Add(this.groupBox9);
            this.pnl_AG.Controls.Add(this.label78);
            this.pnl_AG.Location = new System.Drawing.Point(15, 7);
            this.pnl_AG.Name = "pnl_AG";
            this.pnl_AG.Size = new System.Drawing.Size(822, 549);
            this.pnl_AG.TabIndex = 30;
            this.pnl_AG.Visible = false;
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(680, 243);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(75, 23);
            this.button79.TabIndex = 12;
            this.button79.Text = "Load Table";
            this.button79.UseVisualStyleBackColor = true;
            this.button79.Click += new System.EventHandler(this.button79_Click);
            // 
            // dataGridView9
            // 
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Location = new System.Drawing.Point(40, 82);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.Size = new System.Drawing.Size(747, 150);
            this.dataGridView9.TabIndex = 11;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button41);
            this.groupBox9.Controls.Add(this.button42);
            this.groupBox9.Controls.Add(this.label70);
            this.groupBox9.Controls.Add(this.tableLayoutPanel7);
            this.groupBox9.Location = new System.Drawing.Point(7, 275);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(809, 261);
            this.groupBox9.TabIndex = 10;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Table";
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(405, 212);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(107, 27);
            this.button41.TabIndex = 13;
            this.button41.Text = "Exit";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(278, 212);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(116, 27);
            this.button42.TabIndex = 12;
            this.button42.Text = "Save";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(295, 16);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(123, 19);
            this.label70.TabIndex = 2;
            this.label70.Text = "Enter the Details";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 7;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel7.Controls.Add(this.textBox46, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.label71, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.label72, 2, 0);
            this.tableLayoutPanel7.Controls.Add(this.label73, 3, 0);
            this.tableLayoutPanel7.Controls.Add(this.label74, 4, 0);
            this.tableLayoutPanel7.Controls.Add(this.label75, 5, 0);
            this.tableLayoutPanel7.Controls.Add(this.label76, 6, 0);
            this.tableLayoutPanel7.Controls.Add(this.label77, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.textBox47, 6, 1);
            this.tableLayoutPanel7.Controls.Add(this.dateTimePicker9, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.textBox48, 5, 1);
            this.tableLayoutPanel7.Controls.Add(this.textBox49, 4, 1);
            this.tableLayoutPanel7.Controls.Add(this.textBox50, 3, 1);
            this.tableLayoutPanel7.Controls.Add(this.textBox51, 2, 1);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(3, 55);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(73, 20);
            this.textBox46.TabIndex = 17;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(106, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(30, 13);
            this.label71.TabIndex = 27;
            this.label71.Text = "Date";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(224, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(49, 13);
            this.label72.TabIndex = 29;
            this.label72.Text = "Instal No";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(323, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(61, 13);
            this.label73.TabIndex = 30;
            this.label73.Text = "Bid Amount";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(446, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(60, 13);
            this.label74.TabIndex = 31;
            this.label74.Text = "Commssion";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(567, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(46, 13);
            this.label75.TabIndex = 34;
            this.label75.Text = "Balance";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(688, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(31, 13);
            this.label76.TabIndex = 36;
            this.label76.Text = "Total";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(3, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(35, 13);
            this.label77.TabIndex = 28;
            this.label77.Text = "Name";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(688, 55);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(87, 20);
            this.textBox47.TabIndex = 14;
            // 
            // dateTimePicker9
            // 
            this.dateTimePicker9.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker9.Name = "dateTimePicker9";
            this.dateTimePicker9.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker9.TabIndex = 37;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(567, 55);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(77, 20);
            this.textBox48.TabIndex = 13;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(446, 55);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(74, 20);
            this.textBox49.TabIndex = 15;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(323, 55);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(91, 20);
            this.textBox50.TabIndex = 11;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(224, 55);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(74, 20);
            this.textBox51.TabIndex = 12;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.ForeColor = System.Drawing.Color.Blue;
            this.label78.Location = new System.Drawing.Point(324, 7);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(153, 39);
            this.label78.TabIndex = 0;
            this.label78.Text = "Group_AG";
            // 
            // pnl_SMG
            // 
            this.pnl_SMG.Controls.Add(this.button78);
            this.pnl_SMG.Controls.Add(this.dataGridView8);
            this.pnl_SMG.Controls.Add(this.groupBox10);
            this.pnl_SMG.Controls.Add(this.label87);
            this.pnl_SMG.Location = new System.Drawing.Point(17, 9);
            this.pnl_SMG.Name = "pnl_SMG";
            this.pnl_SMG.Size = new System.Drawing.Size(822, 549);
            this.pnl_SMG.TabIndex = 31;
            this.pnl_SMG.Visible = false;
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(635, 251);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(75, 23);
            this.button78.TabIndex = 12;
            this.button78.Text = "Load Table";
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Click += new System.EventHandler(this.button78_Click);
            // 
            // dataGridView8
            // 
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Location = new System.Drawing.Point(34, 78);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.Size = new System.Drawing.Size(747, 150);
            this.dataGridView8.TabIndex = 11;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button43);
            this.groupBox10.Controls.Add(this.button44);
            this.groupBox10.Controls.Add(this.label79);
            this.groupBox10.Controls.Add(this.tableLayoutPanel8);
            this.groupBox10.Location = new System.Drawing.Point(8, 284);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(809, 261);
            this.groupBox10.TabIndex = 10;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Table";
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(405, 212);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(107, 27);
            this.button43.TabIndex = 13;
            this.button43.Text = "Exit";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(278, 212);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(116, 27);
            this.button44.TabIndex = 12;
            this.button44.Text = "Save";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(295, 16);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(123, 19);
            this.label79.TabIndex = 2;
            this.label79.Text = "Enter the Details";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 7;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel8.Controls.Add(this.textBox52, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.label80, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.label81, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.label82, 3, 0);
            this.tableLayoutPanel8.Controls.Add(this.label83, 4, 0);
            this.tableLayoutPanel8.Controls.Add(this.label84, 5, 0);
            this.tableLayoutPanel8.Controls.Add(this.label85, 6, 0);
            this.tableLayoutPanel8.Controls.Add(this.label86, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.textBox53, 6, 1);
            this.tableLayoutPanel8.Controls.Add(this.dateTimePicker10, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.textBox54, 5, 1);
            this.tableLayoutPanel8.Controls.Add(this.textBox55, 4, 1);
            this.tableLayoutPanel8.Controls.Add(this.textBox56, 3, 1);
            this.tableLayoutPanel8.Controls.Add(this.textBox57, 2, 1);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel8.TabIndex = 1;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(3, 55);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(73, 20);
            this.textBox52.TabIndex = 17;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(106, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(30, 13);
            this.label80.TabIndex = 27;
            this.label80.Text = "Date";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(224, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(49, 13);
            this.label81.TabIndex = 29;
            this.label81.Text = "Instal No";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(323, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(61, 13);
            this.label82.TabIndex = 30;
            this.label82.Text = "Bid Amount";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(446, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(60, 13);
            this.label83.TabIndex = 31;
            this.label83.Text = "Commssion";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(567, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(46, 13);
            this.label84.TabIndex = 34;
            this.label84.Text = "Balance";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(688, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(31, 13);
            this.label85.TabIndex = 36;
            this.label85.Text = "Total";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(3, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(35, 13);
            this.label86.TabIndex = 28;
            this.label86.Text = "Name";
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(688, 55);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(87, 20);
            this.textBox53.TabIndex = 14;
            // 
            // dateTimePicker10
            // 
            this.dateTimePicker10.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker10.Name = "dateTimePicker10";
            this.dateTimePicker10.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker10.TabIndex = 37;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(567, 55);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(77, 20);
            this.textBox54.TabIndex = 13;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(446, 55);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(74, 20);
            this.textBox55.TabIndex = 15;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(323, 55);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(91, 20);
            this.textBox56.TabIndex = 11;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(224, 55);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(74, 20);
            this.textBox57.TabIndex = 12;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.ForeColor = System.Drawing.Color.Blue;
            this.label87.Location = new System.Drawing.Point(324, 7);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(176, 39);
            this.label87.TabIndex = 0;
            this.label87.Text = "Group_SMG";
            // 
            // pnl_SMRUTHI
            // 
            this.pnl_SMRUTHI.Controls.Add(this.button74);
            this.pnl_SMRUTHI.Controls.Add(this.dataGridView4);
            this.pnl_SMRUTHI.Controls.Add(this.groupBox11);
            this.pnl_SMRUTHI.Controls.Add(this.label96);
            this.pnl_SMRUTHI.Location = new System.Drawing.Point(17, 10);
            this.pnl_SMRUTHI.Name = "pnl_SMRUTHI";
            this.pnl_SMRUTHI.Size = new System.Drawing.Size(822, 549);
            this.pnl_SMRUTHI.TabIndex = 32;
            this.pnl_SMRUTHI.Visible = false;
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(729, 248);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(75, 23);
            this.button74.TabIndex = 12;
            this.button74.Text = "Load Table";
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Click += new System.EventHandler(this.button74_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(22, 69);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(782, 150);
            this.dataGridView4.TabIndex = 11;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.button45);
            this.groupBox11.Controls.Add(this.button46);
            this.groupBox11.Controls.Add(this.label88);
            this.groupBox11.Controls.Add(this.tableLayoutPanel9);
            this.groupBox11.Location = new System.Drawing.Point(7, 274);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(809, 261);
            this.groupBox11.TabIndex = 10;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Table";
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(405, 212);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(107, 27);
            this.button45.TabIndex = 13;
            this.button45.Text = "Exit";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(278, 212);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(116, 27);
            this.button46.TabIndex = 12;
            this.button46.Text = "Save";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(295, 16);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(123, 19);
            this.label88.TabIndex = 2;
            this.label88.Text = "Enter the Details";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 7;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanel9.Controls.Add(this.textBox58, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.label89, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.label90, 2, 0);
            this.tableLayoutPanel9.Controls.Add(this.label91, 3, 0);
            this.tableLayoutPanel9.Controls.Add(this.label92, 4, 0);
            this.tableLayoutPanel9.Controls.Add(this.label93, 5, 0);
            this.tableLayoutPanel9.Controls.Add(this.label94, 6, 0);
            this.tableLayoutPanel9.Controls.Add(this.label95, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.textBox59, 6, 1);
            this.tableLayoutPanel9.Controls.Add(this.dateTimePicker11, 1, 1);
            this.tableLayoutPanel9.Controls.Add(this.textBox60, 5, 1);
            this.tableLayoutPanel9.Controls.Add(this.textBox61, 4, 1);
            this.tableLayoutPanel9.Controls.Add(this.textBox62, 3, 1);
            this.tableLayoutPanel9.Controls.Add(this.textBox63, 2, 1);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(4, 73);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(3, 55);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(73, 20);
            this.textBox58.TabIndex = 17;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(106, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(30, 13);
            this.label89.TabIndex = 27;
            this.label89.Text = "Date";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(224, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(49, 13);
            this.label90.TabIndex = 29;
            this.label90.Text = "Instal No";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(323, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(61, 13);
            this.label91.TabIndex = 30;
            this.label91.Text = "Bid Amount";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(446, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(60, 13);
            this.label92.TabIndex = 31;
            this.label92.Text = "Commssion";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(567, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(46, 13);
            this.label93.TabIndex = 34;
            this.label93.Text = "Balance";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(692, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(31, 13);
            this.label94.TabIndex = 36;
            this.label94.Text = "Total";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(3, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(35, 13);
            this.label95.TabIndex = 28;
            this.label95.Text = "Name";
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(692, 55);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(87, 20);
            this.textBox59.TabIndex = 14;
            // 
            // dateTimePicker11
            // 
            this.dateTimePicker11.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker11.Name = "dateTimePicker11";
            this.dateTimePicker11.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker11.TabIndex = 37;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(567, 55);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(77, 20);
            this.textBox60.TabIndex = 13;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(446, 55);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(74, 20);
            this.textBox61.TabIndex = 15;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(323, 55);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(91, 20);
            this.textBox62.TabIndex = 11;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(224, 55);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(74, 20);
            this.textBox63.TabIndex = 12;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.ForeColor = System.Drawing.Color.Blue;
            this.label96.Location = new System.Drawing.Point(324, 7);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(253, 39);
            this.label96.TabIndex = 0;
            this.label96.Text = "Group_SMURTHI";
            // 
            // pnl_SAG
            // 
            this.pnl_SAG.Controls.Add(this.button73);
            this.pnl_SAG.Controls.Add(this.dataGridView3);
            this.pnl_SAG.Controls.Add(this.label105);
            this.pnl_SAG.Controls.Add(this.groupBox12);
            this.pnl_SAG.Location = new System.Drawing.Point(16, 9);
            this.pnl_SAG.Name = "pnl_SAG";
            this.pnl_SAG.Size = new System.Drawing.Size(822, 549);
            this.pnl_SAG.TabIndex = 33;
            this.pnl_SAG.Visible = false;
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(629, 252);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(96, 23);
            this.button73.TabIndex = 12;
            this.button73.Text = "Load Table";
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.button73_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(14, 88);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(773, 150);
            this.dataGridView3.TabIndex = 11;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.ForeColor = System.Drawing.Color.Blue;
            this.label105.Location = new System.Drawing.Point(324, 7);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(169, 39);
            this.label105.TabIndex = 0;
            this.label105.Text = "Group_SAG";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button47);
            this.groupBox12.Controls.Add(this.button48);
            this.groupBox12.Controls.Add(this.label97);
            this.groupBox12.Controls.Add(this.tableLayoutPanel10);
            this.groupBox12.Location = new System.Drawing.Point(3, 280);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(809, 261);
            this.groupBox12.TabIndex = 10;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Table";
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(405, 212);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(107, 27);
            this.button47.TabIndex = 13;
            this.button47.Text = "Exit";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(278, 212);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(116, 27);
            this.button48.TabIndex = 12;
            this.button48.Text = "Save";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(295, 16);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(123, 19);
            this.label97.TabIndex = 2;
            this.label97.Text = "Enter the Details";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 7;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel10.Controls.Add(this.textBox64, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.label98, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.label99, 2, 0);
            this.tableLayoutPanel10.Controls.Add(this.label100, 3, 0);
            this.tableLayoutPanel10.Controls.Add(this.label101, 4, 0);
            this.tableLayoutPanel10.Controls.Add(this.label102, 5, 0);
            this.tableLayoutPanel10.Controls.Add(this.label103, 6, 0);
            this.tableLayoutPanel10.Controls.Add(this.label104, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.textBox65, 6, 1);
            this.tableLayoutPanel10.Controls.Add(this.dateTimePicker12, 1, 1);
            this.tableLayoutPanel10.Controls.Add(this.textBox66, 5, 1);
            this.tableLayoutPanel10.Controls.Add(this.textBox67, 4, 1);
            this.tableLayoutPanel10.Controls.Add(this.textBox68, 3, 1);
            this.tableLayoutPanel10.Controls.Add(this.textBox69, 2, 1);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel10.TabIndex = 1;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(3, 55);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(73, 20);
            this.textBox64.TabIndex = 17;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(106, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(30, 13);
            this.label98.TabIndex = 27;
            this.label98.Text = "Date";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(224, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(49, 13);
            this.label99.TabIndex = 29;
            this.label99.Text = "Instal No";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(323, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(61, 13);
            this.label100.TabIndex = 30;
            this.label100.Text = "Bid Amount";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(446, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(60, 13);
            this.label101.TabIndex = 31;
            this.label101.Text = "Commssion";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(567, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(46, 13);
            this.label102.TabIndex = 34;
            this.label102.Text = "Balance";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(688, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(31, 13);
            this.label103.TabIndex = 36;
            this.label103.Text = "Total";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(3, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(35, 13);
            this.label104.TabIndex = 28;
            this.label104.Text = "Name";
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(688, 55);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(87, 20);
            this.textBox65.TabIndex = 14;
            // 
            // dateTimePicker12
            // 
            this.dateTimePicker12.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker12.Name = "dateTimePicker12";
            this.dateTimePicker12.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker12.TabIndex = 37;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(567, 55);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(77, 20);
            this.textBox66.TabIndex = 13;
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(446, 55);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(74, 20);
            this.textBox67.TabIndex = 15;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(323, 55);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(91, 20);
            this.textBox68.TabIndex = 11;
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(224, 55);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(74, 20);
            this.textBox69.TabIndex = 12;
            // 
            // pnl_CG
            // 
            this.pnl_CG.Controls.Add(this.button84);
            this.pnl_CG.Controls.Add(this.groupBox13);
            this.pnl_CG.Controls.Add(this.label114);
            this.pnl_CG.Controls.Add(this.dataGridView2);
            this.pnl_CG.Location = new System.Drawing.Point(12, 9);
            this.pnl_CG.Name = "pnl_CG";
            this.pnl_CG.Size = new System.Drawing.Size(822, 549);
            this.pnl_CG.TabIndex = 34;
            this.pnl_CG.Visible = false;
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(669, 244);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(75, 23);
            this.button84.TabIndex = 47;
            this.button84.Text = "Load Table";
            this.button84.UseVisualStyleBackColor = true;
            this.button84.Click += new System.EventHandler(this.button84_Click);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.button49);
            this.groupBox13.Controls.Add(this.button50);
            this.groupBox13.Controls.Add(this.label106);
            this.groupBox13.Controls.Add(this.tableLayoutPanel11);
            this.groupBox13.Location = new System.Drawing.Point(10, 279);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(809, 261);
            this.groupBox13.TabIndex = 10;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Table";
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(405, 212);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(107, 27);
            this.button49.TabIndex = 13;
            this.button49.Text = "Exit";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(278, 212);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(116, 27);
            this.button50.TabIndex = 12;
            this.button50.Text = "Save";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(295, 16);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(123, 19);
            this.label106.TabIndex = 2;
            this.label106.Text = "Enter the Details";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 7;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel11.Controls.Add(this.textBox70, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.label107, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.label108, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.label109, 3, 0);
            this.tableLayoutPanel11.Controls.Add(this.label110, 4, 0);
            this.tableLayoutPanel11.Controls.Add(this.label111, 5, 0);
            this.tableLayoutPanel11.Controls.Add(this.label112, 6, 0);
            this.tableLayoutPanel11.Controls.Add(this.label113, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.textBox71, 6, 1);
            this.tableLayoutPanel11.Controls.Add(this.dateTimePicker13, 1, 1);
            this.tableLayoutPanel11.Controls.Add(this.textBox72, 5, 1);
            this.tableLayoutPanel11.Controls.Add(this.textBox73, 4, 1);
            this.tableLayoutPanel11.Controls.Add(this.textBox74, 3, 1);
            this.tableLayoutPanel11.Controls.Add(this.textBox75, 2, 1);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.92308F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.07692F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel11.TabIndex = 1;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(3, 57);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(73, 20);
            this.textBox70.TabIndex = 17;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(106, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(30, 13);
            this.label107.TabIndex = 27;
            this.label107.Text = "Date";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(224, 0);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(49, 13);
            this.label108.TabIndex = 29;
            this.label108.Text = "Instal No";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(323, 0);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(61, 13);
            this.label109.TabIndex = 30;
            this.label109.Text = "Bid Amount";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(446, 0);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(60, 13);
            this.label110.TabIndex = 31;
            this.label110.Text = "Commssion";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(567, 0);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(46, 13);
            this.label111.TabIndex = 34;
            this.label111.Text = "Balance";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(688, 0);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(31, 13);
            this.label112.TabIndex = 36;
            this.label112.Text = "Total";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(3, 0);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(35, 13);
            this.label113.TabIndex = 28;
            this.label113.Text = "Name";
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(688, 57);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(87, 20);
            this.textBox71.TabIndex = 14;
            // 
            // dateTimePicker13
            // 
            this.dateTimePicker13.Location = new System.Drawing.Point(106, 57);
            this.dateTimePicker13.Name = "dateTimePicker13";
            this.dateTimePicker13.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker13.TabIndex = 37;
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(567, 57);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(77, 20);
            this.textBox72.TabIndex = 13;
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(446, 57);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(74, 20);
            this.textBox73.TabIndex = 15;
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(323, 57);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(91, 20);
            this.textBox74.TabIndex = 11;
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(224, 57);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(74, 20);
            this.textBox75.TabIndex = 12;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.ForeColor = System.Drawing.Color.Blue;
            this.label114.Location = new System.Drawing.Point(324, 7);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(150, 39);
            this.label114.TabIndex = 0;
            this.label114.Text = "Group_CG";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(32, 56);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(777, 177);
            this.dataGridView2.TabIndex = 11;
            // 
            // pnl_PG
            // 
            this.pnl_PG.Controls.Add(this.load_details);
            this.pnl_PG.Controls.Add(this.groupBox8);
            this.pnl_PG.Controls.Add(this.label69);
            this.pnl_PG.Controls.Add(this.dataGridView1);
            this.pnl_PG.Location = new System.Drawing.Point(12, 4);
            this.pnl_PG.Name = "pnl_PG";
            this.pnl_PG.Size = new System.Drawing.Size(822, 549);
            this.pnl_PG.TabIndex = 36;
            this.pnl_PG.Visible = false;
            // 
            // load_details
            // 
            this.load_details.Location = new System.Drawing.Point(688, 253);
            this.load_details.Name = "load_details";
            this.load_details.Size = new System.Drawing.Size(75, 23);
            this.load_details.TabIndex = 12;
            this.load_details.Text = "Load Table";
            this.load_details.UseVisualStyleBackColor = true;
            this.load_details.Click += new System.EventHandler(this.load_details_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.checkBox1);
            this.groupBox8.Controls.Add(this.button39);
            this.groupBox8.Controls.Add(this.button40);
            this.groupBox8.Controls.Add(this.label61);
            this.groupBox8.Controls.Add(this.tableLayoutPanel6);
            this.groupBox8.Location = new System.Drawing.Point(8, 284);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(809, 261);
            this.groupBox8.TabIndex = 10;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Table";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(7, 42);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(60, 17);
            this.checkBox1.TabIndex = 14;
            this.checkBox1.Text = "Double";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(405, 212);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(107, 27);
            this.button39.TabIndex = 13;
            this.button39.Text = "Exit";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(278, 212);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(116, 27);
            this.button40.TabIndex = 12;
            this.button40.Text = "Save";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(295, 16);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(123, 19);
            this.label61.TabIndex = 2;
            this.label61.Text = "Enter the Details";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 7;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel6.Controls.Add(this.textBox40, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label62, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label63, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.label64, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.label65, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.label66, 5, 0);
            this.tableLayoutPanel6.Controls.Add(this.label67, 6, 0);
            this.tableLayoutPanel6.Controls.Add(this.label68, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.textBox41, 6, 1);
            this.tableLayoutPanel6.Controls.Add(this.dateTimePicker8, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.textBox44, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this.textBox45, 2, 1);
            this.tableLayoutPanel6.Controls.Add(this.textBox42, 4, 1);
            this.tableLayoutPanel6.Controls.Add(this.textBox43, 5, 1);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel6.TabIndex = 1;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(3, 55);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(73, 20);
            this.textBox40.TabIndex = 17;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(106, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(30, 13);
            this.label62.TabIndex = 27;
            this.label62.Text = "Date";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(224, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(49, 13);
            this.label63.TabIndex = 29;
            this.label63.Text = "Instal No";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(323, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(61, 13);
            this.label64.TabIndex = 30;
            this.label64.Text = "Bid Amount";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(446, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(60, 13);
            this.label65.TabIndex = 31;
            this.label65.Text = "Commssion";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(567, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(46, 13);
            this.label66.TabIndex = 34;
            this.label66.Text = "Balance";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(688, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(31, 13);
            this.label67.TabIndex = 36;
            this.label67.Text = "Total";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(3, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(35, 13);
            this.label68.TabIndex = 28;
            this.label68.Text = "Name";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(688, 55);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(87, 20);
            this.textBox41.TabIndex = 14;
            // 
            // dateTimePicker8
            // 
            this.dateTimePicker8.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker8.Name = "dateTimePicker8";
            this.dateTimePicker8.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker8.TabIndex = 37;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(323, 55);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(91, 20);
            this.textBox44.TabIndex = 11;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(224, 55);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(74, 20);
            this.textBox45.TabIndex = 12;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(446, 55);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(77, 20);
            this.textBox42.TabIndex = 13;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(567, 55);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(74, 20);
            this.textBox43.TabIndex = 15;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.Color.Blue;
            this.label69.Location = new System.Drawing.Point(324, 7);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(150, 39);
            this.label69.TabIndex = 0;
            this.label69.Text = "Group_PG";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 64);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(748, 179);
            this.dataGridView1.TabIndex = 11;
            // 
            // pgBindingSource
            // 
            this.pgBindingSource.DataMember = "pg";
            this.pgBindingSource.DataSource = this.chit_fundDataSet;
            // 
            // chit_fundDataSet
            // 
            this.chit_fundDataSet.DataSetName = "chit_fundDataSet";
            this.chit_fundDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.button72);
            this.groupBox17.Controls.Add(this.button69);
            this.groupBox17.Controls.Add(this.button68);
            this.groupBox17.Controls.Add(this.button67);
            this.groupBox17.Controls.Add(this.button66);
            this.groupBox17.Controls.Add(this.button65);
            this.groupBox17.Controls.Add(this.button64);
            this.groupBox17.Controls.Add(this.button63);
            this.groupBox17.Controls.Add(this.button62);
            this.groupBox17.Controls.Add(this.button61);
            this.groupBox17.Controls.Add(this.button60);
            this.groupBox17.Controls.Add(this.button59);
            this.groupBox17.Controls.Add(this.button58);
            this.groupBox17.Controls.Add(this.button57);
            this.groupBox17.Location = new System.Drawing.Point(11, 12);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(843, 542);
            this.groupBox17.TabIndex = 40;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Select the group";
            this.groupBox17.Visible = false;
            this.groupBox17.Enter += new System.EventHandler(this.groupBox17_Enter);
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(340, 480);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(104, 27);
            this.button72.TabIndex = 49;
            this.button72.Text = "Exit";
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(319, 162);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(75, 23);
            this.button69.TabIndex = 12;
            this.button69.Text = "SMRUTHI";
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(447, 228);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(75, 23);
            this.button68.TabIndex = 11;
            this.button68.Text = "CG";
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(442, 101);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(75, 23);
            this.button67.TabIndex = 10;
            this.button67.Text = "SAG";
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(210, 222);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(75, 23);
            this.button66.TabIndex = 9;
            this.button66.Text = "SMG";
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(210, 104);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(75, 23);
            this.button65.TabIndex = 8;
            this.button65.Text = "AG";
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(575, 263);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(75, 23);
            this.button64.TabIndex = 7;
            this.button64.Text = "SKBG";
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(575, 192);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(75, 23);
            this.button63.TabIndex = 6;
            this.button63.Text = "VG";
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(575, 135);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(75, 23);
            this.button62.TabIndex = 5;
            this.button62.Text = "PG";
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(575, 69);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(75, 23);
            this.button61.TabIndex = 4;
            this.button61.Text = "SVG";
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(91, 265);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(75, 23);
            this.button60.TabIndex = 3;
            this.button60.Text = "NG";
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(92, 192);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(75, 23);
            this.button59.TabIndex = 2;
            this.button59.Text = "SG";
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(92, 136);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(75, 23);
            this.button58.TabIndex = 1;
            this.button58.Text = "TG";
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(91, 69);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(75, 23);
            this.button57.TabIndex = 0;
            this.button57.Text = "RG";
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // pnl_VG
            // 
            this.pnl_VG.Controls.Add(this.button77);
            this.pnl_VG.Controls.Add(this.dataGridView7);
            this.pnl_VG.Controls.Add(this.groupBox15);
            this.pnl_VG.Controls.Add(this.label132);
            this.pnl_VG.Location = new System.Drawing.Point(12, 7);
            this.pnl_VG.Name = "pnl_VG";
            this.pnl_VG.Size = new System.Drawing.Size(822, 549);
            this.pnl_VG.TabIndex = 41;
            this.pnl_VG.Visible = false;
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(655, 236);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(75, 23);
            this.button77.TabIndex = 12;
            this.button77.Text = "Load Table";
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.button77_Click);
            // 
            // dataGridView7
            // 
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Location = new System.Drawing.Point(18, 64);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.Size = new System.Drawing.Size(744, 150);
            this.dataGridView7.TabIndex = 11;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.button53);
            this.groupBox15.Controls.Add(this.button54);
            this.groupBox15.Controls.Add(this.label124);
            this.groupBox15.Controls.Add(this.tableLayoutPanel13);
            this.groupBox15.Location = new System.Drawing.Point(7, 266);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(809, 261);
            this.groupBox15.TabIndex = 10;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Table";
            this.groupBox15.Enter += new System.EventHandler(this.groupBox15_Enter);
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(405, 212);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(107, 27);
            this.button53.TabIndex = 13;
            this.button53.Text = "Exit";
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(278, 212);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(116, 27);
            this.button54.TabIndex = 12;
            this.button54.Text = "Save";
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.Location = new System.Drawing.Point(295, 16);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(123, 19);
            this.label124.TabIndex = 2;
            this.label124.Text = "Enter the Details";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 7;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel13.Controls.Add(this.textBox82, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label125, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.label126, 2, 0);
            this.tableLayoutPanel13.Controls.Add(this.label127, 3, 0);
            this.tableLayoutPanel13.Controls.Add(this.label128, 4, 0);
            this.tableLayoutPanel13.Controls.Add(this.label129, 5, 0);
            this.tableLayoutPanel13.Controls.Add(this.label130, 6, 0);
            this.tableLayoutPanel13.Controls.Add(this.label131, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.textBox83, 6, 1);
            this.tableLayoutPanel13.Controls.Add(this.dateTimePicker15, 1, 1);
            this.tableLayoutPanel13.Controls.Add(this.textBox84, 5, 1);
            this.tableLayoutPanel13.Controls.Add(this.textBox85, 4, 1);
            this.tableLayoutPanel13.Controls.Add(this.textBox86, 3, 1);
            this.tableLayoutPanel13.Controls.Add(this.textBox87, 2, 1);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel13.TabIndex = 1;
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(3, 55);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(73, 20);
            this.textBox82.TabIndex = 17;
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(106, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(30, 13);
            this.label125.TabIndex = 27;
            this.label125.Text = "Date";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(224, 0);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(49, 13);
            this.label126.TabIndex = 29;
            this.label126.Text = "Instal No";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(323, 0);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(61, 13);
            this.label127.TabIndex = 30;
            this.label127.Text = "Bid Amount";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(446, 0);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(60, 13);
            this.label128.TabIndex = 31;
            this.label128.Text = "Commssion";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(567, 0);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(46, 13);
            this.label129.TabIndex = 34;
            this.label129.Text = "Balance";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(688, 0);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(31, 13);
            this.label130.TabIndex = 36;
            this.label130.Text = "Total";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(3, 0);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(35, 13);
            this.label131.TabIndex = 28;
            this.label131.Text = "Name";
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(688, 55);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(87, 20);
            this.textBox83.TabIndex = 14;
            // 
            // dateTimePicker15
            // 
            this.dateTimePicker15.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker15.Name = "dateTimePicker15";
            this.dateTimePicker15.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker15.TabIndex = 37;
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(567, 55);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(77, 20);
            this.textBox84.TabIndex = 13;
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(446, 55);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(74, 20);
            this.textBox85.TabIndex = 15;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(323, 55);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(91, 20);
            this.textBox86.TabIndex = 11;
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(224, 55);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(74, 20);
            this.textBox87.TabIndex = 12;
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.ForeColor = System.Drawing.Color.Blue;
            this.label132.Location = new System.Drawing.Point(324, 7);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(153, 39);
            this.label132.TabIndex = 0;
            this.label132.Text = "Group_VG";
            // 
            // pnl_SKBG
            // 
            this.pnl_SKBG.Controls.Add(this.button76);
            this.pnl_SKBG.Controls.Add(this.dataGridView6);
            this.pnl_SKBG.Controls.Add(this.label141);
            this.pnl_SKBG.Controls.Add(this.groupBox16);
            this.pnl_SKBG.Location = new System.Drawing.Point(19, 11);
            this.pnl_SKBG.Name = "pnl_SKBG";
            this.pnl_SKBG.Size = new System.Drawing.Size(822, 549);
            this.pnl_SKBG.TabIndex = 42;
            this.pnl_SKBG.Visible = false;
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(645, 234);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(75, 23);
            this.button76.TabIndex = 12;
            this.button76.Text = "Load Table";
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Click += new System.EventHandler(this.button76_Click);
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(23, 56);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(740, 150);
            this.dataGridView6.TabIndex = 11;
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.ForeColor = System.Drawing.Color.Blue;
            this.label141.Location = new System.Drawing.Point(324, 7);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(190, 39);
            this.label141.TabIndex = 0;
            this.label141.Text = "Group_SKBG";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.button55);
            this.groupBox16.Controls.Add(this.button56);
            this.groupBox16.Controls.Add(this.label133);
            this.groupBox16.Controls.Add(this.tableLayoutPanel14);
            this.groupBox16.Location = new System.Drawing.Point(4, 260);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(809, 261);
            this.groupBox16.TabIndex = 10;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Table";
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(405, 212);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(107, 27);
            this.button55.TabIndex = 13;
            this.button55.Text = "Exit";
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(278, 212);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(116, 27);
            this.button56.TabIndex = 12;
            this.button56.Text = "Save";
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label133.Location = new System.Drawing.Point(295, 16);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(123, 19);
            this.label133.TabIndex = 2;
            this.label133.Text = "Enter the Details";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 7;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel14.Controls.Add(this.textBox88, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.label134, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.label135, 2, 0);
            this.tableLayoutPanel14.Controls.Add(this.label136, 3, 0);
            this.tableLayoutPanel14.Controls.Add(this.label137, 4, 0);
            this.tableLayoutPanel14.Controls.Add(this.label138, 5, 0);
            this.tableLayoutPanel14.Controls.Add(this.label139, 6, 0);
            this.tableLayoutPanel14.Controls.Add(this.label140, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.textBox89, 6, 1);
            this.tableLayoutPanel14.Controls.Add(this.dateTimePicker16, 1, 1);
            this.tableLayoutPanel14.Controls.Add(this.textBox90, 5, 1);
            this.tableLayoutPanel14.Controls.Add(this.textBox91, 4, 1);
            this.tableLayoutPanel14.Controls.Add(this.textBox92, 3, 1);
            this.tableLayoutPanel14.Controls.Add(this.textBox93, 2, 1);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 2;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel14.TabIndex = 1;
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(3, 55);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(73, 20);
            this.textBox88.TabIndex = 17;
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(106, 0);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(30, 13);
            this.label134.TabIndex = 27;
            this.label134.Text = "Date";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(224, 0);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(49, 13);
            this.label135.TabIndex = 29;
            this.label135.Text = "Instal No";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(323, 0);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(61, 13);
            this.label136.TabIndex = 30;
            this.label136.Text = "Bid Amount";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(446, 0);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(60, 13);
            this.label137.TabIndex = 31;
            this.label137.Text = "Commssion";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(567, 0);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(46, 13);
            this.label138.TabIndex = 34;
            this.label138.Text = "Balance";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(688, 0);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(31, 13);
            this.label139.TabIndex = 36;
            this.label139.Text = "Total";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(3, 0);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(35, 13);
            this.label140.TabIndex = 28;
            this.label140.Text = "Name";
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(688, 55);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(87, 20);
            this.textBox89.TabIndex = 14;
            // 
            // dateTimePicker16
            // 
            this.dateTimePicker16.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker16.Name = "dateTimePicker16";
            this.dateTimePicker16.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker16.TabIndex = 37;
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(567, 55);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(77, 20);
            this.textBox90.TabIndex = 13;
            // 
            // textBox91
            // 
            this.textBox91.Location = new System.Drawing.Point(446, 55);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(74, 20);
            this.textBox91.TabIndex = 15;
            // 
            // textBox92
            // 
            this.textBox92.Location = new System.Drawing.Point(323, 55);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(91, 20);
            this.textBox92.TabIndex = 11;
            // 
            // textBox93
            // 
            this.textBox93.Location = new System.Drawing.Point(224, 55);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(74, 20);
            this.textBox93.TabIndex = 12;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.groupBox20);
            this.panel8.Controls.Add(this.groupBox19);
            this.panel8.Controls.Add(this.button71);
            this.panel8.Controls.Add(this.groupBox18);
            this.panel8.Controls.Add(this.groupBox4);
            this.panel8.Location = new System.Drawing.Point(14, 11);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(821, 542);
            this.panel8.TabIndex = 44;
            this.panel8.Visible = false;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.radioButton3);
            this.groupBox20.Controls.Add(this.radioButton4);
            this.groupBox20.Location = new System.Drawing.Point(448, 22);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(323, 51);
            this.groupBox20.TabIndex = 50;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "-";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(233, 19);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(73, 17);
            this.radioButton3.TabIndex = 30;
            this.radioButton3.Text = "Statement";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Checked = true;
            this.radioButton4.Location = new System.Drawing.Point(24, 19);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(55, 17);
            this.radioButton4.TabIndex = 29;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Status";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.radioButton2);
            this.groupBox19.Controls.Add(this.radioButton1);
            this.groupBox19.Location = new System.Drawing.Point(47, 20);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(270, 51);
            this.groupBox19.TabIndex = 49;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Report choose";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(188, 25);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(66, 17);
            this.radioButton2.TabIndex = 30;
            this.radioButton2.Text = "Personal";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(12, 21);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(54, 17);
            this.radioButton1.TabIndex = 29;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Group";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(355, 500);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(104, 27);
            this.button71.TabIndex = 48;
            this.button71.Text = "Exit";
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.button71_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.txt_name_rep);
            this.groupBox18.Controls.Add(this.label33);
            this.groupBox18.Controls.Add(this.label1);
            this.groupBox18.Controls.Add(this.date_To);
            this.groupBox18.Controls.Add(this.date_From);
            this.groupBox18.Controls.Add(this.button19);
            this.groupBox18.Location = new System.Drawing.Point(45, 298);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(732, 177);
            this.groupBox18.TabIndex = 12;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Personal";
            this.groupBox18.Visible = false;
            // 
            // txt_name_rep
            // 
            this.txt_name_rep.Location = new System.Drawing.Point(445, 90);
            this.txt_name_rep.Name = "txt_name_rep";
            this.txt_name_rep.Size = new System.Drawing.Size(156, 20);
            this.txt_name_rep.TabIndex = 27;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(397, 36);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(20, 13);
            this.label33.TabIndex = 25;
            this.label33.Text = "To";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(85, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "From";
            // 
            // date_To
            // 
            this.date_To.Location = new System.Drawing.Point(434, 33);
            this.date_To.Name = "date_To";
            this.date_To.Size = new System.Drawing.Size(192, 20);
            this.date_To.TabIndex = 23;
            // 
            // date_From
            // 
            this.date_From.Location = new System.Drawing.Point(140, 32);
            this.date_From.Name = "date_From";
            this.date_From.Size = new System.Drawing.Size(200, 20);
            this.date_From.TabIndex = 24;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(187, 87);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(104, 27);
            this.button19.TabIndex = 22;
            this.button19.Text = "Main Report";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button22);
            this.groupBox4.Controls.Add(this.button33);
            this.groupBox4.Controls.Add(this.button32);
            this.groupBox4.Controls.Add(this.button27);
            this.groupBox4.Controls.Add(this.button20);
            this.groupBox4.Controls.Add(this.button30);
            this.groupBox4.Controls.Add(this.button26);
            this.groupBox4.Controls.Add(this.button21);
            this.groupBox4.Controls.Add(this.button29);
            this.groupBox4.Controls.Add(this.button28);
            this.groupBox4.Controls.Add(this.button25);
            this.groupBox4.Controls.Add(this.button24);
            this.groupBox4.Controls.Add(this.button23);
            this.groupBox4.Location = new System.Drawing.Point(43, 77);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(731, 198);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Group";
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(61, 143);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(89, 24);
            this.button22.TabIndex = 27;
            this.button22.Text = "SG";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click_2);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(608, 154);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(85, 24);
            this.button33.TabIndex = 23;
            this.button33.Text = "PG";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(334, 80);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(85, 24);
            this.button32.TabIndex = 24;
            this.button32.Text = "Smruthi";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(604, 77);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(89, 24);
            this.button27.TabIndex = 12;
            this.button27.Text = "SKBG";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(608, 21);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(89, 24);
            this.button20.TabIndex = 13;
            this.button20.Text = "VG";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(447, 79);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(89, 26);
            this.button30.TabIndex = 14;
            this.button30.Text = "CG";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(212, 77);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(89, 26);
            this.button26.TabIndex = 15;
            this.button26.Text = "AG";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(61, 77);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(89, 26);
            this.button21.TabIndex = 16;
            this.button21.Text = "TG";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(449, 152);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(89, 24);
            this.button29.TabIndex = 17;
            this.button29.Text = "SVG";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(449, 18);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(87, 28);
            this.button28.TabIndex = 18;
            this.button28.Text = "SAG";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(212, 145);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(89, 24);
            this.button25.TabIndex = 19;
            this.button25.Text = "SMG";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(214, 16);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(87, 28);
            this.button24.TabIndex = 20;
            this.button24.Text = "NG";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click_1);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(63, 16);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(87, 28);
            this.button23.TabIndex = 22;
            this.button23.Text = "RG";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // pnl_SVG
            // 
            this.pnl_SVG.Controls.Add(this.button75);
            this.pnl_SVG.Controls.Add(this.dataGridView5);
            this.pnl_SVG.Controls.Add(this.groupBox14);
            this.pnl_SVG.Controls.Add(this.label123);
            this.pnl_SVG.Location = new System.Drawing.Point(12, 7);
            this.pnl_SVG.Name = "pnl_SVG";
            this.pnl_SVG.Size = new System.Drawing.Size(822, 549);
            this.pnl_SVG.TabIndex = 45;
            this.pnl_SVG.Visible = false;
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(645, 239);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(75, 23);
            this.button75.TabIndex = 12;
            this.button75.Text = "Load Table";
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Click += new System.EventHandler(this.button75_Click);
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(23, 72);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(775, 150);
            this.dataGridView5.TabIndex = 11;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button51);
            this.groupBox14.Controls.Add(this.button52);
            this.groupBox14.Controls.Add(this.label115);
            this.groupBox14.Controls.Add(this.tableLayoutPanel12);
            this.groupBox14.Location = new System.Drawing.Point(7, 278);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(809, 261);
            this.groupBox14.TabIndex = 10;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Table";
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(405, 212);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(107, 27);
            this.button51.TabIndex = 13;
            this.button51.Text = "Exit";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(278, 212);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(116, 27);
            this.button52.TabIndex = 12;
            this.button52.Text = "Save";
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.Location = new System.Drawing.Point(295, 16);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(123, 19);
            this.label115.TabIndex = 2;
            this.label115.Text = "Enter the Details";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 7;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel12.Controls.Add(this.textBox76, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.label116, 1, 0);
            this.tableLayoutPanel12.Controls.Add(this.label117, 2, 0);
            this.tableLayoutPanel12.Controls.Add(this.label118, 3, 0);
            this.tableLayoutPanel12.Controls.Add(this.label119, 4, 0);
            this.tableLayoutPanel12.Controls.Add(this.label120, 5, 0);
            this.tableLayoutPanel12.Controls.Add(this.label121, 6, 0);
            this.tableLayoutPanel12.Controls.Add(this.label122, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.textBox77, 6, 1);
            this.tableLayoutPanel12.Controls.Add(this.dateTimePicker14, 1, 1);
            this.tableLayoutPanel12.Controls.Add(this.textBox78, 5, 1);
            this.tableLayoutPanel12.Controls.Add(this.textBox79, 4, 1);
            this.tableLayoutPanel12.Controls.Add(this.textBox80, 3, 1);
            this.tableLayoutPanel12.Controls.Add(this.textBox81, 2, 1);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(4, 80);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(797, 104);
            this.tableLayoutPanel12.TabIndex = 1;
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(3, 55);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(73, 20);
            this.textBox76.TabIndex = 17;
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(106, 0);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(30, 13);
            this.label116.TabIndex = 27;
            this.label116.Text = "Date";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(224, 0);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(49, 13);
            this.label117.TabIndex = 29;
            this.label117.Text = "Instal No";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(323, 0);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(61, 13);
            this.label118.TabIndex = 30;
            this.label118.Text = "Bid Amount";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(446, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(60, 13);
            this.label119.TabIndex = 31;
            this.label119.Text = "Commssion";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(567, 0);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(46, 13);
            this.label120.TabIndex = 34;
            this.label120.Text = "Balance";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(688, 0);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(31, 13);
            this.label121.TabIndex = 36;
            this.label121.Text = "Total";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(3, 0);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(35, 13);
            this.label122.TabIndex = 28;
            this.label122.Text = "Name";
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(688, 55);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(87, 20);
            this.textBox77.TabIndex = 14;
            // 
            // dateTimePicker14
            // 
            this.dateTimePicker14.Location = new System.Drawing.Point(106, 55);
            this.dateTimePicker14.Name = "dateTimePicker14";
            this.dateTimePicker14.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker14.TabIndex = 37;
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(567, 55);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(77, 20);
            this.textBox78.TabIndex = 13;
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(446, 55);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(74, 20);
            this.textBox79.TabIndex = 15;
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(323, 55);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(91, 20);
            this.textBox80.TabIndex = 11;
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(224, 55);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(74, 20);
            this.textBox81.TabIndex = 12;
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.ForeColor = System.Drawing.Color.Blue;
            this.label123.Location = new System.Drawing.Point(324, 7);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(169, 39);
            this.label123.TabIndex = 0;
            this.label123.Text = "Group_SVG";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(324, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 39);
            this.label13.TabIndex = 0;
            this.label13.Text = "Amount";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(522, 81);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 26);
            this.button4.TabIndex = 7;
            this.button4.Text = "Search";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(266, 87);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(219, 20);
            this.textBox5.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(192, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Search";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.dateTimePicker2);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.lbl_Name);
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            this.groupBox2.Location = new System.Drawing.Point(6, 122);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(809, 300);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Table";
            this.groupBox2.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(325, 256);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(116, 27);
            this.button2.TabIndex = 7;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(280, 227);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(198, 20);
            this.dateTimePicker2.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(295, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 19);
            this.label11.TabIndex = 2;
            this.label11.Text = "Enter the Amount";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(231, 231);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 2;
            this.label12.Text = "Date :";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Location = new System.Drawing.Point(336, 63);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(41, 13);
            this.lbl_Name.TabIndex = 2;
            this.lbl_Name.Text = "Name :";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 14;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.Controls.Add(this.textBox7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox20, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox19, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox18, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox17, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox16, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox15, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox14, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox13, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox12, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox11, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox10, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox9, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox8, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_TG, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_SG, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_NG, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_AG, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_SMG, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_Smruthi, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_SAG, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_CG, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_SVG, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_PG, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_VG, 11, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_SKBG, 12, 0);
            this.tableLayoutPanel1.Controls.Add(this.Total, 13, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_RG, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 101);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(805, 77);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // textBox7
            // 
            this.textBox7.Enabled = false;
            this.textBox7.Location = new System.Drawing.Point(750, 31);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(48, 20);
            this.textBox7.TabIndex = 24;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(623, 31);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(47, 20);
            this.textBox20.TabIndex = 23;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(566, 31);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(39, 20);
            this.textBox19.TabIndex = 22;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(505, 31);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(48, 20);
            this.textBox18.TabIndex = 21;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(448, 31);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(47, 20);
            this.textBox17.TabIndex = 20;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(392, 31);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(43, 20);
            this.textBox16.TabIndex = 19;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(333, 31);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(47, 20);
            this.textBox15.TabIndex = 18;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(278, 31);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(48, 20);
            this.textBox14.TabIndex = 17;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(220, 31);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(48, 20);
            this.textBox13.TabIndex = 16;
            this.textBox13.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(167, 31);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(47, 20);
            this.textBox12.TabIndex = 15;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(118, 31);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(43, 20);
            this.textBox11.TabIndex = 14;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(57, 31);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(47, 20);
            this.textBox10.TabIndex = 13;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(683, 31);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(48, 20);
            this.textBox9.TabIndex = 12;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(3, 31);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(48, 20);
            this.textBox8.TabIndex = 11;
            // 
            // lbl_TG
            // 
            this.lbl_TG.AutoSize = true;
            this.lbl_TG.Location = new System.Drawing.Point(57, 0);
            this.lbl_TG.Name = "lbl_TG";
            this.lbl_TG.Size = new System.Drawing.Size(22, 13);
            this.lbl_TG.TabIndex = 27;
            this.lbl_TG.Text = "TG";
            // 
            // lbl_SG
            // 
            this.lbl_SG.AutoSize = true;
            this.lbl_SG.Location = new System.Drawing.Point(118, 0);
            this.lbl_SG.Name = "lbl_SG";
            this.lbl_SG.Size = new System.Drawing.Size(22, 13);
            this.lbl_SG.TabIndex = 29;
            this.lbl_SG.Text = "SG";
            // 
            // lbl_NG
            // 
            this.lbl_NG.AutoSize = true;
            this.lbl_NG.Location = new System.Drawing.Point(167, 0);
            this.lbl_NG.Name = "lbl_NG";
            this.lbl_NG.Size = new System.Drawing.Size(23, 13);
            this.lbl_NG.TabIndex = 30;
            this.lbl_NG.Text = "NG";
            // 
            // lbl_AG
            // 
            this.lbl_AG.AutoSize = true;
            this.lbl_AG.Location = new System.Drawing.Point(220, 0);
            this.lbl_AG.Name = "lbl_AG";
            this.lbl_AG.Size = new System.Drawing.Size(22, 13);
            this.lbl_AG.TabIndex = 31;
            this.lbl_AG.Text = "AG";
            // 
            // lbl_SMG
            // 
            this.lbl_SMG.AutoSize = true;
            this.lbl_SMG.Location = new System.Drawing.Point(278, 0);
            this.lbl_SMG.Name = "lbl_SMG";
            this.lbl_SMG.Size = new System.Drawing.Size(31, 13);
            this.lbl_SMG.TabIndex = 34;
            this.lbl_SMG.Text = "SMG";
            // 
            // lbl_Smruthi
            // 
            this.lbl_Smruthi.AutoSize = true;
            this.lbl_Smruthi.Location = new System.Drawing.Point(333, 0);
            this.lbl_Smruthi.Name = "lbl_Smruthi";
            this.lbl_Smruthi.Size = new System.Drawing.Size(42, 13);
            this.lbl_Smruthi.TabIndex = 36;
            this.lbl_Smruthi.Text = "Smruthi";
            // 
            // lbl_SAG
            // 
            this.lbl_SAG.AutoSize = true;
            this.lbl_SAG.Location = new System.Drawing.Point(392, 0);
            this.lbl_SAG.Name = "lbl_SAG";
            this.lbl_SAG.Size = new System.Drawing.Size(29, 13);
            this.lbl_SAG.TabIndex = 38;
            this.lbl_SAG.Text = "SAG";
            // 
            // lbl_CG
            // 
            this.lbl_CG.AutoSize = true;
            this.lbl_CG.Location = new System.Drawing.Point(448, 0);
            this.lbl_CG.Name = "lbl_CG";
            this.lbl_CG.Size = new System.Drawing.Size(22, 13);
            this.lbl_CG.TabIndex = 39;
            this.lbl_CG.Text = "CG";
            // 
            // lbl_SVG
            // 
            this.lbl_SVG.AutoSize = true;
            this.lbl_SVG.Location = new System.Drawing.Point(505, 0);
            this.lbl_SVG.Name = "lbl_SVG";
            this.lbl_SVG.Size = new System.Drawing.Size(29, 13);
            this.lbl_SVG.TabIndex = 37;
            this.lbl_SVG.Text = "SVG";
            // 
            // lbl_PG
            // 
            this.lbl_PG.AutoSize = true;
            this.lbl_PG.Location = new System.Drawing.Point(566, 0);
            this.lbl_PG.Name = "lbl_PG";
            this.lbl_PG.Size = new System.Drawing.Size(22, 13);
            this.lbl_PG.TabIndex = 35;
            this.lbl_PG.Text = "PG";
            // 
            // lbl_VG
            // 
            this.lbl_VG.AutoSize = true;
            this.lbl_VG.Location = new System.Drawing.Point(623, 0);
            this.lbl_VG.Name = "lbl_VG";
            this.lbl_VG.Size = new System.Drawing.Size(22, 13);
            this.lbl_VG.TabIndex = 33;
            this.lbl_VG.Text = "VG";
            // 
            // lbl_SKBG
            // 
            this.lbl_SKBG.AutoSize = true;
            this.lbl_SKBG.Location = new System.Drawing.Point(683, 0);
            this.lbl_SKBG.Name = "lbl_SKBG";
            this.lbl_SKBG.Size = new System.Drawing.Size(36, 13);
            this.lbl_SKBG.TabIndex = 32;
            this.lbl_SKBG.Text = "SKBG";
            // 
            // Total
            // 
            this.Total.AutoSize = true;
            this.Total.Location = new System.Drawing.Point(750, 0);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(31, 13);
            this.Total.TabIndex = 26;
            this.Total.Text = "Total";
            // 
            // lbl_RG
            // 
            this.lbl_RG.AutoSize = true;
            this.lbl_RG.Location = new System.Drawing.Point(3, 0);
            this.lbl_RG.Name = "lbl_RG";
            this.lbl_RG.Size = new System.Drawing.Size(23, 13);
            this.lbl_RG.TabIndex = 28;
            this.lbl_RG.Text = "RG";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(330, 444);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(116, 27);
            this.button17.TabIndex = 11;
            this.button17.Text = "Exit";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button17);
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Location = new System.Drawing.Point(16, 7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(822, 549);
            this.panel3.TabIndex = 20;
            this.panel3.Visible = false;
            // 
            // pgTableAdapter
            // 
            this.pgTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet1
            // 
            this.chit_fundDataSet1.DataSetName = "chit_fundDataSet1";
            this.chit_fundDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cgBindingSource
            // 
            this.cgBindingSource.DataMember = "cg";
            this.cgBindingSource.DataSource = this.chit_fundDataSet1;
            // 
            // cgTableAdapter
            // 
            this.cgTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet2
            // 
            this.chit_fundDataSet2.DataSetName = "chit_fundDataSet2";
            this.chit_fundDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sagBindingSource
            // 
            this.sagBindingSource.DataMember = "sag";
            this.sagBindingSource.DataSource = this.chit_fundDataSet2;
            // 
            // sagTableAdapter
            // 
            this.sagTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet3
            // 
            this.chit_fundDataSet3.DataSetName = "chit_fundDataSet3";
            this.chit_fundDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // smruthiBindingSource
            // 
            this.smruthiBindingSource.DataMember = "smruthi";
            this.smruthiBindingSource.DataSource = this.chit_fundDataSet3;
            // 
            // smruthiTableAdapter
            // 
            this.smruthiTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet4
            // 
            this.chit_fundDataSet4.DataSetName = "chit_fundDataSet4";
            this.chit_fundDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // svgBindingSource
            // 
            this.svgBindingSource.DataMember = "svg";
            this.svgBindingSource.DataSource = this.chit_fundDataSet4;
            // 
            // svgTableAdapter
            // 
            this.svgTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet5
            // 
            this.chit_fundDataSet5.DataSetName = "chit_fundDataSet5";
            this.chit_fundDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // skbgBindingSource
            // 
            this.skbgBindingSource.DataMember = "skbg";
            this.skbgBindingSource.DataSource = this.chit_fundDataSet5;
            // 
            // skbgTableAdapter
            // 
            this.skbgTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet6
            // 
            this.chit_fundDataSet6.DataSetName = "chit_fundDataSet6";
            this.chit_fundDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vgBindingSource
            // 
            this.vgBindingSource.DataMember = "vg";
            this.vgBindingSource.DataSource = this.chit_fundDataSet6;
            // 
            // vgTableAdapter
            // 
            this.vgTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet7
            // 
            this.chit_fundDataSet7.DataSetName = "chit_fundDataSet7";
            this.chit_fundDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // smgBindingSource
            // 
            this.smgBindingSource.DataMember = "smg";
            this.smgBindingSource.DataSource = this.chit_fundDataSet7;
            // 
            // smgTableAdapter
            // 
            this.smgTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet8
            // 
            this.chit_fundDataSet8.DataSetName = "chit_fundDataSet8";
            this.chit_fundDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // agBindingSource
            // 
            this.agBindingSource.DataMember = "ag";
            this.agBindingSource.DataSource = this.chit_fundDataSet8;
            // 
            // agTableAdapter
            // 
            this.agTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet9
            // 
            this.chit_fundDataSet9.DataSetName = "chit_fundDataSet9";
            this.chit_fundDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sgBindingSource
            // 
            this.sgBindingSource.DataMember = "sg";
            this.sgBindingSource.DataSource = this.chit_fundDataSet9;
            // 
            // sgTableAdapter
            // 
            this.sgTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet10
            // 
            this.chit_fundDataSet10.DataSetName = "chit_fundDataSet10";
            this.chit_fundDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tgBindingSource
            // 
            this.tgBindingSource.DataMember = "tg";
            this.tgBindingSource.DataSource = this.chit_fundDataSet10;
            // 
            // tgTableAdapter
            // 
            this.tgTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet11
            // 
            this.chit_fundDataSet11.DataSetName = "chit_fundDataSet11";
            this.chit_fundDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rGBindingSource
            // 
            this.rGBindingSource.DataMember = "RG";
            this.rGBindingSource.DataSource = this.chit_fundDataSet11;
            // 
            // rGTableAdapter
            // 
            this.rGTableAdapter.ClearBeforeFill = true;
            // 
            // chit_fundDataSet12
            // 
            this.chit_fundDataSet12.DataSetName = "chit_fundDataSet12";
            this.chit_fundDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nGBindingSource
            // 
            this.nGBindingSource.DataMember = "NG";
            this.nGBindingSource.DataSource = this.chit_fundDataSet12;
            // 
            // nGTableAdapter
            // 
            this.nGTableAdapter.ClearBeforeFill = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button85);
            this.panel4.Controls.Add(this.label148);
            this.panel4.Controls.Add(this.label147);
            this.panel4.Controls.Add(this.label146);
            this.panel4.Controls.Add(this.label145);
            this.panel4.Controls.Add(this.label144);
            this.panel4.Controls.Add(this.label143);
            this.panel4.Controls.Add(this.txt_installment_amount);
            this.panel4.Controls.Add(this.txt_type_chit);
            this.panel4.Controls.Add(this.txt_total_installment);
            this.panel4.Controls.Add(this.txt_chit_Amount);
            this.panel4.Controls.Add(this.txt_Group_Name);
            this.panel4.Location = new System.Drawing.Point(8, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(827, 554);
            this.panel4.TabIndex = 49;
            this.panel4.Visible = false;
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(402, 428);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(99, 29);
            this.button85.TabIndex = 3;
            this.button85.Text = "Save";
            this.button85.UseVisualStyleBackColor = true;
            this.button85.Click += new System.EventHandler(this.button85_Click);
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Font = new System.Drawing.Font("Monotype Corsiva", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label148.ForeColor = System.Drawing.Color.Teal;
            this.label148.Location = new System.Drawing.Point(379, 59);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(163, 36);
            this.label148.TabIndex = 2;
            this.label148.Text = "Create Group";
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Location = new System.Drawing.Point(273, 354);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(96, 13);
            this.label147.TabIndex = 1;
            this.label147.Text = "Installment Amount";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Location = new System.Drawing.Point(273, 310);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(70, 13);
            this.label146.TabIndex = 1;
            this.label146.Text = "Type of Chit :";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Location = new System.Drawing.Point(273, 267);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(90, 13);
            this.label145.TabIndex = 1;
            this.label145.Text = "Total Installment :";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(273, 218);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(70, 13);
            this.label144.TabIndex = 1;
            this.label144.Text = "Chit Amount :";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(273, 175);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(73, 13);
            this.label143.TabIndex = 1;
            this.label143.Text = "Group Name :";
            // 
            // txt_installment_amount
            // 
            this.txt_installment_amount.Location = new System.Drawing.Point(397, 351);
            this.txt_installment_amount.Name = "txt_installment_amount";
            this.txt_installment_amount.Size = new System.Drawing.Size(206, 20);
            this.txt_installment_amount.TabIndex = 0;
            // 
            // txt_type_chit
            // 
            this.txt_type_chit.Location = new System.Drawing.Point(397, 307);
            this.txt_type_chit.Name = "txt_type_chit";
            this.txt_type_chit.Size = new System.Drawing.Size(206, 20);
            this.txt_type_chit.TabIndex = 0;
            // 
            // txt_total_installment
            // 
            this.txt_total_installment.Location = new System.Drawing.Point(397, 264);
            this.txt_total_installment.Name = "txt_total_installment";
            this.txt_total_installment.Size = new System.Drawing.Size(206, 20);
            this.txt_total_installment.TabIndex = 0;
            // 
            // txt_chit_Amount
            // 
            this.txt_chit_Amount.Location = new System.Drawing.Point(397, 215);
            this.txt_chit_Amount.Name = "txt_chit_Amount";
            this.txt_chit_Amount.Size = new System.Drawing.Size(206, 20);
            this.txt_chit_Amount.TabIndex = 0;
            // 
            // txt_Group_Name
            // 
            this.txt_Group_Name.Location = new System.Drawing.Point(397, 172);
            this.txt_Group_Name.Name = "txt_Group_Name";
            this.txt_Group_Name.Size = new System.Drawing.Size(206, 20);
            this.txt_Group_Name.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label28);
            this.panel6.Controls.Add(this.button12);
            this.panel6.Controls.Add(this.button10);
            this.panel6.Controls.Add(this.txt_pswdl);
            this.panel6.Controls.Add(this.txt_emaill);
            this.panel6.Controls.Add(this.label24);
            this.panel6.Controls.Add(this.label16);
            this.panel6.Location = new System.Drawing.Point(310, 160);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(322, 244);
            this.panel6.TabIndex = 51;
            this.panel6.Visible = false;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(82, 18);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(184, 13);
            this.label28.TabIndex = 5;
            this.label28.Text = "Enter Email Id And Password to Login";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(191, 170);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 4;
            this.button12.Text = "Register";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(57, 170);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 4;
            this.button10.Text = "Sign In";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // txt_pswdl
            // 
            this.txt_pswdl.Location = new System.Drawing.Point(126, 106);
            this.txt_pswdl.Name = "txt_pswdl";
            this.txt_pswdl.Size = new System.Drawing.Size(100, 20);
            this.txt_pswdl.TabIndex = 1;
            // 
            // txt_emaill
            // 
            this.txt_emaill.Location = new System.Drawing.Point(126, 49);
            this.txt_emaill.Name = "txt_emaill";
            this.txt_emaill.Size = new System.Drawing.Size(100, 20);
            this.txt_emaill.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(58, 57);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(50, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "Email Id :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(50, 110);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Password :";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button70);
            this.panel7.Controls.Add(this.button11);
            this.panel7.Controls.Add(this.txt_userid);
            this.panel7.Controls.Add(this.label27);
            this.panel7.Controls.Add(this.txt_cpaswd);
            this.panel7.Controls.Add(this.txt_paswd);
            this.panel7.Controls.Add(this.txt_emailid);
            this.panel7.Controls.Add(this.label29);
            this.panel7.Controls.Add(this.label23);
            this.panel7.Controls.Add(this.label26);
            this.panel7.Location = new System.Drawing.Point(299, 159);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(325, 246);
            this.panel7.TabIndex = 50;
            this.panel7.Visible = false;
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(169, 204);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(75, 23);
            this.button70.TabIndex = 5;
            this.button70.Text = "Back";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(80, 206);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 4;
            this.button11.Text = "Register";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // txt_userid
            // 
            this.txt_userid.Location = new System.Drawing.Point(142, 23);
            this.txt_userid.Name = "txt_userid";
            this.txt_userid.Size = new System.Drawing.Size(100, 20);
            this.txt_userid.TabIndex = 3;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(72, 25);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 13);
            this.label27.TabIndex = 2;
            this.label27.Text = "User Id :";
            // 
            // txt_cpaswd
            // 
            this.txt_cpaswd.Location = new System.Drawing.Point(141, 144);
            this.txt_cpaswd.Name = "txt_cpaswd";
            this.txt_cpaswd.Size = new System.Drawing.Size(100, 20);
            this.txt_cpaswd.TabIndex = 1;
            // 
            // txt_paswd
            // 
            this.txt_paswd.Location = new System.Drawing.Point(141, 103);
            this.txt_paswd.Name = "txt_paswd";
            this.txt_paswd.Size = new System.Drawing.Size(100, 20);
            this.txt_paswd.TabIndex = 1;
            // 
            // txt_emailid
            // 
            this.txt_emailid.Location = new System.Drawing.Point(141, 59);
            this.txt_emailid.Name = "txt_emailid";
            this.txt_emailid.Size = new System.Drawing.Size(100, 20);
            this.txt_emailid.TabIndex = 1;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(33, 147);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(97, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "Confirm Password :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(71, 66);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(50, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Email Id :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(57, 106);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 13);
            this.label26.TabIndex = 0;
            this.label26.Text = "Password :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 564);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl_PG);
            this.Controls.Add(this.pnl_CG);
            this.Controls.Add(this.pnl_SAG);
            this.Controls.Add(this.pnl_SMRUTHI);
            this.Controls.Add(this.pnl_SVG);
            this.Controls.Add(this.groupBox17);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.pnl_SKBG);
            this.Controls.Add(this.pnl_VG);
            this.Controls.Add(this.pnl_SMG);
            this.Controls.Add(this.pnl_AG);
            this.Controls.Add(this.pnl_SG);
            this.Controls.Add(this.pnl_TG);
            this.Controls.Add(this.pnl_RG);
            this.Controls.Add(this.pnl_NG);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.pnl_NG.ResumeLayout(false);
            this.pnl_NG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).EndInit();
            this.pnl_RG.ResumeLayout(false);
            this.pnl_RG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.pnl_TG.ResumeLayout(false);
            this.pnl_TG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.pnl_SG.ResumeLayout(false);
            this.pnl_SG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.pnl_AG.ResumeLayout(false);
            this.pnl_AG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.pnl_SMG.ResumeLayout(false);
            this.pnl_SMG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.pnl_SMRUTHI.ResumeLayout(false);
            this.pnl_SMRUTHI.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.pnl_SAG.ResumeLayout(false);
            this.pnl_SAG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.pnl_CG.ResumeLayout(false);
            this.pnl_CG.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.pnl_PG.ResumeLayout(false);
            this.pnl_PG.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet)).EndInit();
            this.groupBox17.ResumeLayout(false);
            this.pnl_VG.ResumeLayout(false);
            this.pnl_VG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.pnl_SKBG.ResumeLayout(false);
            this.pnl_SKBG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.pnl_SVG.ResumeLayout(false);
            this.pnl_SVG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sagBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smruthiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.svgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skbgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rGBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chit_fundDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nGBindingSource)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmb_grp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_no_Chits;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_add_name;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Panel pnl_NG;
        private System.Windows.Forms.Panel pnl_RG;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel pnl_TG;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Panel pnl_SG;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Panel pnl_AG;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.DateTimePicker dateTimePicker9;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Panel pnl_SMG;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.DateTimePicker dateTimePicker10;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Panel pnl_SMRUTHI;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.DateTimePicker dateTimePicker11;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Panel pnl_SAG;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.DateTimePicker dateTimePicker12;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Panel pnl_CG;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.DateTimePicker dateTimePicker13;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Panel pnl_PG;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.DateTimePicker dateTimePicker8;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Panel pnl_VG;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.DateTimePicker dateTimePicker15;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Panel pnl_SKBG;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.DateTimePicker dateTimePicker16;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Panel pnl_SVG;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.DateTimePicker dateTimePicker14;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label lbl_TG;
        private System.Windows.Forms.Label lbl_SG;
        private System.Windows.Forms.Label lbl_NG;
        private System.Windows.Forms.Label lbl_AG;
        private System.Windows.Forms.Label lbl_SMG;
        private System.Windows.Forms.Label lbl_Smruthi;
        private System.Windows.Forms.Label lbl_SAG;
        private System.Windows.Forms.Label lbl_CG;
        private System.Windows.Forms.Label lbl_SVG;
        private System.Windows.Forms.Label lbl_PG;
        private System.Windows.Forms.Label lbl_VG;
        private System.Windows.Forms.Label lbl_SKBG;
        private System.Windows.Forms.Label Total;
        private System.Windows.Forms.Label lbl_RG;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox txt_name_rep;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker date_To;
        private System.Windows.Forms.DateTimePicker date_From;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.DataGridView dataGridView1;
        private chit_fundDataSet chit_fundDataSet;
        private System.Windows.Forms.BindingSource pgBindingSource;
        private chit_fundDataSetTableAdapters.pgTableAdapter pgTableAdapter;
        private System.Windows.Forms.Button load_details;
        private System.Windows.Forms.DataGridView dataGridView2;
        private chit_fundDataSet1 chit_fundDataSet1;
        private System.Windows.Forms.BindingSource cgBindingSource;
        private chit_fundDataSet1TableAdapters.cgTableAdapter cgTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView3;
        private chit_fundDataSet2 chit_fundDataSet2;
        private System.Windows.Forms.BindingSource sagBindingSource;
        private chit_fundDataSet2TableAdapters.sagTableAdapter sagTableAdapter;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.DataGridView dataGridView4;
        private chit_fundDataSet3 chit_fundDataSet3;
        private System.Windows.Forms.BindingSource smruthiBindingSource;
        private chit_fundDataSet3TableAdapters.smruthiTableAdapter smruthiTableAdapter;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.DataGridView dataGridView5;
        private chit_fundDataSet4 chit_fundDataSet4;
        private System.Windows.Forms.BindingSource svgBindingSource;
        private chit_fundDataSet4TableAdapters.svgTableAdapter svgTableAdapter;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.DataGridView dataGridView6;
        private chit_fundDataSet5 chit_fundDataSet5;
        private System.Windows.Forms.BindingSource skbgBindingSource;
        private chit_fundDataSet5TableAdapters.skbgTableAdapter skbgTableAdapter;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.DataGridView dataGridView7;
        private chit_fundDataSet6 chit_fundDataSet6;
        private System.Windows.Forms.BindingSource vgBindingSource;
        private chit_fundDataSet6TableAdapters.vgTableAdapter vgTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView8;
        private chit_fundDataSet7 chit_fundDataSet7;
        private System.Windows.Forms.BindingSource smgBindingSource;
        private chit_fundDataSet7TableAdapters.smgTableAdapter smgTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.Button button78;
        private chit_fundDataSet8 chit_fundDataSet8;
        private System.Windows.Forms.BindingSource agBindingSource;
        private chit_fundDataSet8TableAdapters.agTableAdapter agTableAdapter;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.DataGridView dataGridView10;
        private chit_fundDataSet9 chit_fundDataSet9;
        private System.Windows.Forms.BindingSource sgBindingSource;
        private chit_fundDataSet9TableAdapters.sgTableAdapter sgTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView11;
        private chit_fundDataSet10 chit_fundDataSet10;
        private System.Windows.Forms.BindingSource tgBindingSource;
        private chit_fundDataSet10TableAdapters.tgTableAdapter tgTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView12;
        private System.Windows.Forms.Button button81;
        private chit_fundDataSet11 chit_fundDataSet11;
        private System.Windows.Forms.BindingSource rGBindingSource;
        private chit_fundDataSet11TableAdapters.RGTableAdapter rGTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView13;
        private System.Windows.Forms.Button button82;
        private chit_fundDataSet12 chit_fundDataSet12;
        private System.Windows.Forms.BindingSource nGBindingSource;
        private chit_fundDataSet12TableAdapters.NGTableAdapter nGTableAdapter;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.TextBox txt_installment_amount;
        private System.Windows.Forms.TextBox txt_type_chit;
        private System.Windows.Forms.TextBox txt_total_installment;
        private System.Windows.Forms.TextBox txt_chit_Amount;
        private System.Windows.Forms.TextBox txt_Group_Name;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox txt_pswdl;
        private System.Windows.Forms.TextBox txt_emaill;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox txt_userid;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txt_cpaswd;
        private System.Windows.Forms.TextBox txt_paswd;
        private System.Windows.Forms.TextBox txt_emailid;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Label label148;
    }
}

